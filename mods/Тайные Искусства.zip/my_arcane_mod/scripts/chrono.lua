-- Школа Хрономант: «Ускорение времени» — временный бафф колонистам вокруг мага.
-- Эффект "script" в spells.json зовёт time_haste_cast(кто, x, y, id).
-- Центр — сам маг (alem.pos), а не клик по карте: промахнуться мимо людей нельзя.
-- Остановка времени собрана из готовых эффектов (stun + slow) и скрипта не требует.

local HASTE = {
  time_haste     = { radius = 4.0, hours = 2, move = 0.5,  work = 0.4, melee = 0.3 },
  time_haste_ii  = { radius = 5.0, hours = 3, move = 0.65, work = 0.5, melee = 0.4 },
  time_haste_iii = { radius = 6.0, hours = 4, move = 0.8,  work = 0.6, melee = 0.5 },
}

function time_haste_cast(who, x, y, id)
  local p = HASTE[id] or HASTE.time_haste
  local ok, err = pcall(function()
    local cx, cy = x, y
    if who then
      local px, py = alem.pos(who)
      if px then cx, cy = px, py end
    end

    -- кого ускоряем: все колонисты в радиусе + сам маг
    local list, seen = {}, {}
    for _, name in ipairs(alem.colonists_near(cx, cy, p.radius) or {}) do
      if not seen[name] then seen[name] = true; table.insert(list, name) end
    end
    if who and not seen[who] then table.insert(list, who) end

    for _, name in ipairs(list) do
      alem.buff(name, "chrono_haste", { moveSpeed = p.move, workSpeed = p.work, melee = p.melee }, p.hours)
      local nx, ny = alem.pos(name)
      alem.fx_text("Ускорен!", nx or cx, ny or cy, "#78c8ff")
    end
    alem.fx("flash", cx, cy, p.radius)
    alem.log("chrono haste: ускорено " .. #list .. " чел., на " .. p.hours .. " ч.")
  end)
  if not ok then alem.log("chrono haste: " .. tostring(err)) end
end
