-- Мана: шкала задана в energies.json (100, +10 в час, во сне быстрее).
-- Комплект «Облачение мага» (колпак + мантия) в sets.json даёт настроение и тепло,
-- а здесь — прибавку к максимуму маны: sets.json маны дать не умеет.
-- Раз в несколько секунд проверяем каждого мага: комплект даёт +50, посох в руках — +10/+15/+20 (уникальный +30).
-- Всё в pcall: ошибка здесь не должна выключать скрипты мода.

local SET_BONUS = 50   -- комплект «Облачение мага»: +50 к максимуму
-- Посох в руках прибавляет к максимуму маны (только тем, у кого есть шкала маны).
local STAFF_BONUS = { staff_basic = 10, staff_advanced = 15, staff_divine = 20, staff_guardian = 30 }
local STAFF_BY_SPELL = { divine_wrath = "staff_divine", spark_bolt = "staff_advanced", staff_light = "staff_basic" }

local applied = {}   -- имя -> true, если мы выдали свой максимум
local seen    = {}   -- имя -> уже сбросили старый максимум после загрузки
local logged  = {}   -- имя -> строка с последним залогированным составом

local function has(v, id)
  return type(v) == "string" and string.find(v, id, 1, true) ~= nil
end

-- Надеты ли колпак и мантия: сначала alem.worn (таблица слот -> id), запасной путь — apparel_of.
local function wearing_set(name)
  local hat, robe = false, false
  local w = alem.worn(name)
  if type(w) == "table" then
    for _, v in pairs(w) do
      if has(v, "wizard_hat") then hat = true end
      if has(v, "wizard_robe") then robe = true end
    end
  end
  if not (hat and robe) then
    for _, slot in ipairs({ "Head", "TorsoOver", "Torso", "ArmorOver" }) do
      local h = alem.apparel_of(name, slot)
      local info = h and alem.item_info(h)
      if info then
        if has(info.id, "wizard_hat") then hat = true end
        if has(info.id, "wizard_robe") then robe = true end
      end
    end
  end
  return hat and robe, hat, robe
end

-- Какой посох в руках: id оружия через weapon_of + item_info.
-- Если id прочитать не вышло, запасной путь — способности посохов (они доступны только с посохом в руках).
local function staff_in_hand(name)
  local ok, h = pcall(alem.weapon_of, name)
  if ok and h then
    local ok2, info = pcall(alem.item_info, h)
    if ok2 and type(info) == "table" and info.id then
      return STAFF_BONUS[info.id] and info.id or nil
    end
  end
  local okS, list = pcall(alem.spells, name)
  if okS and type(list) == "table" then
    for _, sp in ipairs(list) do
      local st = STAFF_BY_SPELL[sp.id]
      if st then return st end
    end
  end
  return nil
end

local BASE_MAX = 100          -- обычный максимум маны (energies.json)
local BLOOD_BONUS = 20        -- Кровь архимагов (bloodlines.json)
local bonus_now = {}         -- имя -> текущая прибавка (для полоски на экране)

local function has_blood(name)
  local ok, list = pcall(alem.bloodlines, name)
  if ok and type(list) == "table" then
    for _, id in ipairs(list) do
      if id == "arcane_blood" then return true end
    end
  end
  return false
end

local function update(name)
  local cur, mx = alem.energy(name, "mana")
  if cur == nil then return end                         -- у человека нет шкалы маны
  -- после загрузки в сейве мог остаться старый «свой максимум»: один раз сбрасываем
  if not seen[name] then
    seen[name] = true
    pcall(function() alem.energy_max(name, "mana", nil) end)
    applied[name] = nil
  end

  local full, hat, robe = wearing_set(name)
  local staff = staff_in_hand(name)
  local bonus = (full and SET_BONUS or 0) + (staff and STAFF_BONUS[staff] or 0)
  bonus_now[name] = bonus

  local state = (hat and "шляпа " or "") .. (robe and "мантия " or "") .. (staff or "")
  if logged[name] ~= state then
    logged[name] = state
    alem.log("mana: " .. name .. " надето: [" .. state .. "] бонус=" .. bonus .. ", максимум сейчас " .. tostring(mx))
  end

  if bonus > 0 then
    local want = BASE_MAX + (has_blood(name) and BLOOD_BONUS or 0) + bonus
    -- игра может сама пересчитать максимум (час, сон, загрузка) — поэтому проверяем каждый раз
    if mx == nil or math.abs(mx - want) > 0.5 then
      alem.energy_max(name, "mana", want)
      if not applied[name] then
        applied[name] = true
        pcall(function() alem.fx_text("Мана +" .. bonus, alem.pos(name)) end)
      end
      local _, nm = alem.energy(name, "mana")
      alem.log("mana: " .. name .. " максимум " .. tostring(mx) .. " -> запрошено " .. want .. ", игра показывает " .. tostring(nm))
    end
  elseif applied[name] then
    alem.energy_max(name, "mana", nil)                  -- сброс на обычный максимум
    applied[name] = nil
  end
end

-- Магическое истощение: мана упала до нуля — болезнь magic_exhaustion (diseases.json).
-- Срабатывает один раз при падении до нуля; пока мана не вернётся выше порога, повторно не заражает.
local EXHAUST_AT, RECOVER_AT = 2, 15
local drained = {}  -- имя -> true, пока мана не отросла

local function exhaustion(name)
  local cur = alem.energy(name, "mana")
  if cur == nil then return end
  if cur <= EXHAUST_AT then
    if not drained[name] then
      drained[name] = true
      pcall(function() alem.infect(name, "magic_exhaustion") end)
      pcall(function() alem.fx_text("Истощение!", alem.pos(name)) end)
      alem.log("mana: " .. name .. " истощён")
    end
  elseif cur >= RECOVER_AT then
    drained[name] = nil
  end
end

local function tick()
  for _, name in ipairs(alem.colonists()) do
    local ok, err = pcall(update, name)
    if not ok then alem.log("mana: " .. tostring(err)) end
    pcall(exhaustion, name)
  end
end

alem.every(3, function() pcall(tick) end)

-- Полоска маны на экране: мана выбранного колониста (тапните мага — внизу слева появится «Мана 57/100»).
-- Подробности есть и в карточке колониста, но полоска видна всегда.
local function hud_fn()
  local ok, text, frac = pcall(function()
    local name = alem.selected()
    if not name then return "Мана: выберите мага", 0 end
    local cur, mx = alem.energy(name, "mana")
    if cur == nil then return name .. ": нет магии", 0 end
    mx = mx or 100
    local b = bonus_now[name] or 0
    local extra = (b > 0) and (" (+" .. b .. ")") or ""
    return name .. ": мана " .. math.floor(cur + 0.5) .. "/" .. math.floor(mx + 0.5) .. extra, (mx > 0) and (cur / mx) or 0
  end)
  if ok then return text, frac end
  return "Мана", 0
end

pcall(function()
  alem.hud{ id = "arcane_mana", x = 20, y = 20, w = 280, h = 52, anchor = "bottomleft",
            bar_color = "#6FA8FF", refresh = 0.5, fn = hud_fn }
end)
