-- Магические печати: постройки 1x1, которые игрок кладёт на землю.
-- Раз в 0.5 с игра зовёт seal_tick(id, x, y, uid) (поле tick/tickFn в furniture.json).
-- Печать срабатывает ТОЛЬКО на врага (колонисты на неё не влияют), зовёт заклинание-печать
-- из spells.json (seal_*: все эффекты бьют только врагов) через alem.spell_at и исчезает.
-- Огонь и яд задевают всех в круге, поэтому, пока свой колонист рядом с точкой удара
-- (радиус safe), печать ждёт и не срабатывает.
-- Печать исцеления работает на своих: ждёт раненого колониста.
-- Всё в pcall: ошибка здесь не должна выключать скрипты мода.

local SEALS = {
  -- at: "enemy" — бить во врага, "seal" — в точку печати
  seal_fire   = { spell = "seal_fireball",  on = "enemy", trigger = 6.0, at = "enemy", safe = 3.4, text = "Огненная печать!", color = "#ff8a3d" },
  seal_frost  = { spell = "seal_frost",     on = "enemy", trigger = 3.2, at = "seal",  safe = 0,   text = "Ледяная печать!",  color = "#78c8ff" },
  seal_storm  = { spell = "seal_lightning", on = "enemy", trigger = 8.0, at = "enemy", safe = 0,   text = "Грозовая печать!", color = "#ffe45a" },
  seal_poison = { spell = "seal_poison",    on = "enemy", trigger = 5.0, at = "enemy", safe = 4.6, text = "Ядовитая печать!", color = "#8ae04a" },
  seal_heal   = { spell = "heal_wave_ii",   on = "hurt",  trigger = 3.5, at = "seal",  safe = 0,   text = "Печать исцеления!", color = "#5fe08a", hp = 60 },
}

local fired = {}  -- uid -> true: защита от двойного срабатывания до сноса постройки

-- Ближайший живой враг в радиусе r.
local function nearest_enemy(x, y, r)
  local bd, bx, by
  for _, e in ipairs(alem.enemy_list() or {}) do
    if e.x and e.y and not e.downed then
      local dx, dy = e.x - x, e.y - y
      local d = dx * dx + dy * dy
      if d <= r * r and (not bd or d < bd) then bd, bx, by = d, e.x, e.y end
    end
  end
  return bd ~= nil, bx, by
end

-- Есть ли свой колонист рядом с точкой удара (для огня и яда).
local function ally_near(x, y, r)
  if not r or r <= 0 then return false end
  local list = alem.colonists_near(x, y, r)
  return list ~= nil and #list > 0
end

function seal_tick(id, x, y, uid)
  if uid and fired[uid] then return end
  local p = SEALS[id]
  if not p then return end
  local ok, err = pcall(function()
    local go, tx, ty = false, x, y
    if p.on == "enemy" then
      local hit, ex, ey = nearest_enemy(x, y, p.trigger)
      if hit then
        if p.at == "enemy" then tx, ty = ex, ey end
        go = not ally_near(tx, ty, p.safe)   -- свой в зоне удара: ждём
      end
    elseif p.on == "hurt" then
      for _, name in ipairs(alem.colonists_near(x, y, p.trigger) or {}) do
        local hp = alem.health(name)
        if hp and hp < (p.hp or 60) then go = true; break end
      end
    end
    if go then
      if uid then fired[uid] = true end
      alem.spell_at(p.spell, tx, ty)
      alem.fx_text(p.text, x, y, p.color)
      alem.demolish(x, y)
    end
  end)
  if not ok then alem.log("seal " .. tostring(id) .. ": " .. tostring(err)) end
end
