-- Школа Рунный маг.
-- «Руна-ловушка»: руна лежит в точке и ждёт врага; когда враг подходит — взрыв.
-- «Рунная защита»: колонисты вокруг мага получают бафф rune_ward (меньше урона) на время.
-- Эффект "script" в spells.json зовёт rune_trap_cast / rune_ward_cast (кто, x, y, id).
-- Всё в pcall: ошибка здесь не должна выключать скрипты мода.

local TRAP = {
  rune_trap     = { dmg = 28, radius = 2.2, trigger = 3.4, life = 60 },
  rune_trap_ii  = { dmg = 40, radius = 2.7, trigger = 4.0, life = 90 },
  rune_trap_iii = { dmg = 55, radius = 3.2, trigger = 4.6, life = 120 },
}

local WARD = {
  rune_ward     = { radius = 4.0, hours = 1.0, cut = -0.20 },
  rune_ward_ii  = { radius = 5.0, hours = 1.5, cut = -0.30 },
  rune_ward_iii = { radius = 6.0, hours = 2.0, cut = -0.40 },
}

local STEP = 0.2

local function enemy_near(x, y, r)
  local list = alem.enemy_list() or {}
  for _, e in ipairs(list) do
    if e.x and e.y and not e.downed then
      local dx, dy = e.x - x, e.y - y
      if dx * dx + dy * dy <= r * r then return true end
    end
  end
  return false
end

local function watch(p, x, y, left)
  if left <= 0 then
    pcall(function() alem.fx("smoke", x, y, 1) end)
    return
  end
  local fire = false
  pcall(function()
    -- руну не взрываем, пока рядом свой колонист: иначе он попадёт под взрыв
    local mine = alem.colonists_near(x, y, p.radius * 0.7) or {}
    if #mine == 0 and enemy_near(x, y, p.trigger) then fire = true end
  end)
  if fire then
    pcall(function()
      alem.fx("explosion", x, y, p.radius)
      alem.damage_at(x, y, p.radius, p.dmg, "heat", "Руна")
      alem.fx_text("Руна!", x, y, "#4fd1c5")
    end)
    return
  end
  if math.floor(left / STEP + 0.5) % 5 == 0 then
    pcall(function() alem.fx_sprite("spells/rune_trap", x, y, 1.2, 0.6, "#4fd1c5", 0) end)
  end
  alem.after(STEP, function() watch(p, x, y, left - STEP) end)
end

function rune_trap_cast(who, x, y, id)
  local p = TRAP[id] or TRAP.rune_trap
  local ok, err = pcall(function()
    alem.fx_text("Руна взведена", x, y, "#4fd1c5")
    watch(p, x, y, p.life)
  end)
  if not ok then alem.log("rune trap: " .. tostring(err)) end
end

function rune_ward_cast(who, x, y, id)
  local p = WARD[id] or WARD.rune_ward
  local ok, err = pcall(function()
    local cx, cy = x, y
    if who then
      local px, py = alem.pos(who)
      if px then cx, cy = px, py end
    end
    local list, seen = {}, {}
    for _, name in ipairs(alem.colonists_near(cx, cy, p.radius) or {}) do
      if not seen[name] then seen[name] = true; table.insert(list, name) end
    end
    if who and not seen[who] then table.insert(list, who) end
    for _, name in ipairs(list) do
      alem.buff(name, "rune_ward", { damageTaken = p.cut }, p.hours)
      local nx, ny = alem.pos(name)
      alem.fx_text("Руна защиты", nx or cx, ny or cy, "#4fd1c5")
    end
    alem.fx("flash", cx, cy, p.radius)
    alem.log("rune ward: защищено " .. #list .. " чел., на " .. p.hours .. " ч.")
  end)
  if not ok then alem.log("rune ward: " .. tostring(err)) end
end
