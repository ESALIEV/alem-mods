-- Энт не бежит. Игра считает призванного энта бойцом налёта, поэтому при «Рейд отражён»
-- он получал приказ отступать вместе с рейдерами. Перебиваем этот приказ часто (каждые 0.3 с)
-- и сразу при конце налёта: пока есть чужие враги — ведём на ближайшего (в том числе
-- на убегающего); когда врагов нет — держим рядом с ближайшим колонистом.
local function is_ent(id) return type(id) == "string" and id:find("^druid_ent") ~= nil end
local function tick()
  local list = alem.enemy_list() or {}
  local people = alem.colonists() or {}
  for _, e in ipairs(list) do
    if is_ent(e.id) and e.x and e.y and not e.downed then
      local bx, by, bd
      for _, o in ipairs(list) do
        if not is_ent(o.id) and not o.downed and o.x and o.y then
          local d = (o.x - e.x) ^ 2 + (o.y - e.y) ^ 2
          if not bd or d < bd then bd, bx, by = d, o.x, o.y end
        end
      end
      if not bx then
        for _, name in ipairs(people) do
          local px, py = alem.pos(name)
          if px then
            local d = (px - e.x) ^ 2 + (py - e.y) ^ 2
            if d > 9 and (not bd or d < bd) then bd, bx, by = d, px, py end
          end
        end
      end
      if bx then
        pcall(function() alem.enemy_stop(e.h) end)
        pcall(function() alem.enemy_goto(e.h, math.floor(bx), math.floor(by), 2) end)
      end
    end
  end
end
local function safe()
  local ok, err = pcall(tick)
  if not ok then alem.log("ent_ai: " .. tostring(err)) end
end
alem.every(0.3, safe)
alem.on("on_raid_end", function() safe() end)
