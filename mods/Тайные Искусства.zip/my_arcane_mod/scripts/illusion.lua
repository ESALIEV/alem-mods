-- Школа Иллюзионист: «Кошмар» — бросается в точку, враги вокруг в панике бегут прочь.
-- Двойник (clone) и Пелена (invisible) собраны из готовых эффектов, скрипта не требуют.
-- Эффект "script" в spells.json зовёт nightmare_cast(кто, x, y, id).
-- Всё в pcall: ошибка здесь не должна выключать скрипты мода.

local NIGHTMARE = {
  nightmare     = { radius = 4.0, seconds = 6 },
  nightmare_ii  = { radius = 5.0, seconds = 8 },
  nightmare_iii = { radius = 6.0, seconds = 10 },
}

local FLEE = 10  -- на сколько клеток убегают

-- Ближайшая проходимая клетка по направлению (dx, dy) от (x, y), пробуем дальше и ближе.
local function flee_cell(x, y, dx, dy)
  local w, h = alem.map_size()
  for _, d in ipairs({ FLEE, 8, 6, 4, 2 }) do
    local tx, ty = math.floor(x + dx * d), math.floor(y + dy * d)
    if tx >= 1 and ty >= 1 and (not w or tx < w) and (not h or ty < h) and alem.walkable(tx, ty) then
      return tx, ty
    end
  end
  return nil
end

-- Паника держится весь срок: часто заново отправляем напуганных в бег,
-- иначе боевой ИИ перехватывает управление и враг возвращается в драку.
local STEP = 0.3
local scared = {}  -- h -> { x, y, left }

alem.every(STEP, function()
  pcall(function()
    for h, s in pairs(scared) do
      s.left = s.left - STEP
      if s.left <= 0 then
        scared[h] = nil
        pcall(function() alem.enemy_stop(h) end)
      else
        pcall(function() alem.enemy_goto(h, s.x, s.y, 2) end)
      end
    end
  end)
end)

function nightmare_cast(who, x, y, id)
  local p = NIGHTMARE[id] or NIGHTMARE.nightmare
  local ok, err = pcall(function()
    -- Кошмар теперь бросается в точку: центр паники — куда бросили.
    local cx, cy = x, y
    local mx, my = cx, cy  -- маг, на случай врага ровно в центре
    if who then
      local px, py = alem.pos(who)
      if px then
        mx, my = px, py
        if not cx then cx, cy = px, py end
      end
    end
    local n = 0
    alem.fx_text("Кошмар!", cx, cy, "#f060c8")
    for _, e in ipairs(alem.enemy_list() or {}) do
      if e.x and e.y and not e.downed then
        local dx, dy = e.x - cx, e.y - cy
        local dist = math.sqrt(dx * dx + dy * dy)
        if dist <= p.radius then
          if dist < 0.01 then
            dx, dy = cx - mx, cy - my
            dist = math.sqrt(dx * dx + dy * dy)
            if dist < 0.01 then dx, dy, dist = 1, 0, 1 end
          end
          local ux, uy = dx / dist, dy / dist
          local tx, ty = flee_cell(e.x, e.y, ux, uy)
          if not tx then
            for _, a in ipairs({ 0.6, -0.6, 1.2, -1.2, 2.4, -2.4 }) do
              local c, s2 = math.cos(a), math.sin(a)
              tx, ty = flee_cell(e.x, e.y, ux * c - uy * s2, ux * s2 + uy * c)
              if tx then break end
            end
          end
          if tx then
            pcall(function() alem.enemy_stop(e.h) end)
            alem.enemy_goto(e.h, tx, ty, 2)
            scared[e.h] = { x = tx, y = ty, left = p.seconds }
            alem.fx_text("Ужас!", e.x, e.y, "#f060c8")
            n = n + 1
          end
        end
      end
    end
    alem.fx("smoke", cx, cy, p.radius)
    alem.log("nightmare: напугано врагов: " .. n .. ", на " .. p.seconds .. " с")
  end)
  if not ok then alem.log("nightmare: " .. tostring(err)) end
end
