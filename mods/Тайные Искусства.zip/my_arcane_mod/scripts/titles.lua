-- ===== Летопись магов: титулы без черт =====
-- Титул зависит от числа применений способностей у колонистов с магической
-- чертой. Это не черта (они выпадали бы при генерации): титул виден в окне
-- «Летопись магов» из веера меню и даёт бонус настроения на сутки.

local MAGE_TRAITS = { "Пиромант", "Геомант", "Целитель", "Мистик", "Буревестник", "Страж", "Друид", "Хрономант", "Рунный маг", "Криомант", "Иллюзионист" }

local TITLES = {
  { name = "Ученик",  need = 15,  mood = 1 },
  { name = "Адепт",   need = 50,  mood = 2 },
  { name = "Магистр", need = 120, mood = 3 },
  { name = "Архимаг", need = 300, mood = 5 },
}

local function is_mage(who)
  for _, t in ipairs(MAGE_TRAITS) do
    if alem.has_trait(who, t) then return true end
  end
  return false
end

local function casts_of(who)
  return alem.get('casts_total_' .. who, 0)
end

local function title_index(casts)
  local idx = 0
  for i, t in ipairs(TITLES) do
    if casts >= t.need then idx = i end
  end
  return idx
end

alem.on('on_spell', function(who, spellId, x, y)
  if not is_mage(who) then return end
  local before = title_index(casts_of(who))
  local n = casts_of(who) + 1
  alem.set('casts_total_' .. who, n)
  local after = title_index(n)
  if after > before then
    local t = TITLES[after]
    alem.toast(who .. ' получает титул «' .. t.name .. '»')
    alem.say(who, t.name .. '!')
    alem.letter('Новый титул', who .. ' получает титул «' .. t.name .. '».')
  end
end)

-- Бонус за титул: воспоминание на сутки, обновляется каждое утро.
alem.on('on_day', function(day)
  for _, who in ipairs(alem.colonists()) do
    local i = title_index(casts_of(who))
    if i > 0 and is_mage(who) then
      local t = TITLES[i]
      alem.memory(who, t.mood, 1, 'Титул: ' .. t.name)
    end
  end
end)

local function rows()
  local out = {}
  for _, who in ipairs(alem.colonists()) do
    if is_mage(who) then
      local n = casts_of(who)
      local i = title_index(n)
      local title = (i > 0) and TITLES[i].name or 'без титула'
      local nxt = TITLES[i + 1]
      local tail = nxt and (' · до «' .. nxt.name .. '»: ' .. (nxt.need - n)) or ' · вершина'
      table.insert(out, who .. ' — ' .. title .. ' · применений: ' .. n .. tail)
    end
  end
  if #out == 0 then out[1] = 'Магов в колонии пока нет.' end
  return out
end

pcall(alem.menu_button, 'Летопись магов', 'chronicle_menu', function()
  alem.window{ id = 'mage_chronicle', title = 'Летопись магов', w = 1000, h = 520, pause = true,
    elements = {
      { type = 'text', id = 'hint', text = 'Титул растёт от числа применений способностей.',
        x = 30, y = 70, w = 940, h = 36, size = 22 },
      { type = 'list', id = 'mages', rows = rows(), x = 30, y = 120, w = 940, h = 370 },
    } }
end)
