-- ===== Выдача способностей магам =====
-- У заклинаний нет requires, поэтому знание выдаёт только скрипт. Раз в
-- несколько секунд каждому колонисту с чертой школы выдаётся то заклинание
-- школы, которого он не знает ни в одном из рангов. Ничего не хранится
-- в сейве: потерянное возвращается само, выученное не дублируется.
-- Всё в pcall, чтобы сбой не выключил скрипты мода.

local SCHOOLS = {
  { trait = "Пиромант",    spells = { "fireball", "flame_burst" } },
  { trait = "Геомант",     spells = { "earth_wall", "stone_ring" } },
  { trait = "Целитель",    spells = { "heal_wave", "mend" } },
  { trait = "Мистик",      spells = { "mystic_clarity", "blink", "summon_spirit" } },
  { trait = "Иллюзионист", spells = { "mirror_double", "veil", "nightmare" } },
  { trait = "Криомант",    spells = { "frost_nova", "ice_spike", "deep_freeze" } },
  { trait = "Буревестник", spells = { "lightning", "whirlwind" } },
  { trait = "Страж",       spells = { "barrier", "spirit_bolt" } },
  { trait = "Друид",       spells = { "poison_cloud", "summon_ent" } },
  { trait = "Хрономант",   spells = { "time_stop", "time_haste" } },
  { trait = "Рунный маг",  spells = { "rune_trap", "rune_ward" } },
}

-- Одна школа на колониста: если черт школ несколько (случайная генерация,
-- старые сейвы), оставляем первую по списку черт, остальные снимаем вместе с заклинаниями.
local function enforce_one_school(who)
  local have = {}
  for _, sc in ipairs(SCHOOLS) do
    if alem.has_trait(who, sc.trait) then have[#have + 1] = sc end
  end
  if #have < 2 then return end
  local keep = have[1]
  local ok, list = pcall(function() return alem.traits(who) end)
  if ok and type(list) == "table" then
    for _, t in ipairs(list) do
      local name = type(t) == "table" and (t.name or t.id) or t
      for _, sc in ipairs(have) do
        if sc.trait == name then keep = sc; goto found end
      end
    end
  end
  ::found::
  local keepSpells = {}
  for _, b in ipairs(keep.spells) do keepSpells[b] = true end
  for _, sc in ipairs(have) do
    if sc ~= keep then
      pcall(function() alem.remove_trait(who, sc.trait) end)
      for _, b in ipairs(sc.spells) do
        if not keepSpells[b] then
          for _, suf in ipairs({ "", "_ii", "_iii" }) do
            pcall(function() alem.forget(who, b .. suf) end)
          end
        end
      end
    end
  end
end

local function ensure_spells()
  for _, who in ipairs(alem.colonists()) do
    pcall(enforce_one_school, who)
    -- Ледяная волна ушла от Мистика к Криоманту: забываем её у старых мистиков
    -- (если у человека нет черты Криомант).
    -- Призыв волков заменён Призывом энта: забываем волков у друидов.
    if alem.has_trait(who, "Друид") then
      for _, id in ipairs({ "summon_wolves", "summon_wolves_ii", "summon_wolves_iii" }) do
        pcall(function() alem.forget(who, id) end)
      end
    end
    if alem.has_trait(who, "Мистик") and not alem.has_trait(who, "Криомант") then
      for _, id in ipairs({ "frost_nova", "frost_nova_ii", "frost_nova_iii" }) do
        pcall(function() alem.forget(who, id) end)
      end
    end
    for _, sc in ipairs(SCHOOLS) do
      if alem.has_trait(who, sc.trait) then
        local known = {}
        for _, sp in ipairs(alem.spells(who) or {}) do known[sp.id] = true end
        for _, base in ipairs(sc.spells) do
          if not (known[base] or known[base .. "_ii"] or known[base .. "_iii"]) then
            alem.teach(who, base)
          end
        end
      end
    end
  end
end

local function safe_ensure()
  local ok, err = pcall(ensure_spells)
  if not ok then alem.log("arcane init: " .. tostring(err)) end
end

safe_ensure()
alem.on("on_map_generated", function() safe_ensure() end)
alem.on("on_load", function() safe_ensure() end)
alem.every(3, safe_ensure)
