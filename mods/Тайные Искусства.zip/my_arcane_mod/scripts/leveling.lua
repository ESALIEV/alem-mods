-- ===== Тайные Искусства: прокачка способностей =====
-- Ранг II: после CASTS_TO_RANK_II применений базовое заклинание меняется на
-- усиленную версию "_ii" (сильнее, короче откат, сытость как у базовой).
-- Ранг III: ещё CASTS_TO_RANK_III применений версии "_ii" — и она становится
-- "_iii". На третьем ранге растёт только сила эффекта: откат и время
-- каста те же, что у ранга II, специально не сокращаются дальше.

local CASTS_TO_RANK_II = 15
local CASTS_TO_RANK_III = 20

local UPGRADE_II = {
  fireball = "fireball_ii",
  flame_burst = "flame_burst_ii",
  earth_wall = "earth_wall_ii",
  stone_ring = "stone_ring_ii",
  heal_wave = "heal_wave_ii",
  mend = "mend_ii",
  frost_nova = "frost_nova_ii",
  blink = "blink_ii",
  summon_spirit = "summon_spirit_ii",
  lightning = "lightning_ii",
  whirlwind = "whirlwind_ii",
  barrier = "barrier_ii",
  spirit_bolt = "spirit_bolt_ii",
  poison_cloud = "poison_cloud_ii",
  summon_ent = "summon_ent_ii",
  time_stop = "time_stop_ii",
  time_haste = "time_haste_ii",
  rune_trap = "rune_trap_ii",
  ice_spike = "ice_spike_ii",
  mirror_double = "mirror_double_ii",
  veil = "veil_ii",
  nightmare = "nightmare_ii",
  deep_freeze = "deep_freeze_ii",
  mystic_clarity = "mystic_clarity_ii",
  rune_ward = "rune_ward_ii",
}

local UPGRADE_III = {
  fireball_ii = "fireball_iii",
  flame_burst_ii = "flame_burst_iii",
  earth_wall_ii = "earth_wall_iii",
  stone_ring_ii = "stone_ring_iii",
  heal_wave_ii = "heal_wave_iii",
  mend_ii = "mend_iii",
  frost_nova_ii = "frost_nova_iii",
  blink_ii = "blink_iii",
  summon_spirit_ii = "summon_spirit_iii",
  lightning_ii = "lightning_iii",
  whirlwind_ii = "whirlwind_iii",
  barrier_ii = "barrier_iii",
  spirit_bolt_ii = "spirit_bolt_iii",
  poison_cloud_ii = "poison_cloud_iii",
  summon_ent_ii = "summon_ent_iii",
  time_stop_ii = "time_stop_iii",
  time_haste_ii = "time_haste_iii",
  rune_trap_ii = "rune_trap_iii",
  ice_spike_ii = "ice_spike_iii",
  mirror_double_ii = "mirror_double_iii",
  veil_ii = "veil_iii",
  nightmare_ii = "nightmare_iii",
  deep_freeze_ii = "deep_freeze_iii",
  mystic_clarity_ii = "mystic_clarity_iii",
  rune_ward_ii = "rune_ward_iii",
}

local NAMES = {
  fireball = "Огненный шар", flame_burst = "Пламенная вспышка",
  earth_wall = "Земляная стена", stone_ring = "Каменное кольцо",
  heal_wave = "Волна исцеления", mend = "Исцеляющее касание",
  frost_nova = "Ледяная волна", blink = "Мерцание",
  summon_spirit = "Призыв духа", lightning = "Молния",
  whirlwind = "Вихрь", barrier = "Барьер", spirit_bolt = "Духовный заряд",
  poison_cloud = "Ядовитое облако", summon_ent = "Призыв энта",
  time_stop = "Остановка времени", time_haste = "Ускорение времени",
  rune_trap = "Руна-ловушка", ice_spike = "Ледяной шип", mirror_double = "Зеркальный двойник", veil = "Пелена", nightmare = "Кошмар", deep_freeze = "Глубокая заморозка", mystic_clarity = "Просветление", rune_ward = "Рунная защита",
}

local function base_name(spellId)
  local base = spellId:gsub('_ii$', ''):gsub('_iii$', '')
  return NAMES[base] or base
end

alem.on('on_spell', function(who, castId, x, y)
  -- копия с суффиксом _h (маг в колпаке) считается той же способностью
  local spellId = (castId:gsub('_h$', ''))
  local nextII = UPGRADE_II[spellId]
  if nextII then
    local key = 'rankxp_' .. who .. '_' .. spellId
    local casts = alem.get(key, 0) + 1
    alem.set(key, casts)

    if casts >= CASTS_TO_RANK_II then
      alem.forget(who, castId)
      alem.teach(who, nextII)
      alem.memory(who, 5, 1, 'Освоил ' .. base_name(spellId) .. ' в совершенстве')
      alem.letter('Мастерство растёт', who .. ' довёл способность «' .. base_name(spellId) .. '» до второго ранга — сильнее и быстрее перезаряжается.')
    end
    return
  end

  local nextIII = UPGRADE_III[spellId]
  if nextIII then
    local key = 'rankxp3_' .. who .. '_' .. spellId
    local casts = alem.get(key, 0) + 1
    alem.set(key, casts)

    if casts >= CASTS_TO_RANK_III then
      alem.forget(who, castId)
      alem.teach(who, nextIII)
      alem.memory(who, 7, 1, 'Постиг ' .. base_name(spellId) .. ' в высшей форме')
      alem.letter('Вершина мастерства', who .. ' довёл способность «' .. base_name(spellId) .. '» до третьего ранга — мощнее прежнего, откат тот же.')
    end
  end
end)
