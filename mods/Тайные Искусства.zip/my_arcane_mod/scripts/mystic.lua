-- Школа Мистик: «Просветление» — бафф колонистам вокруг мага (работа, меткость, настроение).
-- Эффект "script" в spells.json зовёт mystic_clarity_cast(кто, x, y, id).
-- Центр — сам маг; всё в pcall, чтобы ошибка не выключила скрипты мода.

local CLARITY = {
  mystic_clarity     = { radius = 5.0, hours = 2, work = 0.15, aim = 0.2, mood = 2 },
  mystic_clarity_ii  = { radius = 6.0, hours = 3, work = 0.25, aim = 0.3, mood = 3 },
  mystic_clarity_iii = { radius = 7.0, hours = 4, work = 0.35, aim = 0.4, mood = 4 },
}

function mystic_clarity_cast(who, x, y, id)
  local p = CLARITY[id] or CLARITY.mystic_clarity
  local ok, err = pcall(function()
    local cx, cy = x, y
    if who then
      local px, py = alem.pos(who)
      if px then cx, cy = px, py end
    end
    local list, seen = {}, {}
    for _, name in ipairs(alem.colonists_near(cx, cy, p.radius) or {}) do
      if not seen[name] then seen[name] = true; table.insert(list, name) end
    end
    if who and not seen[who] then table.insert(list, who) end
    for _, name in ipairs(list) do
      alem.buff(name, "mystic_clarity", { workSpeed = p.work, aim = p.aim, mood = p.mood }, p.hours)
      local nx, ny = alem.pos(name)
      alem.fx_text("Просветление", nx or cx, ny or cy, "#b48cff")
    end
    alem.fx("flash", cx, cy, p.radius)
    alem.log("mystic clarity: " .. #list .. " чел., на " .. p.hours .. " ч.")
  end)
  if not ok then alem.log("mystic clarity: " .. tostring(err)) end
end
