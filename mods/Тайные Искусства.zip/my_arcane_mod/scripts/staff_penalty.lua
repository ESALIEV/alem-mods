-- ===== Штрафы: посох в руках у не-мага и тоска мага по магии =====

local MAGE_TRAITS = { "Пиромант", "Геомант", "Целитель", "Мистик", "Буревестник", "Страж", "Друид", "Хрономант", "Рунный маг", "Криомант", "Иллюзионист" }
local STAFF_SPELLS = { staff_light = true, spark_bolt = true, divine_wrath = true }

local function is_mage(who)
  for _, t in ipairs(MAGE_TRAITS) do
    if alem.has_trait(who, t) then return true end
  end
  return false
end

local function stamp()
  return alem.day() * 24 + alem.hour()
end

-- Скрипту неоткуда узнать, какое оружие в руках, зато способности посохов
-- работают только с ним. Значит, применил их — держит посох.
alem.on('on_spell', function(who, spellId, x, y)
  alem.set('lastcast_' .. who, stamp())

  if STAFF_SPELLS[spellId] and not is_mage(who) then
    local last = alem.get('backlash_' .. who, -100)
    if stamp() - last >= 2 then
      alem.set('backlash_' .. who, stamp())
      alem.memory(who, -8, 1, 'Посох жжёт руки')
      alem.need(who, 'rest', math.max(0, alem.need(who, 'rest') - 25))
      alem.say(who, 'Ай! Посох обжигает...')
    end
  end
end)

-- Маг, не колдовавший больше суток, тоскует: -10 к настроению на день.
alem.every_hours(1, function()
  local now = stamp()
  for _, who in ipairs(alem.colonists()) do
    if is_mage(who) then
      local last = alem.get('lastcast_' .. who, -1)
      if last < 0 then
        alem.set('lastcast_' .. who, now)
      elseif now - last > 24 then
        local pen = alem.get('longing_' .. who, -100)
        if now - pen >= 24 then
          alem.set('longing_' .. who, now)
          alem.memory(who, -10, 1, 'Тоска по магии')
        end
      end
    end
  end
end)

-- ===== Бонус: в колонии есть маг — всем спокойнее (+4) =====
local function any_mage()
  for _, who in ipairs(alem.colonists()) do
    if is_mage(who) then return true end
  end
  return false
end

local mage_was_present = false

alem.on('on_day', function(day)
  if any_mage() then alem.mood_all(4, 1, 'В колонии есть маг') end
end)

-- маг появился посреди суток — бонус сразу, а не со следующего утра
alem.every_hours(1, function()
  local present = any_mage()
  if present and not mage_was_present then
    alem.mood_all(4, 1, 'В колонии есть маг')
  end
  mage_was_present = present
end)
