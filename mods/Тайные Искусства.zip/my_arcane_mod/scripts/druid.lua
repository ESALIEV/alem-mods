-- Школа Друид: ядовитое облако держится в точке и травит всех в радиусе по тикам.
-- Эффект "script" в spells.json зовёт poison_cloud_cast(кто, x, y, id).
-- Всё в pcall: ошибка здесь не должна выключать скрипты мода (три подряд — и они отключаются).

local CLOUD = {
  poison_cloud     = { ticks = 6, every = 1.5, dmg = 3, radius = 3.2 },
  poison_cloud_ii  = { ticks = 8, every = 1.5, dmg = 4, radius = 3.8 },
  poison_cloud_iii = { ticks = 10, every = 1.5, dmg = 5, radius = 4.3 },
  seal_poison      = { ticks = 8, every = 1.5, dmg = 4, radius = 3.8, enemies_only = true },
}

local function tick(p, x, y, left)
  if left <= 0 then return end
  pcall(function()
    if p.enemies_only then
      -- печать: травим только врагов, бьём маленьким кругом вокруг каждого
      for _, e in ipairs(alem.enemy_list() or {}) do
        if e.x and e.y and not e.downed then
          local dx, dy = e.x - x, e.y - y
          if dx * dx + dy * dy <= p.radius * p.radius then
            alem.damage_at(e.x, e.y, 0.6, p.dmg, "sharp", "Яд")
          end
        end
      end
    else
      alem.damage_at(x, y, p.radius, p.dmg, "sharp", "Яд")
    end
    alem.fx("smoke", x, y, p.radius)
  end)
  alem.after(p.every, function() tick(p, x, y, left - 1) end)
end

function poison_cloud_cast(who, x, y, id)
  local p = CLOUD[id] or CLOUD.poison_cloud
  local ok, err = pcall(function() tick(p, x, y, p.ticks) end)
  if not ok then alem.log("druid poison: " .. tostring(err)) end
end
