-- ===== Тайные Искусства: кристаллы =====
-- Кристалл не ждёт удачного трейта при генерации колониста: расходуете его —
-- любой колонист получает школу магии целиком, через alem.teach (requires у спелла игнорируется).

local CRYSTALS = {
  { key = "Crystal_Pyro",   name = "Кристалл Пироманта",     trait = "Пиромант",     spells = { "fireball", "flame_burst" } },
  { key = "Crystal_Geo",    name = "Кристалл Геоманта",      trait = "Геомант",      spells = { "earth_wall", "stone_ring" } },
  { key = "Crystal_Heal",   name = "Кристалл Целителя",      trait = "Целитель",     spells = { "heal_wave", "mend" } },
  { key = "Crystal_Mystic", name = "Кристалл Мистика",       trait = "Мистик",       spells = { "mystic_clarity", "blink", "summon_spirit" } },
  { key = "Crystal_Illusion", name = "Кристалл Иллюзиониста", trait = "Иллюзионист", spells = { "mirror_double", "veil", "nightmare" } },
  { key = "Crystal_Cryo",   name = "Кристалл Криоманта",     trait = "Криомант",     spells = { "frost_nova", "ice_spike", "deep_freeze" } },
  { key = "Crystal_Storm",  name = "Кристалл Буревестника",  trait = "Буревестник",  spells = { "lightning", "whirlwind" } },
  { key = "Crystal_Guard",  name = "Кристалл Стража",        trait = "Страж",        spells = { "barrier", "spirit_bolt" } },
  { key = "Crystal_Druid",  name = "Кристалл Друида",        trait = "Друид",        spells = { "poison_cloud", "summon_ent" } },
  { key = "Crystal_Chrono", name = "Кристалл Хроманта",      trait = "Хрономант",    spells = { "time_stop", "time_haste" } },
  { key = "Crystal_Rune",   name = "Кристалл Рунного мага",  trait = "Рунный маг",   spells = { "rune_trap", "rune_ward" } },
}

-- Разум держит только одну школу магии — свою от рождения или полученную кристаллом.
local function already_a_mage(who)
  for _, c in ipairs(CRYSTALS) do
    if alem.has_trait(who, c.trait) then return true end
  end
  return false
end

local function teach_school(who, c)
  for _, spellId in ipairs(c.spells) do
    alem.teach(who, spellId)
  end
  if not alem.has_trait(who, c.trait) then
    alem.add_trait(who, c.trait)
  end
  alem.set('mage_init_' .. who .. '_' .. c.trait, 1)
  alem.memory(who, 6, 1, 'Раскрыл силу кристалла')
  alem.letter('Обучение завершено', who .. ' раскрывает силу: ' .. c.name .. '.')
end

local function any_crystal_in_stock()
  for _, c in ipairs(CRYSTALS) do
    if alem.resource(c.key) > 0 then return true end
  end
  return false
end

-- Окно alem.dialog вмещает около пяти кнопок: остальные уезжают за край экрана
-- (так пропадали Страж и Друид). Поэтому длинные списки листаем по 3 пункта (+ «Назад» и «Дальше» = 5 кнопок).
local PAGE = 3

local function paged_dialog(title, text, items, on_pick, page)
  page = page or 1
  local pages = math.max(1, math.ceil(#items / PAGE))
  if page > pages then page = pages end
  local first = (page - 1) * PAGE + 1
  local labels, map = {}, {}
  for i = first, math.min(#items, first + PAGE - 1) do
    table.insert(labels, items[i].label)
    map[#labels] = i
  end
  local prev_i, next_i
  if page > 1 then table.insert(labels, '◀ Назад'); prev_i = #labels end
  if page < pages then table.insert(labels, 'Дальше ▶'); next_i = #labels end
  local head = pages > 1 and (text .. '  (стр. ' .. page .. '/' .. pages .. ')') or text

  alem.dialog(title, head, labels, function(n)
    if n == prev_i then return paged_dialog(title, text, items, on_pick, page - 1) end
    if n == next_i then return paged_dialog(title, text, items, on_pick, page + 1) end
    local idx = map[n]
    if idx then on_pick(items[idx].value) end
  end)
end

local function open_crystal_menu()
  if not any_crystal_in_stock() then
    alem.letter('Нет кристаллов', 'На складе нет ни одного кристалла. Создайте их на магическом верстаке (технология «Тайнопись»).')
    return
  end
  local items = {}
  for _, c in ipairs(CRYSTALS) do
    local n = alem.resource(c.key)
    if n > 0 then
      table.insert(items, { label = c.name .. ' (' .. n .. ')', value = c })
    end
  end

  paged_dialog('Использовать кристалл', 'Какую школу магии раскрываем?', items, function(c)
    if alem.resource(c.key) < 1 then
      alem.letter('Нет кристалла', 'На складе нет ни одного: ' .. c.name .. '.')
      return
    end

    local eligible = {}
    for _, name in ipairs(alem.colonists()) do
      if not already_a_mage(name) then table.insert(eligible, { label = name, value = name }) end
    end

    if #eligible == 0 then
      alem.letter('Некому', 'Каждый ваш колонист уже связан со своей школой магии — разум держит только одну.')
      return
    end

    paged_dialog('Кто получает силу?', 'Выберите колониста для ' .. c.name, eligible, function(who)
      if already_a_mage(who) then
        alem.letter('Разум уже связан', who .. ' уже владеет магией и не может принять ещё одну школу.')
        return
      end
      if alem.resource(c.key) < 1 then return end
      alem.take(c.key, 1)
      teach_school(who, c)
    end)
  end)
end


-- Кнопка стоит в веере меню и видна всегда (раньше пряталась при пустом складе).
-- Вызов в pcall: ошибка интерфейса не должна выключать скрипты мода.
local function safe(f, ...)
  local ok, err = pcall(f, ...)
  if not ok then alem.log('arcane crystals: ' .. tostring(err)) end
end

safe(function() alem.menu_button('Кристалл', 'crystal_menu', open_crystal_menu) end)
safe(function() alem.button_hide('Кристалл', false) end)
