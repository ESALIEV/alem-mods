-- Online Market 7.1 | Alem 0.25.01
-- Категории, только товары с ценой, русские имена, пагинация, pcall
-- 7.1: ✕ Закрыть всегда полностью выходит из маркета

local P = 'om_'

local open_market, menu_buy_cats, menu_buy_list, menu_buy_qty, confirm_buy
local menu_sell_list, menu_exchange, rebuild_catalog

local function get(k, d)
    local ok, v = pcall(function()
        if alem.get then return alem.get(P .. k) end
    end)
    if ok and v ~= nil then return v end
    return d
end

local function set(k, v)
    pcall(function()
        if alem.set then alem.set(P .. k, v) end
    end)
end

local function log(msg)
    pcall(alem.log, '[MARKET] ' .. tostring(msg))
end

if get('tokens', 0) == 0 then set('tokens', 0) end

local BUY_MARKUP    = 1.25
local SELL_RATE     = 0.50
local DELIVERY_RISK = 0.02
local REFUND_RATE   = 0.50

-- ================= УТИЛИТЫ =================
local function stock_count(id)
    local ok, v = pcall(alem.resource, id)
    if ok and type(v) == 'number' then return math.max(0, math.floor(v)) end
    if ok and type(v) == 'table' then
        return math.max(0, math.floor(tonumber(v.count or v.amount or 0) or 0))
    end
    return 0
end

local function take_resource(id, qty)
    local before = stock_count(id)
    if before < qty then return false end
    local ok, result = pcall(alem.take, id, qty)
    if not ok or result == false then return false end
    local after = stock_count(id)
    if after > before - qty then return false end
    return true
end

local function spawn_at_center(id, qty)
    local ok, cx, cy = pcall(alem.colony_center)
    if not ok or type(cx) ~= 'number' or type(cy) ~= 'number' then
        local size_ok, w, h = pcall(alem.map_size)
        if not size_ok then return false end
        cx, cy = math.floor(w / 2), math.floor(h / 2)
    end
    cx, cy = math.floor(cx), math.floor(cy)
    local offsets = {
        {0,0},{1,0},{0,1},{-1,0},{0,-1},{1,1},{-1,1},{1,-1},{-1,-1},
        {2,0},{0,2},{-2,0},{0,-2},{2,1},{1,2},{-2,1},{-1,2}
    }
    for _, offset in ipairs(offsets) do
        local x, y = cx + offset[1], cy + offset[2]
        local placed, result = pcall(alem.spawn_item, id, qty, x, y)
        if placed and result ~= false then return true end
    end
    return false
end

local MARKS_ID = 'ImperialMark'
if stock_count('ImperialMark') == 0 and stock_count('Mark') > 0 then
    MARKS_ID = 'Mark'
end

-- ================= СЛОВАРЬ: русские имена + базовые цены =================
-- value > 0 обязательно. Нет value и нет записи здесь → товар НЕ продаётся в магазине.
local FALLBACK = {
    -- Еда
    Food={name="Сухпаёк",base=10,cat="food"}, MealSimple={name="Простое блюдо",base=15,cat="food"},
    MealFine={name="Сытное блюдо",base=25,cat="food"}, MealBurnt={name="Пригоревшее блюдо",base=5,cat="food"},
    Pemmican={name="Пеммикан",base=20,cat="food"}, Meat={name="Мясо",base=12,cat="food"},
    Fish={name="Рыба",base=11,cat="food"}, Raspberry={name="Малина",base=8,cat="food"},
    Rice={name="Рис",base=9,cat="food"}, Potato={name="Картофель",base=7,cat="food"},
    Venison={name="Оленина",base=14,cat="food"}, WolfMeat={name="Волчатина",base=13,cat="food"},
    RabbitMeat={name="Крольчатина",base=11,cat="food"}, HorseMeat={name="Конина",base=12,cat="food"},
    -- Материалы
    Wood={name="Дерево",base=4,cat="mat"}, Stone={name="Камень",base=3,cat="mat"},
    Steel={name="Сталь",base=30,cat="mat"}, Iron={name="Железо",base=22,cat="mat"},
    Copper={name="Медь",base=18,cat="mat"}, Bronze={name="Бронза",base=28,cat="mat"},
    Coal={name="Уголь",base=8,cat="mat"}, Cloth={name="Ткань",base=14,cat="mat"},
    Leather={name="Кожа",base=16,cat="mat"}, Fur={name="Мех",base=18,cat="mat"},
    Planks={name="Доски",base=7,cat="mat"}, Glass={name="Стекло",base=20,cat="mat"},
    Silver={name="Серебро",base=50,cat="mat"}, Gold={name="Золото",base=120,cat="mat"},
    LimestoneChunk={name="Обломок известняка",base=2,cat="mat"}, GraniteChunk={name="Обломок гранита",base=2,cat="mat"},
    LimestoneBlock={name="Блоки известняка",base=5,cat="mat"}, GraniteBlock={name="Блоки гранита",base=5,cat="mat"},
    IronOre={name="Железная руда",base=10,cat="mat"}, CopperOre={name="Медная руда",base=9,cat="mat"},
    LeadOre={name="Свинцовая руда",base=8,cat="mat"}, Lead={name="Свинец",base=14,cat="mat"},
    Sulfur={name="Сера",base=12,cat="mat"}, Gunpowder={name="Порох",base=15,cat="mat"},
    IronComponent={name="Железный компонент",base=35,cat="mat"}, Gears={name="Шестерни",base=40,cat="mat"},
    Springs={name="Пружины",base=25,cat="mat"}, PreciseParts={name="Точные детали",base=55,cat="mat"},
    Rivets={name="Заклёпки",base=8,cat="mat"}, Bolts={name="Болты",base=6,cat="mat"},
    SteelMechanism={name="Стальной механизм",base=45,cat="mat"},
    -- Медицина
    Medicine={name="Медикаменты",base=60,cat="med"}, Herbs={name="Лечебные травы",base=6,cat="med"},
    Antibiotics={name="Антибиотик",base=80,cat="med"},
    -- Боеприпасы
    Ammo={name="Патроны",base=5,cat="ammo"}, MusketBall={name="Мушкетные пули",base=6,cat="ammo"},
    AmmoSmokeless={name="Патроны бездымные",base=7,cat="ammo"}, Arrow={name="Стрелы",base=3,cat="ammo"},
    CannonBall={name="Ядра",base=20,cat="ammo"}, Grapeshot={name="Картечь",base=18,cat="ammo"},
}

local EXCLUDE = {
    ImperialMark=true, Mark=true, Ash=true, Corpse=true
}

local VANILLA_IDS = {}
for id,_ in pairs(FALLBACK) do VANILLA_IDS[id] = true end

-- ================= КАТАЛОГ =================
local catalog = {}
local catalog_built = false

local function try_get_value(id)
    local ok, v = pcall(alem.resource, id)
    if ok and type(v) == 'table' then
        local val = tonumber(v.value or v.price or v.base)
        if val and val > 0 then return math.floor(val) end
    end
    return nil
end

local function try_get_name(id)
    local ok, v = pcall(alem.resource, id)
    if ok and type(v) == 'table' then
        local n = v.nameRu or v.name or v.displayName
        if type(n) == 'string' and n ~= '' and n ~= id then return n end
    end
    return nil
end

local function guess_cat(id)
    local low = string.lower(id)
    if FALLBACK[id] and FALLBACK[id].cat then return FALLBACK[id].cat end
    if low:find('meal') or low:find('food') or low:find('meat') or low:find('fish')
        or low:find('rice') or low:find('berry') or low:find('potato') or low:find('pemmican') then
        return 'food'
    end
    if low:find('medicine') or low:find('herb') or low:find('antibiotic') or low:find('med')
        or low:find('bandage') or low:find('drug') then
        return 'med'
    end
    if low:find('ammo') or low:find('bullet') or low:find('arrow') or low:find('shell')
        or low:find('cannon') or low:find('grape') or low:find('powder') then
        return 'ammo'
    end
    if low:find('steel') or low:find('iron') or low:find('wood') or low:find('stone')
        or low:find('cloth') or low:find('leather') or low:find('gold') or low:find('silver')
        or low:find('component') or low:find('gear') or low:find('plank') or low:find('glass') then
        return 'mat'
    end
    return 'mod'
end

local function collect_ids(raw)
    local ids, seen = {}, {}
    if type(raw) ~= 'table' then return ids end
    for i, v in ipairs(raw) do
        if type(v) == 'string' and v ~= '' and not seen[v] then
            seen[v] = true
            ids[#ids + 1] = v
        elseif type(v) == 'table' then
            local id = v.id or v.Id or v.name
            if type(id) == 'string' and id ~= '' and not seen[id] then
                seen[id] = true
                ids[#ids + 1] = id
            end
        end
    end
    for k, v in pairs(raw) do
        if type(k) == 'string' and not seen[k] and type(v) ~= 'function' and not tonumber(k) then
            seen[k] = true
            ids[#ids + 1] = k
        end
    end
    return ids
end

rebuild_catalog = function()
    catalog = {}
    local seen = {}

    local ok, raw = pcall(alem.ids, "resources")
    local from_ids = {}
    if ok then from_ids = collect_ids(raw) end

    for _, id in ipairs(from_ids) do
        if not EXCLUDE[id] and not seen[id] then
            seen[id] = true
            local game_val = try_get_value(id)
            local fb = FALLBACK[id]
            local base = game_val or (fb and fb.base) or nil
            -- ЖЁСТКОЕ ПРАВИЛО: нет цены → не в каталог покупки
            if base and base > 0 then
                local name = try_get_name(id) or (fb and fb.name) or id
                local cat = guess_cat(id)
                local is_mod = not VANILLA_IDS[id]
                catalog[#catalog + 1] = {
                    id = id, name = name, base = base, cat = cat, is_mod = is_mod
                }
            end
        end
    end

    -- Добиваем известным FALLBACK, если ids что-то пропустил
    for id, data in pairs(FALLBACK) do
        if not EXCLUDE[id] and not seen[id] and data.base and data.base > 0 then
            seen[id] = true
            catalog[#catalog + 1] = {
                id = id, name = data.name, base = data.base, cat = data.cat or 'mat', is_mod = false
            }
        end
    end

    table.sort(catalog, function(a, b)
        return (a.name or a.id) < (b.name or b.id)
    end)

    catalog_built = true
    log('Catalog: ' .. #catalog .. ' items with price (ids ok=' .. tostring(ok) .. ')')
end

local function filter_catalog(cat)
    if not cat or cat == 'all' then return catalog end
    local out = {}
    for _, item in ipairs(catalog) do
        if cat == 'mod' then
            if item.is_mod then out[#out + 1] = item end
        elseif item.cat == cat then
            out[#out + 1] = item
        end
    end
    return out
end

-- ================= ПАГИНАЦИЯ (макс 5 кнопок) =================
-- on_back = «← Назад» (категории / меню)
-- «✕ Закрыть» ВСЕГДА полностью закрывает маркет (ничего не открывает)
local function paged_dialog(title, message, options, callback, on_back)
    if #options == 0 then
        alem.dialog(title, message, {"✕ Закрыть"}, function() end)
        return
    end

    if #options <= 3 then
        local labels = {}
        for i, t in ipairs(options) do labels[i] = t end
        if on_back then labels[#labels + 1] = "← Назад" end
        labels[#labels + 1] = "✕ Закрыть"
        local n_items = #options
        alem.dialog(title, message, labels, function(selected)
            if type(selected) ~= 'number' then return end
            if selected <= n_items then
                callback(selected)
            elseif on_back and selected == n_items + 1 then
                on_back()
            end
        end)
        return
    end

    local total = math.ceil(#options / 2)

    local function show(p)
        if p < 1 then p = 1 end
        if p > total then p = total end
        local first = (p - 1) * 2 + 1
        local labels, indices = {}, {}

        for i = first, math.min(first + 1, #options) do
            labels[#labels + 1] = options[i]
            indices[#labels] = i
        end
        if p > 1 then
            labels[#labels + 1] = "← Назад"
            indices[#labels] = "prev"
        elseif on_back then
            labels[#labels + 1] = "← Назад"
            indices[#labels] = "back"
        end
        if p < total then
            labels[#labels + 1] = "Далее →"
            indices[#labels] = "next"
        end
        labels[#labels + 1] = "✕ Закрыть"
        indices[#labels] = "close"

        while #labels > 5 do
            table.remove(labels, #labels - 1)
            table.remove(indices, #indices - 1)
        end

        alem.dialog(title .. " — " .. p .. "/" .. total, message, labels, function(selected)
            if type(selected) ~= 'number' then return end
            local action = indices[selected]
            if action == "prev" then
                show(p - 1)
            elseif action == "next" then
                show(p + 1)
            elseif action == "back" then
                if on_back then on_back() end
            elseif action == "close" then
                return
            elseif type(action) == "number" then
                callback(action)
            end
        end)
    end
    show(1)
end

-- ================= ГЛАВНОЕ МЕНЮ =================
open_market = function()
    if not catalog_built then rebuild_catalog() end
    local tokens = get('tokens', 0)
    local marks  = stock_count(MARKS_ID)
    local msg = "Токены: " .. tokens .. " TKN\nМарки (" .. MARKS_ID .. "): " .. marks
              .. "\nТоваров с ценой: " .. #catalog

    alem.dialog("Маркет", msg, {
        "1. Купить",
        "2. Продать",
        "3. Обмен",
        "4. Обновить каталог",
        "5. Закрыть"
    }, function(c)
        if c == 1 then menu_buy_cats()
        elseif c == 2 then menu_sell_list()
        elseif c == 3 then menu_exchange()
        elseif c == 4 then
            catalog_built = false
            rebuild_catalog()
            alem.dialog("Каталог", "Обновлено. Товаров с ценой: " .. #catalog, {"ОК"}, open_market)
        end
    end)
end

-- ================= КАТЕГОРИИ ПОКУПКИ (макс 5 кнопок) =================
menu_buy_cats = function()
    if not catalog_built then rebuild_catalog() end
    local tokens = get('tokens', 0)
    alem.dialog("Категория", "Баланс: " .. tokens .. " TKN", {
        "Еда",
        "Материалы",
        "Медицина",
        "Ещё →",
        "✕ Закрыть"
    }, function(c)
        if c == 1 then menu_buy_list('food')
        elseif c == 2 then menu_buy_list('mat')
        elseif c == 3 then menu_buy_list('med')
        elseif c == 4 then
            alem.dialog("Категория", "Баланс: " .. tokens .. " TKN", {
                "Боеприпасы",
                "Модовые",
                "Всё",
                "← Назад",
                "✕ Закрыть"
            }, function(c2)
                if c2 == 1 then menu_buy_list('ammo')
                elseif c2 == 2 then menu_buy_list('mod')
                elseif c2 == 3 then menu_buy_list('all')
                elseif c2 == 4 then menu_buy_cats()
                end
                -- c2 == 5 или иное → полный выход
            end)
        end
        -- c == 5 → полный выход
    end)
end

menu_buy_list = function(cat)
    local list = filter_catalog(cat)
    local tokens = get('tokens', 0)
    if #list == 0 then
        alem.dialog("Каталог", "В этой категории нет товаров с ценой.", {
            "← Категории", "✕ Закрыть"
        }, function(c)
            if c == 1 then menu_buy_cats() end
        end)
        return
    end
    local opts = {}
    for _, item in ipairs(list) do
        local price = math.floor(item.base * BUY_MARKUP)
        opts[#opts + 1] = item.name .. " — " .. price .. " TKN"
    end
    -- ← Назад = категории; ✕ Закрыть = полный выход из маркета
    paged_dialog("Каталог", "Баланс: " .. tokens .. " TKN  |  " .. #list .. " тов.", opts,
        function(idx)
            menu_buy_qty(list[idx], cat)
        end,
        menu_buy_cats
    )
end

menu_buy_qty = function(item, cat)
    cat = cat or item.cat or 'all'
    local base_price = math.floor(item.base * BUY_MARKUP)
    local p1, p5, p10 = base_price, base_price * 5, base_price * 10
    local tokens = get('tokens', 0)
    alem.dialog("Выбор: " .. item.name, "Баланс: " .. tokens .. " TKN", {
        "Купить 1 шт. (" .. p1 .. " TKN)",
        "Купить 5 шт. (" .. p5 .. " TKN)",
        "Купить 10 шт. (" .. p10 .. " TKN)",
        "✕ Назад"
    }, function(c)
        if c == 1 then confirm_buy(item, 1, p1, cat)
        elseif c == 2 then confirm_buy(item, 5, p5, cat)
        elseif c == 3 then confirm_buy(item, 10, p10, cat)
        else menu_buy_list(cat) end
    end)
end

confirm_buy = function(item, qty, total_price, cat)
    cat = cat or item.cat or 'all'
    alem.dialog("Подтверждение",
                item.name .. " x" .. qty .. "\nЦена: " .. total_price .. " TKN\nРиск: 2%",
                {"✓ Купить", "Отмена"}, function(c)
        if c ~= 1 then menu_buy_list(cat); return end
        if get('tokens', 0) < total_price then
            alem.dialog("Ошибка", "Недостаточно токенов!", {"ОК"}, function() menu_buy_list(cat) end)
            return
        end
        set('tokens', get('tokens', 0) - total_price)
        if math.random() < DELIVERY_RISK then
            local refund = math.floor(total_price * REFUND_RATE)
            set('tokens', get('tokens', 0) + refund)
            pcall(alem.spawn_item, "Ash", 1)
            alem.letter("Маркет", "Посылка потеряна! Возврат: " .. refund .. " TKN")
            alem.dialog("Провал!", "Посылка потеряна!\nВозврат: " .. refund .. " TKN",
                        {"ОК"}, function() menu_buy_list(cat) end)
        else
            if spawn_at_center(item.id, qty) then
                alem.letter("Маркет", "Доставлено: " .. item.name .. " x" .. qty)
                alem.dialog("Успех!", item.name .. " x" .. qty .. " доставлен!",
                            {"ОК"}, function() menu_buy_list(cat) end)
            else
                set('tokens', get('tokens', 0) + total_price)
                alem.letter("Маркет", "Ошибка доставки: нет места. Оплата возвращена.")
                alem.dialog("Ошибка", "Нет места. Оплата возвращена.",
                            {"ОК"}, function() menu_buy_list(cat) end)
            end
        end
    end)
end


-- ================= ПРОДАЖА =================
menu_sell_list = function()
    if not catalog_built then rebuild_catalog() end
    local tokens = get('tokens', 0)
    local sellable, opts = {}, {}
    for _, item in ipairs(catalog) do
        local qty = stock_count(item.id)
        if qty > 0 then
            local price = math.floor(item.base * SELL_RATE) * qty
            sellable[#sellable + 1] = { item = item, qty = qty, total = price }
            opts[#opts + 1] = item.name .. " x" .. qty .. " → +" .. price .. " TKN"
        end
    end
    if #sellable == 0 then
        alem.dialog("Продажа", "Нет ресурсов на складе (с ценой).", {"Назад"}, open_market)
        return
    end
    paged_dialog("Продажа", "Баланс: " .. tokens .. " TKN  |  " .. #sellable .. " поз.", opts,
        function(idx)
            local data = sellable[idx]
            alem.dialog("Подтверждение",
                        "Продать " .. data.qty .. " ед. за " .. data.total .. " TKN?",
                        {"✓ Продать", "✕ Отмена"}, function(cc)
                if cc == 1 then
                    if take_resource(data.item.id, data.qty) then
                        set('tokens', get('tokens', 0) + data.total)
                        alem.letter("Маркет", "Продано: " .. data.item.name .. " x" .. data.qty
                                              .. " за " .. data.total .. " TKN")
                        alem.dialog("Успех!", "+ " .. data.total .. " TKN",
                                    {"ОК"}, menu_sell_list)
                    else
                        alem.dialog("Ошибка", "Не удалось забрать ресурс. Он в зоне склада?",
                                    {"ОК"}, menu_sell_list)
                    end
                else
                    menu_sell_list()
                end
            end)
        end,
        open_market
    )
end

-- ================= ОБМЕН МАРОК =================
menu_exchange = function()
    local tokens = get('tokens', 0)
    local marks = stock_count(MARKS_ID)
    alem.dialog("Обмен", "Токены: " .. tokens .. "\nМарки: " .. marks, {
        "100 марок → 80 TKN",
        "500 марок → 420 TKN",
        "1000 марок → 900 TKN",
        "50 TKN → 40 марок",
        "← Назад"
    }, function(c)
        if c == 5 or c == nil then open_market(); return end
        local need_m, give_t, need_t, give_m = 0, 0, 0, 0
        if c == 1 then need_m, give_t = 100, 80
        elseif c == 2 then need_m, give_t = 500, 420
        elseif c == 3 then need_m, give_t = 1000, 900
        elseif c == 4 then need_t, give_m = 50, 40 end

        if need_m > 0 then
            if marks < need_m then
                alem.dialog("Ошибка", "Недостаточно марок!", {"ОК"}, menu_exchange)
                return
            end
            if take_resource(MARKS_ID, need_m) then
                set('tokens', tokens + give_t)
                alem.dialog("Готово", "+" .. give_t .. " TKN", {"ОК"}, menu_exchange)
            else
                alem.dialog("Ошибка", "Не удалось забрать марки.", {"ОК"}, menu_exchange)
            end
        elseif need_t > 0 then
            if tokens < need_t then
                alem.dialog("Ошибка", "Недостаточно токенов!", {"ОК"}, menu_exchange)
                return
            end
            set('tokens', tokens - need_t)
            if spawn_at_center(MARKS_ID, give_m) then
                alem.dialog("Готово", "+" .. give_m .. " марок", {"ОК"}, menu_exchange)
            else
                set('tokens', get('tokens', 0) + need_t)
                alem.dialog("Ошибка", "Нет места для марок.", {"ОК"}, menu_exchange)
            end
        end
    end)
end

-- ================= РЕГИСТРАЦИЯ КНОПКИ (как в рабочей 6.5) =================
local registered = false
local function register_button()
    if registered then return end
    if type(alem.menu_button) == 'function' then
        local ok, result = pcall(alem.menu_button, "Маркет", "market_button", open_market)
        if ok and result ~= false then registered = true; return end
        ok, result = pcall(alem.menu_button, "Маркет", "Electronics", open_market)
        if ok and result ~= false then registered = true; return end
    end
    if type(alem.button) == 'function' then
        local ok, result = pcall(alem.button, "Маркет", open_market)
        if ok and result ~= false then registered = true; return end
    end
end

register_button()
pcall(rebuild_catalog)

alem.on('on_load', function()
    register_button()
    catalog_built = false
    rebuild_catalog()
end)

alem.on('on_map_generated', function()
    register_button()
    catalog_built = false
    rebuild_catalog()
end)

alem.on('on_mods_ready', function()
    catalog_built = false
    rebuild_catalog()
end)

alem.on('on_day', function()
    catalog_built = false
end)

log('Online Market 7.1 loaded')
