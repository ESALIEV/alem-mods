-- Statecraft Reborn 16.16 | Alem Colony 0.23.04 | documented Lua API.
-- Separate state prefix avoids old resource/research flags; no resources.json or recipes.json.
local P='sc6_'
local chronicle
local function get(k,d) local v=alem.get(P..k,d);if v==nil then return d end;return v end
local function set(k,v) alem.set(P..k,v) end
local function known(k)
 local ok,v=pcall(alem.researched,k)
 return ok and (v==true or v==1)
end
-- In some game builds enemies() returns a list, not a number.
local function enemy_count()
 local ok,v=pcall(alem.enemies)
 if not ok then return 0 end
 if type(v)=='number' then return math.max(0,v) end
 if type(v)=='table' then
  local n=0
  for _ in pairs(v) do n=n+1 end
  return n
 end
 return 0
end
local function stock_count(id)
 local ok,v=pcall(alem.resource,id)
 if ok and type(v)=='number' then return math.max(0,math.floor(v)) end
 if ok and type(v)=='table' then return math.max(0,math.floor(tonumber(v.count or v.amount or 0) or 0)) end
 return 0
end
local function note(t,s) alem.letter(t,s) end
-- ALEM dialogs show at most five buttons on compact Android screens.
-- Keep original callback indexes while paging the longer government lists.
local function paged_dialog(title,message,options,callback)
 if #options<=5 then return alem.dialog(title,message,options,callback) end
 local total=math.ceil(#options/2)
 local function show(p)
  local first=(p-1)*2+1;local labels={};local indices={}
  for i=first,math.min(first+1,#options) do
   labels[#labels+1]=options[i];indices[#labels]=i
  end
  if p>1 then labels[#labels+1]='← Назад';indices[#labels]='prev' end
  if p<total then labels[#labels+1]='Далее →';indices[#labels]='next' end
  labels[#labels+1]='✕ Закрыть';indices[#labels]='close'
  alem.dialog(title..' — '..p..'/'..total,message,labels,function(selected)
   local action=indices[selected]
   if action=='prev' then show(p-1)
   elseif action=='next' then show(p+1)
   elseif type(action)=='number' then callback(action) end
  end)
 end
 show(1)
end
local function count() return alem.colonist_count() end
local function day() return alem.day() end
local function names() return alem.colonists() end
local function alive(n)
 if not n or n=='' then return false end
 for _,v in ipairs(names()) do if v==n then return true end end
 return false
end
local function ruler()
 local r=get('ruler','')
 if r~='' and not alive(r) then set('ruler','');note('Вакансия','Правитель больше не входит в колонию.');return '' end
 return r
end
local ideologies={
 {'Коммунизм',8,'Чувство равенства',3,{{'Wood',30,48},{'Steel',18,30},{'Cloth',22,36},{'Food',35,55}},'Сегодня наши работники потрудились и перевыполнили план!'},
 {'Фашизм',5,'Военная дисциплина',3,{{'Steel',22,36},{'Wood',28,44},{'Food',25,40}},'Военная промышленность выполнила государственный заказ.'},
 {'Демократия',6,'Гражданское доверие',3,{{'Food',38,60},{'Wood',25,40},{'Cloth',20,34},{'Silver',12,20}},'Местные общины завершили распределение припасов.'},
 {'Монархия',6,'Верность престолу',3,{{'Steel',18,28},{'Wood',28,45},{'Silver',20,32},{'Food',25,40}},'Королевская казна выделила поселению припасы.'},
 {'Технократия',6,'Вера в прогресс',3,{{'Steel',25,40},{'Wood',22,36},{'Silver',15,25},{'Cloth',18,30}},'Инженерный совет отчитался о результатах производства.'},
 {'Корпусы Крига',6,'Служение Императору',3,{{'Steel',22,36},{'AmmoSmokeless',20,35,'Ammo',25,40},{'Gunpowder',15,28},{'Food',20,32}},'Военные склады Империума выполнили заказ. Во славу Его — на поле боя.'},
 {'Аграрный союз',4,'Земля кормит нас',3,{{'Food',40,60},{'Wood',20,32},{'Herbs',10,18}},'Общинные амбары передали урожай.'},
 {'Индустриализм',3,'Труд и производство',3,{{'Steel',20,32},{'Iron',15,25},{'Coal',18,30},{'Copper',10,18}},'Заводские цеха отправили партию материалов.'},
 {'Торговая республика',4,'Свобода торговли',4,{{'Silver',18,28},{'Cloth',18,28},{'Food',25,38},{'Copper',12,20}},'Торговые дома доставили заказ.'},
 {'Военная хунта',3,'Гарнизон прежде всего',3,{{'Steel',20,30},{'Food',25,38},{'Wood',20,32}},'Гарнизон получил снабжение.'},
 {'Культ Механикус',7,'Благословение Омниссии',3,{{'Steel',30,45},{'Iron',15,25}},'Кузни Механикус доставили компоненты'},
 {'Астра Милитарум',6,'Воинская дисциплина',3,{{'Steel',25,38},{'Food',30,45}},'Снабжение Астра Милитарум прибыло'},
 {'Высшее Благо Тау',7,'Единство во имя Блага',4,{{'Food',35,55},{'Silver',20,35}},'Коалиция Тау передала ресурсы'},
 {'Династия Некронов',6,'Вечная династия',4,{{'Steel',28,45},{'Silver',18,30}},'Династические хранилища открыты'},
 {'Владычество Хаоса',5,'Триумф воителей',3,{{'Steel',30,45},{'Gunpowder',14,24}},'Воители доставили трофеи'},
 {'Империум Человечества',7,'Слава Императору',3,{{'Food',35,55},{'Steel',24,40}},'Имперские склады открыты'}
}
local function give(item,qty) alem.give(item,qty) end
-- Daily political authority: n + uniformly random bonus from 0 to min(4,n).
-- Population is sampled at the beginning of each new in-game day.
local ideology_pp_bonus={2,3,4,5,6,3,2,3,4,3,6,5,5,5,4,6} -- bonuses by ideology index
-- Unique ideology policies: periodic administration and non-resource advantages.
local ideology_policies={
 {"Коллективные мастерские","+2 ПВ за цикл; бесплатное снабжение","−2 ПВ на содержание общин",4,2,2,0},
 {"Военный аппарат","+4 ПВ за цикл; военные поставки","−3 ПВ на содержание аппарата",4,4,3,0},
 {"Гражданские институты","+2 ПВ за цикл; скидка 10% на рынке","−1 ПВ на работу институтов",5,2,1,10},
 {"Дворцовая администрация","+3 ПВ за цикл; +2 ПВ в казну","−2 ПВ на двор",5,3,2,0},
 {"Научный совет","+3 ПВ за цикл; научные поставки","−2 ПВ на лаборатории",4,3,2,0},
 {"Военная доктрина Крига","+5 ПВ за цикл; армейские поставки","−4 ПВ на военную машину",4,5,4,0},
 {"Аграрные кооперативы","+2 ПВ за цикл; продовольствие","−1 ПВ на содержание кооперативов",3,2,1,0},
 {"Индустриальные цеха","+4 ПВ за цикл; промышленные поставки","−3 ПВ на оборудование",4,4,3,0},
 {"Торговые привилегии","+3 ПВ за цикл; скидка 15% на рынке","−2 ПВ на торговые представительства",4,3,2,15},
 {"Гарнизонный режим","+4 ПВ за цикл; военные поставки","−3 ПВ на гарнизоны",3,4,3,0},
 {"Священные кузни","+4 ПВ за цикл; материалы","−3 ПВ на техножрецов",4,4,3,0},
 {"Военный департамент","+4 ПВ за цикл; боеприпасы","−3 ПВ на содержание армии",3,4,3,0},
 {"Общественное согласие","+2 ПВ за цикл; скидка 10% на рынке","−1 ПВ на координацию каст",4,2,1,10},
 {"Династические архивы","+3 ПВ за цикл; +3 ПВ в казну","−2 ПВ на поддержание архивов",5,3,2,0},
 {"Военные трофеи","+5 ПВ за цикл; трофейные припасы","−4 ПВ на воителей",3,5,4,0},
 {"Имперская десятина","+4 ПВ за цикл; +2 ПВ в казну","−3 ПВ на бюрократию",4,4,3,0},
}
local function policy_discount()
 local p=ideology_policies[get('ideology',0)]
 return p and p[7] or 0
end
local function policy_tick(d)
 local id=get('ideology',0);local p=ideology_policies[id]
 if not p or d%p[4]~=0 then return end
 local available=get('pp',0);local paid=math.min(available,p[6])
 set('pp',available-paid+p[5])
 if id==4 or id==14 or id==16 then
  local reserve_gain=(id==14) and 3 or 2
  set('reserve',get('reserve',0)+reserve_gain)
 end
 if paid<p[6] then alem.mood_all(-1,1,'Недостаточное финансирование: '..p[1]) end
 note('Идеологическая программа',p[1]..': +'..p[5]..' ПВ; содержание −'..paid..' ПВ.')
end
local function ideology_statistics()
 local function show(page)
  local start=(page-1)*4+1;local options={}
  for i=start,math.min(start+3,#ideologies) do options[#options+1]=ideologies[i][1] end
  options[#options+1]=(start+3<#ideologies) and 'Далее →' or 'В начало'
  alem.dialog('Справочник идеологий '..page..'/4','Выберите идеологию для просмотра всех преимуществ и ограничений.',options,function(choice)
   if choice==#options then show((start+3<#ideologies) and page+1 or 1);return end
   local id=start+choice-1;local v=ideologies[id];local p=ideology_policies[id]
   if not v or not p then return end
   local items={}
   for _,r in ipairs(v[5]) do items[#items+1]=r[1]..' ×'..r[2]..'–'..r[3] end
   local msg='Настроение: +'..v[2]..' ('..v[3]..').\nДоход: +'..(ideology_pp_bonus[id] or 0)..' ПВ ежедневно.\nПоставки раз в '..v[4]..' дня: '..table.concat(items,', ')..'.\n\nОсобенность: '..p[1]..'.\nБонус: '..p[2]..'.\nОграничение: '..p[3]..'.\nРасчёт каждые '..p[4]..' дня.'
   if p[7]>0 then msg=msg..'\nСкидка на государственном рынке: '..p[7]..'%.' end
   if id==4 or id==14 or id==16 then msg=msg..'\nЧасть дохода автоматически направляется в казну.' end
   alem.dialog(v[1],msg,{'К списку','Закрыть'},function(c) if c==1 then show(page) end end)
  end)
 end
 show(1)
end
local function daily_income(n)
 if n<=0 then return 0 end
 local base=n+math.random(0,math.min(4,n))
 return base+(ideology_pp_bonus[get('ideology',0)] or 0)
end
-- Character convictions are independent of the colony's currently chosen ideology.
-- Ideological convictions: each trait has a stable ideology index.
-- One political trait is applied per colonist to avoid double counting.
local ideological_traits={
 'Коммунист','Фашист','Демократ','Монархист','Технократ',
 'Криговец','Аграрий','Индустриалист','Сторонник торговли','Милитарист',
 'Адепт Омниссии','Ветеран Астра Милитарум','Последователь Высшего Блага',
 'Верный династии','Избранник Хаоса','Имперский фанатик'
}
local function conviction_tick()
 local ideology_id=get('ideology',0)
 if ideology_id<1 or ideology_id>#ideological_traits then return end
 for _,person in ipairs(names()) do
  local ok,ts=pcall(alem.traits,person)
  if ok and type(ts)=='table' then
   for i,trait in ipairs(ideological_traits) do
    local has=false
    for _,t in ipairs(ts) do
     if t==trait or (type(t)=='table' and (t.name==trait or t.id==trait)) then has=true;break end
    end
    if has then
     local mood=(i==ideology_id) and 3 or -5
     local reason=(i==ideology_id) and 'Моя идеология совпадает с курсом колонии' or 'Моя идеология не совпадает с курсом колонии'
     alem.memory(person,mood,1,reason)
     break
    end
   end
  end
 end
end
local function pp(n) set('pp',get('pp',0)+n) end
local function spend(n)
 if get('pp',0)<n then note('Недостаточно политической власти','Нужно '..n..' ПВ; имеется '..get('pp',0));return false end
 set('pp',get('pp',0)-n);return true
end
local rank_titles={
 [1]={'Генеральный секретарь','Народный комиссар'},
 [2]={'Верховный вождь','Генерал'},
 [3]={'Первый канцлер','Почётный канцлер'},
 [4]={'Император','Великий князь'},
 [5]={'Верховный архонт','Главный инженер'},
 [6]={'Верховный маршал Крига','Маршал Крига'},
 [7]={'Верховный председатель','Старейшина'},
 [8]={'Генеральный директор','Промышленный магнат'},
 [9]={'Великий консул','Торговый сенатор'},
 [10]={'Генералиссимус','Фельдмаршал'},
 [11]={'Фабрикатор-генерал','Архимагос'},
 [12]={'Лорд-солар','Лорд-маршал'},
 [13]={'Верховный Эфирный','Эфирный наставник'},
 [14]={'Фаэрон','Немесор'},
 [15]={'Воитель Хаоса','Князь Хаоса'},
 [16]={'Лорд-командующий','Лорд-генерал'}
}
local function demote_former(old)
 if not old or old=='' then return end
 if get('ascended_ruler','')==old then
  if type(alem.remove_trait)=='function' then pcall(alem.remove_trait,old,'Возвышенный правитель') end
  if alive(old) and type(alem.add_trait)=='function' then pcall(alem.add_trait,old,'Почётный владыка') end
  set('former_title_'..old,get('ascended_lesser','Почётный владыка'))
  set('ascended_ruler','')
  set('ascended_title','')
 end
end
local function ascend_ruler()
 local who=ruler()
 if who=='' then note('Возвышение','Сначала изберите правителя.');return end
 local i=get('ideology',0)
 local titles=rank_titles[i] or {'Верховный правитель','Почётный владыка'}
 if get('ascended_ruler','')==who then note('Возвышение','Правитель уже возвышен: '..get('ascended_title',''));return end
 alem.dialog('Возвышение правителя','Провозгласить '..who..' титулом «'..titles[1]..'» за 100 ПВ? Бонусы действуют только до смены власти.',{'Провозгласить (100 ПВ)','Назад'},function(choice)
  if choice~=1 or not alive(who) or ruler()~=who then return end
  if not spend(100) then return end
  if type(alem.remove_trait)=='function' then pcall(alem.remove_trait,who,'Почётный владыка') end
  if type(alem.add_trait)=='function' then pcall(alem.add_trait,who,'Возвышенный правитель') end
  set('ascended_ruler',who);set('ascended_title',titles[1]);set('ascended_lesser',titles[2])
  chronicle('Возвышен '..who..': '..titles[1])
  note('Возвышение','Провозглашён '..titles[1]..'. Государственные бонусы активны до смены правителя.')
 end)
end
local function elect()
 if not known('sc_administration') then note('Исследование','Сначала изучите основы государственного управления.');return end
 local current=ruler()
 local ready=get('election_next',0)
 if day()<ready then note('Выборы','Следующие выборы доступны в день '..ready..'.');return end
 local people=names();if #people==0 then return end
 local options={}
 for _,n in ipairs(people) do options[#options+1]=n..(n==current and ' (действующий)' or '') end
 options[#options+1]='Назад'
 paged_dialog('Выборы правителя','Одновременно правит только один человек. После выборов следующие доступны через 7 дней. +3 настроения колонии на 5 суток; правителю +10, пока он занимает пост.',options,function(i)
  if i<1 or i>#people then return end
  local chosen=people[i]
  if not alive(chosen) then note('Выборы','Кандидат больше не входит в колонию.');return end
  if chosen==ruler() then note('Выборы','Этот колонист уже правитель.');return end
  if day()<get('election_next',0) then return end
  demote_former(current)
  set('ruler',chosen);set('election_next',day()+7)
  -- Short refresh prevents long-lasting former ruler bonus after replacement.
  alem.memory(chosen,10,0.06,'Я — правитель')
  alem.mood_all(3,5,'Избрание правителя')
  chronicle('Избран правитель '..chosen);note('Выборы завершены',chosen..' — новый правитель. Прежний снят с должности. Следующие выборы: день '..get('election_next',0)..'.')
 end)
end
local function ideology()
 if not known('sc_administration') then note('Исследование','Нужны основы государственного управления.');return end
 local function choose(i)
  local v=ideologies[i];if not v then return end
  if i==get('ideology',0) then note('Идеология','Она уже действует.');return end
  if day()<get('ideology_next',0) then note('Реформа','Следующая реформа: день '..get('ideology_next',0));return end
  local cost=(i==6 or get('ideology',0)==6) and 50 or 35
  alem.dialog(v[1],'Настроение: +'..v[2]..' («'..v[3]..'»). Поставки раз в '..v[4]..' дня. Особенность: '..ideology_policies[i][1]..'. '..ideology_policies[i][2]..'. '..ideology_policies[i][3]..'.',{'Принять ('..cost..' ПВ)','Назад'},function(c)
   if c~=1 or not spend(cost) then return end
   set('ideology',i);set('ideology_next',day()+12);conviction_tick()
   if get('law',0)==6 and get('special_law_ideology',0)~=i then set('law',0);set('special_law_ideology',0);note('Закон отменён','Особый закон прежней идеологии утратил силу.') end
   if get('ascended_ruler','')~='' and get('ascended_ruler','')==ruler() then
    local newtitles=rank_titles[i]
    if newtitles then set('ascended_title',newtitles[1]);set('ascended_lesser',newtitles[2]) end
   end
   chronicle('Принята идеология '..v[1]);note('Новый государственный курс','Принята идеология: '..v[1])
  end)
 end
 -- Paged selection: four ideologies and a navigation action.
 local show_page
 show_page=function(page)
  local first=(page-1)*4+1
  local options={}
  for i=first,math.min(first+3,#ideologies) do options[#options+1]=ideologies[i][1] end
  local n=#options
  options[#options+1]=(first+3<#ideologies) and 'Далее' or 'В начало'
  alem.dialog('Идеологии: '..page,'Выберите государственный курс.',options,function(choice)
   if choice>=1 and choice<=n then choose(first+choice-1)
   elseif choice==n+1 then show_page((first+3<#ideologies) and (page+1) or 1) end
  end)
 end
 show_page(1)
end

local focus={
 {'Хозяйственный план',35,5,'sc_economy','+20 дерева, +12 стали и +2 настроения на 2 дня.'},
 {'Общественные собрания',24,5,'sc_council','+4 настроения на 3 дня.'},
 {'Военные склады',42,7,'sc_industry','+18 стали для обороны.'},
 {'Продовольственная безопасность',25,4,'sc_economy','+45 еды.'},
 {'Культурный фестиваль',30,7,'sc_propaganda','+5 настроения на 3 дня.'},
 {'Разведывательная операция',35,8,'sc_intelligence','+8 процентных пунктов к следующему ультиматуму.'}
}
local function focus_effect(i)
 if i==1 then give('Wood',20);give('Steel',12);alem.mood_all(2,2,'Хозяйственный подъём')
 elseif i==2 then alem.mood_all(4,3,'Общественные собрания')
 elseif i==3 then give('Steel',18)
 elseif i==4 then give('Food',45)
 elseif i==5 then alem.mood_all(5,3,'Культурный фестиваль')
 elseif i==6 then set('intel',get('intel',0)+8) end
end
local function focuses()
 local o={};for _,f in ipairs(focus) do o[#o+1]=f[1]..' — '..f[2]..' ПВ' end;o[#o+1]='Назад'
 paged_dialog('Национальные фокусы','Политическая власть: '..get('pp',0),o,function(i)
  local f=focus[i];if not f then return end
  if not known(f[4]) then note('Не исследовано','Нужна технология '..f[4]);return end
  if day()<get('focus_'..i,0) then note('Восстановление','Доступно с дня '..get('focus_'..i,0));return end
  alem.dialog(f[1],f[5],{'Выполнить','Назад'},function(c)
   if c~=1 or not spend(f[2]) then return end
   set('focus_'..i,day()+f[3]);focus_effect(i);note('Фокус выполнен',f[1])
  end)
 end)
end
local reforms={
 {'Пятилетний план',100,20,'sc_economy','Раз в 4 дня: дерево и сталь.'},
 {'Военная промышленность',120,15,'sc_industry','Раз в 3 дня: сталь.'},
 {'Земельная реформа',75,20,'sc_agriculture','Раз в 5 дней: еда.'},
 {'Государственное образование',90,15,'sc_education','Раз в 3 дня: +2 настроения на сутки.'},
 {'Народные праздники',60,5,'sc_council','+4 настроения на 5 дней.'},
 {'Разведывательная сеть',110,14,'sc_intelligence','+12 пунктов к следующему ультиматуму.'},
 {'Мобилизация',150,10,'sc_mobilization','Раз в 5 дней: сталь и еда.'},
 {'Административная реформа',100,10,'sc_administration','Ежедневно +3 ПВ в течение 10 дней.'}
}
local function programs()
 local o={};for _,v in ipairs(reforms) do o[#o+1]=v[1]..' — '..v[2]..' ПВ' end;o[#o+1]='Назад'
 paged_dialog('Государственные программы','Несколько программ могут работать одновременно.',o,function(i)
  local r=reforms[i];if not r then return end
  if not known(r[4]) then note('Не исследовано','Нужна технология '..r[4]);return end
  if day()<get('program_cool_'..i,0) then note('Перерыв','Повторить можно с дня '..get('program_cool_'..i,0));return end
  alem.dialog(r[1],r[5]..' Срок: '..r[3]..' суток.',{'Начать','Назад'},function(c)
   if c~=1 or not spend(r[2]) then return end
   set('program_end_'..i,day()+r[3]);set('program_cool_'..i,day()+r[3]+5)
   if i==5 then alem.mood_all(4,5,'Народные праздники') end
   if i==6 then set('intel',get('intel',0)+12) end
   note('Программа принята',r[1])
  end)
 end)
end
local factions={'Северный союз','Вольные города','Пепельные кланы','Зелёная конфедерация'}
local demands={{'Wood',40,'40 дерева',5},{'Steel',25,'25 стали',8},{'Food',65,'65 еды',8},{'Silver',55,'55 серебра',12}}
local function ultimatum()
 if not known('sc_ultimatum') then note('Исследование','Необходимо изучить дипломатическое давление.');return end
 if ruler()=='' then note('Дипломатия','Сначала выберите правителя.');return end
 if get('ult_target',0)>0 then note('Посольство в пути','Ответ ожидается в день '..get('ult_answer',0));return end
 if day()<get('ult_next',0) then note('Посольства заняты','Новое посольство возможно в день '..get('ult_next',0));return end
 local o={};for _,n in ipairs(factions) do o[#o+1]=n end;o[#o+1]='Назад'
 alem.dialog('Адресат ультиматума','Цели мода. API не гарантирует выбор настоящей фракции для ответного рейда.',o,function(fi)
  if fi<1 or fi>#factions then return end
  local d={};for _,v in ipairs(demands) do d[#d+1]=v[3] end;d[#d+1]='Назад'
  alem.dialog('Требование',factions[fi],d,function(di)
   local req=demands[di];if not req then return end
   alem.dialog('Отправить посольство','Цена 18 ПВ. Ответ через 2–4 дня. Отказ грозит рейдом.',{'Отправить','Назад'},function(c)
    if c~=1 or not spend(18) then return end
    local wait=math.random(2,4);set('ult_target',fi);set('ult_demand',di);set('ult_answer',day()+wait);set('ult_next',day()+wait+7)
    note('Посольство отправлено',factions[fi]..': ожидайте ответ '..wait..' суток.')
   end)
  end)
 end)
end
local function answer(d)
 local fi=get('ult_target',0);if fi==0 or d<get('ult_answer',999999) then return end
 local req=demands[get('ult_demand',1)];if not req then set('ult_target',0);return end
 local chance=62-req[4]+get('intel',0)
 if get('intel',0)>0 then chance=chance+6 end
 -- No research-state assumptions: console research does not necessarily emit the hook.
 if get('ideology',0)==2 then chance=chance+4 end
 if fi==3 then chance=chance-15 elseif fi==2 then chance=chance+8 end
 chance=math.max(15,math.min(85,chance))
 set('ult_target',0);set('intel',0)
 if math.random(1,100)<=chance then give(req[1],req[2]);chronicle('Ультиматум принят: '..factions[fi]);note('Ультиматум принят',factions[fi]..' передали '..req[3]..'.')
 else chronicle('Ультиматум отклонён: '..factions[fi]);note('Ультиматум отклонён',factions[fi]..' отказались. Стандартный рейд через 6 часов.');alem.raid_in(6) end
end
local function status()
 local r=ruler();local i=get('ideology',0);local ideology_name='не выбрана'
 if ideologies[i] then ideology_name=ideologies[i][1] end
 local people=count()
 note('Состояние государства','Правитель: '..(r~='' and r or 'нет')..'\nИдеология: '..ideology_name..'\nПолитическая власть: '..get('pp',0)..'\nНаселение: '..people..'\nЕжедневный доход: '..(people>0 and people or 0)..'–'..(people+math.min(4,people))..' ПВ\nВчера начислено: +'..get('last_income',0)..' ПВ (население: '..get('last_population',0)..')\nСледующие выборы: день '..get('election_next',0))
end

-- STATECRAFT 7: all mechanics use documented alem.* methods only.
chronicle=function(event)
 local entry='День '..day()..': '..event
 for i=9,2,-1 do set('history_'..i,get('history_'..(i-1),'')) end
 set('history_1',entry)
end
local function ledger(item,qty)
 give(item,qty)
 set('delivered_'..item,get('delivered_'..item,0)+qty)
end
local function treasury()
 if not known('sc_treasury') then note('Казна','Изучите «Государственная казна».');return end
 local bal=math.max(0,get('reserve',0))
 local opts={'Внести 25 ПВ','Внести 100 ПВ','Забрать 25 ПВ','Забрать 100 ПВ','Экстренные припасы (40 ПВ казны)','Назад'}
 paged_dialog('Государственная казна','Защищено: '..bal..' ПВ\nДоступно для расходов: '..get('pp',0)..' ПВ.\nЗаконы и решения расходуют только доступные ПВ.',opts,function(i)
  local deposit=({[1]=25,[2]=100})[i]
  local withdraw=({[3]=25,[4]=100})[i]
  if deposit then
   if spend(deposit) then set('reserve',bal+deposit);chronicle('Казна пополнена на '..deposit..' ПВ');note('Казна','В резерве '..(bal+deposit)..' ПВ.') end
  elseif withdraw then
   if bal<withdraw then note('Казна','В резерве недостаточно ПВ.');return end
   set('reserve',bal-withdraw);pp(withdraw);chronicle('Из казны выведено '..withdraw..' ПВ')
  elseif i==5 then
   if bal>=40 and day()>=get('treasury_next',0) then
    set('reserve',bal-40);set('treasury_next',day()+7)
    ledger('Food',30);ledger('Wood',20)
    note('Экстренное снабжение','Получено 30 еды и 20 дерева.');chronicle('Казна оплатила экстренное снабжение')
   else note('Казна','Нужно 40 ПВ резерва; повтор через 7 дней.') end
  end
 end)
end
local laws={
 {'Нормированный труд',45,12,'sc_laws','+2 настроения каждый день, но −1 ПВ/день.'},
 {'Усиленные смены',55,10,'sc_laws','Раз в 3 дня +12 дерева; −2 настроения ежедневно.'},
 {'Государственное образование',65,12,'sc_education','Каждые 3 дня +2 настроения; −2 ПВ/день.'},
 {'Военная повинность',70,10,'sc_defense','Раз в 4 дня +10 стали; −2 настроения ежедневно.'},
 {'Продовольственные резервы',50,12,'sc_agriculture','Каждые 4 дня +20 еды; −1 ПВ/день.'}
}
-- Each state has one additional law; the first five legacy law IDs stay unchanged.
local ideology_laws={
 [1]={'Коммунальные мастерские','Wood',20,4,2},
 [2]={'Военные заводы','Steel',15,4,-1},
 [3]={'Гражданские гарантии','Food',22,4,2},
 [4]={'Королевский указ','Silver',12,5,1},
 [5]={'Академия инженеров','Steel',14,5,1},
 [6]={'Приказ о снабжении Крига','AmmoSmokeless',16,5,0},
 [7]={'Общинные амбары','Food',28,4,1},
 [8]={'Промышленная смена','Steel',20,4,-1},
 [9]={'Свободные рынки','Silver',18,4,1},
 [10]={'Гарнизонный устав','Steel',17,4,0},
 [11]={'Священные кузни','Iron',20,4,1},
 [12]={'Воинский устав','AmmoSmokeless',18,4,0},
 [13]={'Единое Благо','Food',26,4,2},
 [14]={'Династические хранилища','Steel',18,4,1},
 [15]={'Право сильного','Gunpowder',16,4,-1},
 [16]={'Имперская десятина','Food',25,4,1},
}
local function laws_menu()
 if not known('sc_laws') then note('Законы','Изучите «Законодательство».');return end
 local ideology_id=get('ideology',0)
 local special=ideology_laws[ideology_id]
 local o={}
 for _,v in ipairs(laws) do o[#o+1]=v[1]..' ('..v[2]..' ПВ)' end
 if special then o[#o+1]=special[1]..' — закон идеологии (65 ПВ)' end
 local cancel_index=#o+1;o[#o+1]='Отменить действующий закон';o[#o+1]='Назад'
 local active=get('law',0)
 local active_name='нет'
 if active>0 and laws[active] then active_name=laws[active][1]
 elseif active==6 then active_name=get('special_law_name','Особый закон') end
 paged_dialog('Законы','Действующий: '..active_name..'. Одновременно действует один закон. Казна защищена от расходов.',o,function(i)
  if i==cancel_index then
   if active>0 then set('law',0);set('law_end',0);set('special_law_ideology',0);chronicle('Отменён закон '..active_name);note('Закон отменён',active_name) end
   return
  end
  if i==#o then return end
  if active>0 then note('Закон','Сначала отмените действующий закон.');return end
  if day()<get('law_next',0) then note('Закон','Следующий закон доступен в день '..get('law_next',0));return end
  if special and i==#laws+1 then
   alem.dialog(special[1],'На 12 дней. Каждые '..special[4]..' дня: '..special[3]..' ед. припасов; настроение '..(special[5]>=0 and '+' or '')..special[5]..'.',{'Принять (65 ПВ)','Назад'},function(c)
    if c==1 and spend(65) then
     set('law',6);set('law_end',day()+12);set('law_next',day()+4)
     set('special_law_ideology',ideology_id);set('special_law_name',special[1])
     chronicle('Принят закон '..special[1]);note('Новый закон',special[1])
    end
   end)
   return
  end
  local v=laws[i];if not v then return end
  if not known(v[4]) then note('Закон','Сначала изучите необходимую технологию.');return end
  alem.dialog(v[1],v[5]..' Срок '..v[3]..' дней.',{'Принять','Назад'},function(c)
   if c==1 and spend(v[2]) then set('law',i);set('law_end',day()+v[3]);set('law_next',day()+4);chronicle('Принят закон '..v[1]);note('Новый закон',v[1]) end
  end)
 end)
end
local function defense()
 if not known('sc_defense') then note('Оборона','Нужно исследование «Оборонное планирование».');return end
 alem.dialog('Военная готовность','Программа готовности защищает снабжение, но не изменяет силу игрового рейда. Врагов на карте: '..tostring(enemy_count()),{'Создать запасы: 55 ПВ','Тревога и собрание: 25 ПВ','Назад'},function(i)
  if i==1 then if day()<get('defense_next',0) then note('Оборона','Доступно в день '..get('defense_next',0));return end
   if spend(55) then set('defense_next',day()+7);ledger('Steel',12);ledger('Food',20);chronicle('Подготовлены оборонные запасы');note('Военная готовность','Получено 12 стали и 20 еды.') end
  elseif i==2 then if day()<get('alarm_next',0) then note('Тревога','Перерыв до дня '..get('alarm_next',0));return end
   if spend(25) then set('alarm_next',day()+5);alem.mood_all(2,2,'Подготовка к обороне');chronicle('Проведены оборонные сборы');note('Сборы','Колонисты получили +2 настроения на 2 дня.') end end
 end)
end
local function statistics()
 if not known('sc_records') then note('Статистика','Нужно исследование «Государственная статистика».');return end
 local t='Население: '..count()..'\nБогатство: '..tostring(alem.wealth())..'\nПВ: '..get('pp',0)..'\nКазна: '..get('reserve',0)..'\nТорговых операций: '..get('trade_count',0)..'\nБаланс торговли серебром: '..get('trade_silver',0)
 for _,item in ipairs({'Wood','Steel','Food','Cloth','Silver'}) do t=t..'\n'..item..': на складе '..tostring(alem.resource(item))..', получено от государства '..get('delivered_'..item,0) end
 note('Статистика государства',t)
end
local function history_menu()
 local t='Последние государственные события:'
 for i=1,9 do local e=get('history_'..i,'');if e~='' then t=t..'\n'..e end end
 note('Летопись',t)
end
local function seasonal(season)
 if not known('sc_festivals') or count()==0 then return end
 local names_season={spring='Весенний праздник',summer='Летний праздник',autumn='Праздник урожая',winter='Зимний праздник'}
 local name=names_season[season];if not name then return end
 if get('season_event_day',-1)==day() then return end
 set('season_event_day',day());chronicle(name)
 if season=='autumn' then ledger('Food',12);note(name,'Получено 12 еды для общины.')
 elseif season=='winter' then alem.mood_all(2,1,name);note(name,'+2 настроения на сутки.')
 else alem.mood_all(1,1,name);note(name,'+1 настроение на сутки.') end
end
local function law_tick(d)
 local i=get('law',0);if i==0 then return end
 local name=(laws[i] and laws[i][1]) or get('special_law_name','Особый закон')
 if d>=get('law_end',0) then
  set('law',0);set('special_law_ideology',0);chronicle('Завершено действие закона '..name);note('Срок закона истёк',name);return
 end
 if i==1 then alem.mood_all(2,1,'Нормированный труд');set('pp',math.max(0,get('pp',0)-1))
 elseif i==2 then alem.mood_all(-2,1,'Усиленные смены');if d%3==0 then ledger('Wood',12) end
 elseif i==3 then set('pp',math.max(0,get('pp',0)-2));if d%3==0 then alem.mood_all(2,1,'Образование') end
 elseif i==4 then alem.mood_all(-2,1,'Военная повинность');if d%4==0 then ledger('Steel',10) end
 elseif i==5 then set('pp',math.max(0,get('pp',0)-1));if d%4==0 then ledger('Food',20) end
 elseif i==6 then
  local law=ideology_laws[get('special_law_ideology',0)]
  if not law then set('law',0);return end
  if law[5]~=0 then alem.mood_all(law[5],1,law[1]) end
  if d%law[4]==0 then
   local resource=law[2]
   if resource=='AmmoSmokeless' and type(alem.resource)=='function' then
    local ok,available=pcall(alem.resource,resource)
    if not ok or available==nil then resource='Steel' end
   end
   ledger(resource,law[3])
  end
 end
end
alem.on('on_trade',function(faction,item,qty,silver)
 set('trade_count',get('trade_count',0)+1)
 if type(silver)=='number' then set('trade_silver',get('trade_silver',0)+silver) end
 set('last_trade',tostring(faction)..': '..tostring(item)..' ×'..tostring(qty))
end)
alem.on('on_season_change',seasonal)
alem.on('on_birth',function(n)chronicle('Родился колонист '..tostring(n)) end)
alem.on('on_prisoner_recruited',function(n)chronicle('В колонию принят '..tostring(n)) end)


-- Immediate market: prices in marks; available items runtime-filtered by vanilla IDs.
local trade_factions={'Северный союз','Степная лига','Вольные города','Пепельные кланы'}
-- ID, label, daily base stock, base MARK price/unit, metadata hint.
-- Only real resources from 0.23.04 plus the existing Wood/Cloth/Medicine compatibility aliases.
local market_categories={
 { "Дерево и камень", {{"Wood","Дерево",40,2,1},{"LimestoneChunk","Известняк",28,2,1},{"GraniteChunk","Гранит",26,2,1},{"LimestoneBlock","Белые известняковые кирпичи",26,3,1},{"GraniteBlock","Гранитные кирпичи",26,3,1},{"Glass","Стекло",15,9,1}} },
 { "Руды и металлы", {{"Iron","Железо",32,9,1},{"Steel","Сталь",26,10,1},{"Copper","Медь",30,9,1},{"Coal","Уголь",40,6,1},{"IronOre","Железная руда",28,5,1},{"CopperOre","Медная руда",28,5,1},{"LeadOre","Свинцовая руда",24,4,1},{"Lead","Свинец",26,6,1},{"Bronze","Бронза",22,11,1},{"GoldOre","Золотая руда",6,28,1},{"SilverOre","Серебряная руда",12,14,1},{"Saltpeter","Селитра",26,4,1},{"Sulfur","Сера",24,5,1},{"Gold","Золотая монета (товар)",2,78,1}} },
 { "Патроны и снаряды", {{"Ammo","Патроны",35,9,1},{"AmmoSmokeless","Бездымные патроны",24,14,1},{"MusketBall","Мушкетные пули",32,6,1},{"Gunpowder","Порох",30,6,1},{"Arrow","Стрелы",40,3,1},{"CannonBall","Пушечные ядра",12,20,1},{"Grapeshot","Картечь",15,15,1},{"Grenade","Гранаты",8,35,1}} },
 { "Лекарства", {{"Herbs","Лечебные травы",35,3,1},{"Antibiotics","Антибиотики",12,38,1},{"Medicine","Медикаменты",15,25,1}} },
 { "Еда и урожай", {{"Food","Продовольствие",45,4,1},{"MealSimple","Готовые блюда (1 порция)",24,9,1},{"MealFine","Изысканные блюда (1 порция)",12,18,1},{"Pemmican","Сушёные пайки",20,8,1},{"Rice","Рис",40,3,1},{"Potato","Картофель",40,3,1},{"Raspberry","Ягоды",36,3,1},{"Fish","Рыба",22,6,1},{"Venison","Оленина",20,8,1},{"ChickenMeat","Курица",20,8,1},{"GoatMeat","Козлятина",16,9,1},{"Cheese","Сыр",16,9,1},{"Butter","Масло",16,9,1},{"Hay","Сено",40,2,1}} },
 { "Ткани и кожа", {{"Cloth","Ткань",36,2,1},{"Leather","Кожа",24,9,1},{"Fur","Мех",18,10,1}} },
 { "Детали и топливо", {{"IronComponent","Железные компоненты",16,20,1},{"Gears","Шестерни",18,15,1},{"Springs","Пружины",18,16,1},{"SteelMechanism","Стальной механизм",8,38,1},{"PreciseParts","Точные детали",8,44,1}} }
}
local function market_registry()
 local found={}
 local ok,ids=pcall(alem.ids,'resources')
 if ok and type(ids)=='table' then
  for _,entry in pairs(ids) do
   local id=type(entry)=='string' and entry or (type(entry)=='table' and (entry.id or entry.name) or nil)
   if type(id)=='string' then found[string.lower(id)]=id end
  end
 end
 -- Verified against Alem Colony 0.23.04 ResourceType metadata. The runtime
 -- registry is preferred; vanilla IDs remain available when it omits entries.
 local vanilla={["Food"]=true,["Raspberry"]=true,["Rice"]=true,["Potato"]=true,["LimestoneChunk"]=true,["GraniteChunk"]=true,["LimestoneBlock"]=true,["GraniteBlock"]=true,["Iron"]=true,["Coal"]=true,["Steel"]=true,["IronOre"]=true,["Herbs"]=true,["Corpse"]=true,["Leather"]=true,["Fish"]=true,["ImperialMark"]=true,["Silver"]=true,["Gold"]=true,["Venison"]=true,["WolfMeat"]=true,["RabbitMeat"]=true,["HorseMeat"]=true,["MealSimple"]=true,["MealFine"]=true,["MealBurnt"]=true,["Pemmican"]=true,["IronComponent"]=true,["CopperOre"]=true,["Copper"]=true,["Bronze"]=true,["Gears"]=true,["Springs"]=true,["SteelMechanism"]=true,["PreciseParts"]=true,["Glass"]=true,["CannonBall"]=true,["Sulfur"]=true,["Gunpowder"]=true,["LeadOre"]=true,["Lead"]=true,["Grapeshot"]=true,["Fur"]=true,["Antibiotics"]=true,["Ammo"]=true,["MusketBall"]=true,["AmmoSmokeless"]=true,["Arrow"]=true,["GoldOre"]=true,["SilverOre"]=true,["Saltpeter"]=true,["Gems"]=true,["Hay"]=true,["Cheese"]=true,["Butter"]=true,["Grenade"]=true,["Kidney"]=true,["Lung"]=true,["Liver"]=true,["Heart"]=true,["Eye"]=true,["ProsthLegWood"]=true,["ProsthLegSteel"]=true,["BionicLeg"]=true,["BionicArm"]=true,["BionicEye"]=true,["Arm"]=true,["Leg"]=true,["BloodI"]=true,["BloodII"]=true,["BloodIII"]=true,["BloodIV"]=true,["ChickenMeat"]=true,["GoatMeat"]=true,["Beef"]=true,["Mutton"]=true,["Pork"]=true,["DogMeat"]=true,["HumanCorpse"]=true,["BabyFormula"]=true,["BabyPuree"]=true,["Beer"]=true,["Moonshine"]=true,["AshLeaf"]=true,["BlackTobacco"]=true,["MountainJuice"]=true,["AirholmPowder"]=true,["Tefiin"]=true,["Morgin"]=true,["Hops"]=true,["Wort"]=true,["TefiaLeaf"]=true,["Molotov"]=true,["IceCore"]=true}
 for id in pairs(vanilla) do
  if not found[string.lower(id)] then found[string.lower(id)]=id end
 end
 -- Compatibility aliases already present in older versions of this mod.
 for _,id in ipairs({'Wood','Cloth'}) do
  if not found[string.lower(id)] then found[string.lower(id)]=id end
 end
 return found
end
-- Daily variation is deterministic: revisiting menus or loading a save does not
-- re-roll prices.  Day one uses the nominal price for a predictable start.
local function market_swing(d,fi,ci,gi)
 if d<=1 then return 0 end
 local seed=(d*7919+fi*1297+ci*541+gi*313)
 local n=(seed*seed+seed*17+53)%101
 if n<=50 then return (n-50)/100 end -- down to -50 percent
 return (n-50)/50                  -- up to +100 percent
end
local function market_marks_per_ten(d)
 -- Baseline: 50 marks = 10 silver = 1 gold; daily mark rate 45..55.
 if d<=1 then return 50 end
 return 50+((d*37+d*d*13)%11)-5
end
local function market_mark_price(d,fi,ci,gi,base,id)
 local price=math.max(1,math.ceil(base*(1+market_swing(d,fi,ci,gi))))
 -- Every commodity varies independently by day and merchant: -50% to +100%.
 -- The first day always uses the displayed base price.
 -- Gold is itself currency: buying it from a trader must not generate
 -- risk-free profit by immediately changing it back into marks/silver.
 if id=='Gold' then price=math.max(price,math.ceil(market_marks_per_ten(d)*1.30)) end
 return price
end

local function market_inventory(ci,fi)
 local goods={};local seen={};local registry=market_registry()
 for gi,v in ipairs(market_categories[ci][2]) do
  local id=registry[string.lower(v[1])]
  if id and not seen[string.lower(v[2])] then
   local seed=(day()*17+fi*11+ci*7+gi*13)%11
   local qty=math.max(1,math.floor(v[3]*(65+seed*7)/100))
   local price=market_mark_price(day(),fi,ci,gi,v[4],v[1])
   local key='stock_'..day()..'_'..fi..'_'..ci..'_'..gi
   local remaining=get(key,qty)
   if remaining>0 then
    goods[#goods+1]={id,v[2],remaining,price,key,qty,gi,v[4]}
    seen[string.lower(v[2])]=true
   end
  end
 end
 return goods
end
-- Deliver paid merchandise as a visible ground stack at the colony's landing area.
-- If the exact middle is occupied, try nearby walkable cells; never delay orders.
local function market_spawn_at_center(id,qty)
 local ok,cx,cy=pcall(alem.colony_center)
 if not ok or type(cx)~='number' or type(cy)~='number' then
  local size_ok,w,h=pcall(alem.map_size)
  if not size_ok or type(w)~='number' or type(h)~='number' then
   return false,'Не удалось определить центр колонии.'
  end
  cx=math.floor(w/2);cy=math.floor(h/2)
 end
 cx=math.floor(cx);cy=math.floor(cy)
 local bounds_ok,w,h=pcall(alem.map_size)
 local offsets={{0,0},{1,0},{0,1},{-1,0},{0,-1},
  {1,1},{-1,1},{1,-1},{-1,-1},{2,0},{0,2},{-2,0},{0,-2},
  {2,1},{1,2},{-2,1},{-1,2},{2,-1},{1,-2}}
 for _,offset in ipairs(offsets) do
  local x=cx+offset[1];local y=cy+offset[2]
  local inside=not bounds_ok or type(w)~='number' or type(h)~='number' or (x>=0 and y>=0 and x<w and y<h)
  if inside then
   local walk_ok,walk=pcall(alem.walkable,x,y)
   if not walk_ok or walk~=false then
    local placed,result=pcall(alem.spawn_item,id,qty,x,y)
    if placed and result~=false then return true,x,y end
   end
  end
 end
 return false,'Не удалось разместить товар около центра карты.'
end

local function market_menu()
 local sites=alem.buildings('sc_market') or {}
 local completed=false
 if type(sites)=='table' then for _,site in pairs(sites) do if type(site)=='table' and (site.built==true or site.built==1) then completed=true;break end end end
 if not completed then note('Рынок','Постройте государственный рынок для торговли с караванами.');return end
 -- All three currencies exist in the vanilla game as physical resources.
 -- Earlier versions deposited silver into script-only Mark/Gold accounts: preserve those deposits.
 local coin_id={['Марки']='ImperialMark',['Серебро']='Silver',['Золото']='Gold'}
 local legacy_key={['Марки']='market_marks',['Золото']='market_gold'}
 local function stored(currency) return stock_count(coin_id[currency]) end
 local function legacy(currency)
  local key=legacy_key[currency]
  return key and math.max(0,math.floor(tonumber(get(key,0)) or 0)) or 0
 end
 local function balance(currency) return stored(currency)+legacy(currency) end
 local function currency_price(marks,currency)
  local marks_per_silver=market_marks_per_ten(day())/10
  if currency=='Марки' then return marks end
  if currency=='Золото' then return math.ceil(marks/(10*marks_per_silver)) end
  return math.ceil(marks/marks_per_silver)
 end
 -- Withdraw from the previous-version account first, and then from physical stock.
 -- Never grant the purchased goods if the engine did not actually subtract the currency.
 local function currency_take(currency,amount)
  amount=math.floor(tonumber(amount) or 0)
  if amount<=0 then return true end
  if balance(currency)<amount then return false end
  local key=legacy_key[currency]
  local credit=legacy(currency)
  local from_account=math.min(credit,amount)
  local from_stock=amount-from_account
  if from_stock>0 then
   local id=coin_id[currency]
   local before=stock_count(id)
   if before<from_stock then return false end
   local ok,result=pcall(alem.take,id,from_stock)
   if not ok or result==false then
    pcall(alem.log,'Statecraft: currency withdrawal failed for '..id..': '..tostring(result))
    return false
   end
   local after=stock_count(id)
   if after>before-from_stock then
    pcall(alem.log,'Statecraft: currency withdrawal could not be verified for '..id)
    return false
   end
  end
  if from_account>0 then set(key,credit-from_account) end
  return true
 end
 local function currency_give(currency,amount)
  if amount<=0 then return false end
  local id=coin_id[currency]
  local ok,result=pcall(alem.give,id,amount)
  if not ok or result==false then
   pcall(alem.log,'Statecraft: currency deposit failed for '..id..': '..tostring(result))
   -- Protect old bank accounts in case mod resource creation is not available.
   local key=legacy_key[currency]
   if key then set(key,legacy(currency)+amount);return true end
   return false
  end
  return true
 end
 local show_factions
 local exchange_menu
 local function wallet_report()
  local msg='Валюта, которую распознаёт игровой склад:\n'
  for _,currency in ipairs({'Марки','Серебро','Золото'}) do
   msg=msg..currency..' ('..coin_id[currency]..'): '..stored(currency)
   if legacy(currency)>0 then msg=msg..' + '..legacy(currency)..' на старом торговом счёте' end
   msg=msg..'\n'
  end
  msg=msg..'\nЕсли монеты видны на земле, а на складе 0: назначьте зону склада, разрешите валюту и дождитесь, пока колонисты перенесут её. Монеты на земле нельзя списывать без подтверждения игры.'
  alem.dialog('Проверка валюты',msg,{'← В монетный двор','✕ Закрыть'},function(i) if i==1 then exchange_menu(2) end end)
 end
 -- Two pages: max 5 buttons. Quote uses the same daily rate for both directions.
 local function exchange_action(direction,qty)
  local mid=market_marks_per_ten(day())
  local source,target,required,received
  if direction=='ms' then source='Марки';target='Серебро';required=math.ceil(mid*qty/10);received=qty
  elseif direction=='sm' then source='Серебро';target='Марки';required=qty;received=math.floor(mid*qty/10)
  elseif direction=='sg' then source='Серебро';target='Золото';required=10*qty;received=qty
  elseif direction=='gm' then source='Золото';target='Марки';required=qty;received=math.floor(mid*qty*0.95)
  else return end
  if received<=0 then note('Монетный двор','Слишком маленькая сумма для этого обмена.');return end
  local back=(direction=='ms' or direction=='sm') and 1 or 2
  local text='День '..day()..'. Сегодня 10 серебра = '..mid..' марок.\nОтдаёте: '..required..' ('..source..').\nПолучаете: '..received..' ('..target..').\nДоступно: '..balance(source)..'.'
  alem.dialog('Подтверждение обмена',text,{'✓ Обменять','← Назад','✕ Закрыть'},function(c)
   if c==2 then exchange_menu(back);return end
   if c~=1 then return end
   if balance(source)<required then note('Недостаточно средств','Нет нужного количества '..source..'. Проверьте, перенесены ли монеты на склад.');exchange_menu(back);return end
   if not currency_take(source,required) then note('Обмен не проведён','Игра не подтвердила списание '..source..'. Проверьте склад или игровой журнал.');exchange_menu(back);return end
   if not currency_give(target,received) then
    -- Refund the withdrawn currency; never keep money from failed exchange.
    currency_give(source,required)
    note('Обмен не проведён','Выдача денег не удалась; внесённая сумма возвращена.')
   else
    chronicle('Монетный двор: '..required..' '..source..' → '..received..' '..target)
    note('Обмен завершён',required..' '..source..' → '..received..' '..target..'. Новые монеты добавлены в колонию; если они лежат на земле, перенесите их на склад.')
   end
   exchange_menu(back)
  end)
 end
 exchange_menu=function(page)
  page=page or 1
  local mid=market_marks_per_ten(day())
  local caption='На складе и торговом счёте:\nМарки: '..balance('Марки')..' | Серебро: '..balance('Серебро')..' | Золото: '..balance('Золото')..'\nБазовый курс: 5 марок = 1 серебро, 10 серебра = 1 золото. Сегодня 10 серебра = '..mid..' марок.'
  if page==1 then
   local opts={'Марки → серебро','Серебро → марки','Далее →','← К караванам','✕ Закрыть'}
   alem.dialog('Монетный двор • 1/2',caption,opts,function(c)
    if c==1 then
     alem.dialog('Марки → серебро','Выберите количество серебра.',{'1 серебро','5 серебра','10 серебра','← Назад','✕ Закрыть'},function(q) if q<=3 then exchange_action('ms',({1,5,10})[q]) elseif q==4 then exchange_menu(1) end end)
    elseif c==2 then
     alem.dialog('Серебро → марки','Сколько серебра обменять?',{'1 серебро','5 серебра','10 серебра','← Назад','✕ Закрыть'},function(q) if q<=3 then exchange_action('sm',({1,5,10})[q]) elseif q==4 then exchange_menu(1) end end)
    elseif c==3 then exchange_menu(2)
    elseif c==4 then show_factions(2) end
   end)
  else
   local opts={'Серебро → золото','Золото → марки','Проверить валюту','← Назад','✕ Закрыть'}
   alem.dialog('Монетный двор • 2/2',caption,opts,function(c)
    if c==1 then
     alem.dialog('Серебро → золото','10 серебра = 1 золотая монета.',{'1 золотая монета','2 золотые монеты','← Назад','✕ Закрыть'},function(q) if q<=2 then exchange_action('sg',q) elseif q==3 then exchange_menu(2) end end)
    elseif c==2 then
     alem.dialog('Золото → марки','Выберите количество золотых монет.',{'1 золотая монета','2 золотые монеты','← Назад','✕ Закрыть'},function(q) if q<=2 then exchange_action('gm',q) elseif q==3 then exchange_menu(2) end end)
    elseif c==3 then wallet_report()
    elseif c==4 then exchange_menu(1) end
   end)
  end
 end
 local function prices_menu()
  local function faction_page(page)
   local first=(page-1)*2+1;local labels={};local actions={}
   for fi=first,math.min(first+1,#trade_factions) do labels[#labels+1]=trade_factions[fi];actions[#labels]=fi end
   if page>1 then labels[#labels+1]='← Назад';actions[#labels]='prev' end
   if first+1<#trade_factions then labels[#labels+1]='Далее →';actions[#labels]='next' end
   labels[#labels+1]='✕ Закрыть';actions[#labels]='close'
   local today=market_marks_per_ten(day());local yesterday=market_marks_per_ten(math.max(1,day()-1))
   local trend=today>yesterday and '↑ марок больше' or today<yesterday and '↓ марок меньше' or 'без изменений'
   alem.dialog('Цены на рынке • '..page..'/2','День '..day()..'. За 10 серебра: '..today..' марок ('..trend..' относительно вчера).\nВыберите фракцию для подробных цен.',labels,function(c)
    local a=actions[c];if a=='prev' then faction_page(page-1) elseif a=='next' then faction_page(page+1) elseif type(a)=='number' then
     local fi=a
     local function category_page(cp)
      local start=(cp-1)*2+1;local opts={};local acts={}
      for ci=start,math.min(start+1,#market_categories) do opts[#opts+1]=market_categories[ci][1];acts[#opts]=ci end
      if cp>1 then opts[#opts+1]='← Назад';acts[#opts]='prev' end
      if start+1<#market_categories then opts[#opts+1]='Далее →';acts[#opts]='next' end
      opts[#opts+1]='✕ Закрыть';acts[#opts]='close'
      alem.dialog('Цены • '..trade_factions[fi],'Выберите категорию. Красные ↑ — подорожали, зелёные ↓ — подешевели относительно вчера.',opts,function(k)
       local x=acts[k];if x=='prev' then category_page(cp-1) elseif x=='next' then category_page(cp+1) elseif type(x)=='number' then
        local ci=x;local items=market_categories[ci][2];local registry=market_registry();local visible={};local seen={}
        for gi,v in ipairs(items) do if registry[string.lower(v[1])] and not seen[v[2]] then visible[#visible+1]={gi,v};seen[v[2]]=true end end
        local function goods_prices(gp)
         local start=(gp-1)*2+1;local buttons={};local lines={};local actions={}
         for i=start,math.min(start+1,#visible) do
          local gi,v=visible[i][1],visible[i][2];local now=market_mark_price(day(),fi,ci,gi,v[4],v[1]);local old=market_mark_price(math.max(1,day()-1),fi,ci,gi,v[4],v[1]);local delta=now-old
          lines[#lines+1]=v[2]..': '..now..' мар. ('..(delta>0 and ('↑ +'..delta) or delta<0 and ('↓ '..delta) or '= без изменений')..')'
         end
         if gp>1 then buttons[#buttons+1]='← Назад';actions[#buttons]='prev' end
         if start+1<#visible then buttons[#buttons+1]='Далее →';actions[#buttons]='next' end
         buttons[#buttons+1]='К категориям';actions[#buttons]='categories'
         buttons[#buttons+1]='✕ Закрыть';actions[#buttons]='close'
         alem.dialog(trade_factions[fi]..' • '..market_categories[ci][1],table.concat(lines,'\n')..'\nИзменение цен за день.',buttons,function(q)
          if actions[q]=='prev' then goods_prices(gp-1) elseif actions[q]=='next' then goods_prices(gp+1) elseif actions[q]=='categories' then category_page(cp) end
         end)
        end
        goods_prices(1)
       end
      end)
     end
     category_page(1)
    end
   end)
  end
  faction_page(1)
 end
 show_factions=function(page)
  page=page or 1
  local first=(page-1)*2+1;local opts={};local actions={}
  for fi=first,math.min(first+1,#trade_factions) do opts[#opts+1]=trade_factions[fi];actions[#opts]=fi end
  if page==1 then
   opts[#opts+1]='📈 Цены на рынке';actions[#opts]='prices'
   opts[#opts+1]='Далее →';actions[#opts]='next'
  else
   opts[#opts+1]='Монетный двор';actions[#opts]='exchange'
   opts[#opts+1]='← Назад';actions[#opts]='prev'
  end
  opts[#opts+1]='✕ Закрыть';actions[#opts]='close'
  alem.dialog('Большой рынок • '..page..'/2','Серебро: '..balance('Серебро')..' | Марки: '..balance('Марки')..' | Золото: '..balance('Золото')..'\nВыберите караван, сводку цен или обмен валют.',opts,function(c)
   local fi=actions[c]
   if fi=='prices' then prices_menu();return end
   if fi=='exchange' then exchange_menu();return end
   if fi=='next' then show_factions(2);return end
   if fi=='prev' then show_factions(1);return end
   if type(fi)~='number' then return end
  if fi<1 or fi>4 then return end
   local categories
   local function goods_page(ci,page)
    local goods=market_inventory(ci,fi);local first=page;local buttons={};local actions={}
    for i=first,math.min(first,#goods) do
     local v=goods[i];buttons[#buttons+1]=v[2]..' ×'..v[3]..' ('..v[4]..' мар./шт)';actions[#buttons]=i
    end
    if page>1 then buttons[#buttons+1]='← Назад';actions[#buttons]='prev' end
    if first<#goods then buttons[#buttons+1]='Далее →';actions[#buttons]='next' end
    buttons[#buttons+1]='Категории';actions[#buttons]='exit'
    buttons[#buttons+1]='✕ Закрыть';actions[#buttons]='close'
    local msg='Запасы и цены обновляются ежедневно. Доставка на землю в центре колонии.\nСеребро: '..balance('Серебро')..' | Марки: '..balance('Марки')..' | Золото: '..balance('Золото')
    if #goods==0 then msg=msg..'\nУ этого каравана сейчас нет товаров в этой категории.' end
    alem.dialog(market_categories[ci][1]..' • '..page,msg,buttons,function(c)
     local a=actions[c]
     if a=='prev' then goods_page(ci,page-1);return end
     if a=='next' then goods_page(ci,page+1);return end
     if a=='exit' then categories(1);return end
     if type(a)~='number' then return end
     local v=goods[a];if not v then return end
     local function quantities()
      local amounts={1,5,10,20,v[3]};local opts={};local actions={};local seen={}
      for _,n in ipairs(amounts) do if n<=v[3] and not seen[n] then opts[#opts+1]='Купить ×'..n;actions[#opts]=n;seen[n]=true end end
      -- At most 5 buttons; large lots are on a second page if necessary.
      local function qty_page(qp)
       local start=qp;local labels={};local act={}
       for j=start,math.min(start,#opts) do labels[#labels+1]=opts[j];act[#labels]=actions[j] end
       if qp>1 then labels[#labels+1]='← Назад';act[#labels]='prev' end
       if start<#opts then labels[#labels+1]='Далее →';act[#labels]='next' end
       labels[#labels+1]='К товарам';act[#labels]='exit'
       labels[#labels+1]='✕ Закрыть';act[#labels]='close'
       alem.dialog(v[2],'Доступно сегодня: '..v[3]..' шт.\nСегодня: '..v[4]..' марок за штуку до скидки. Получение мгновенное.',labels,function(choice)
        local qty=act[choice]
        if qty=='prev' then qty_page(qp-1);return end
        if qty=='next' then qty_page(qp+1);return end
        if qty=='exit' then goods_page(ci,page);return end
        if type(qty)~='number' then return end
        local base=math.max(1,math.ceil(v[4]*qty*(100-policy_discount())/100))
        local function choose_currency()
         local opts={'Марки — '..currency_price(base,'Марки'),'Серебро — '..currency_price(base,'Серебро'),'Золото — '..currency_price(base,'Золото'),'← Назад','✕ Закрыть'}
         alem.dialog('Оплата заказа',v[2]..' ×'..qty..'\nВыберите валюту. Товары появятся на земле в центре колонии сразу после оплаты.',opts,function(c)
          if c==4 then qty_page(qp);return end
          if c==5 then return end
          local currency=({'Марки','Серебро','Золото'})[c];if not currency then return end
          local price=currency_price(base,currency)
          if currency=='Золото' and get('market_gold_spent_day',-1)==day() and get('market_gold_spent',0)+price>2 then note('Рынок','За день можно потратить не более двух золотых монет.');return end
          if currency=='Золото' and get('market_gold_spent_day',-1)~=day() and price>2 then note('Рынок','За день можно потратить не более двух золотых монет.');return end
          if balance(currency)<price then note('Рынок','Недостаточно средств.');return end
          local stock=get(v[5],v[6]);if stock<qty then note('Рынок','Товар уже раскуплен.');return end
          if not currency_take(currency,price) then
           note('Рынок','Игра не подтвердила списание средств. Проверьте наличие монет в зоне склада.');return
          end
          -- Grant the goods NOW.  In case of failure return the withdrawn money,
          -- do not touch daily stock and never create a delayed duplicate.
          local ok_grant,x,y=market_spawn_at_center(v[1],qty)
          if not ok_grant then
           pcall(alem.log,'Statecraft delivery: '..tostring(x)..' for '..v[1]..' x'..qty)
           if not currency_give(currency,price) then
            pcall(alem.log,'Statecraft market: failed to refund '..currency..' x'..price)
            note('Ошибка покупки','Товар не выдан. Не удалось автоматически вернуть оплату — сохраните журнал ошибки.')
           else
            note('Покупка отменена','Игра не смогла выдать товар. Оплата возвращена.')
           end
           return
          end
          set(v[5],stock-qty)
          if currency=='Золото' then
           local spent=get('market_gold_spent_day',-1)==day() and get('market_gold_spent',0) or 0
           set('market_gold_spent_day',day());set('market_gold_spent',spent+price)
          end
          chronicle('Рынок: '..v[2]..' ×'..qty..' за '..price..' ('..currency..')')
          note('Покупка получена',v[2]..' ×'..qty..' доставлены на землю в центре колонии ('..x..', '..y..'). Остаток у каравана: '..(stock-qty))
         end)
        end
        choose_currency()
       end)
      end
      qty_page(1)
     end
     quantities()
    end)
   end
   categories=function(cp)
    local first=cp;local buttons={};local actions={}
    for i=first,math.min(first,#market_categories) do buttons[#buttons+1]=market_categories[i][1];actions[#buttons]=i end
    if cp>1 then buttons[#buttons+1]='← Назад';actions[#buttons]='prev' end
    if first<#market_categories then buttons[#buttons+1]='Далее →';actions[#buttons]='next' end
    buttons[#buttons+1]='К караванам';actions[#buttons]='exit'
    buttons[#buttons+1]='✕ Закрыть';actions[#buttons]='close'
    alem.dialog('Рынок • '..trade_factions[fi],'Категории товаров. Дневные остатки и цены обновляются каждое утро.',buttons,function(c)
     local a=actions[c]
     if a=='prev' then categories(cp-1);return end
     if a=='next' then categories(cp+1);return end
     if a=='exit' then show_factions(1);return end
     if type(a)=='number' then goods_page(a,1) end
    end)
   end
   categories(1)
  end)
 end
 show_factions()
end
local function mobilize()
 -- Basic drafting is available immediately; the research improves military supply.
 -- Triggering the original button on day one must not fail or require research.
 local current=get('mobilized',0)==1
 local o=current and {'Снять мобилизацию','Назад'} or {'Мобилизовать всех колонистов','Назад'}
 alem.dialog('Военная мобилизация','Режим: '..(current and 'боевой' or 'мирный')..'. Все жители будут призваны к обороне. При отмене вернутся к обычным занятиям.',o,function(i)
  if i~=1 then return end
  local on=not current;local people=names();local successes=0
  for _,name in ipairs(people) do
   local ok,result=pcall(alem.draft,name,on)
   if ok and result~=false then successes=successes+1
   else pcall(alem.log,'Statecraft mobilisation: '..tostring(name)..' '..tostring(result)) end
  end
  if successes~=#people then
   note('Мобилизация','Не удалось изменить режим всех колонистов. Успешно: '..successes..' из '..#people..'.');return
  end
  set('mobilized',on and 1 or 0)
  chronicle(on and 'Объявлена мобилизация' or 'Мобилизация отменена')
  note('Военная мобилизация',on and ('К обороне призваны '..successes..' колонистов.') or 'Колонисты возвращены к мирной работе.')
 end)
end
-- Two main governmental pages and a third page for ongoing programs.
-- Smaller pages keep action buttons accessible on Android screens.
local function sc_ork_recon_fallback()
 local battles=tonumber(alem.get('sc_ork_battles',0)) or 0
 local tier=math.floor(battles/3)
 local points=math.floor((95+battles*55+tier*100)*(1+battles*0.28))
 local next_day=tonumber(alem.get('sc_ork_next',0)) or 0
 local active=alem.get('sc_ork_active',0)==1
 alem.dialog('Орочья разведка',
  'Пережито битв: '..battles..'\nСила следующей Вааагх!: '..points..
  '\nСтатус: '..(active and 'идёт нападение' or 'орда собирается')..
  '\nПланируемый налёт: '..(next_day>0 and ('день '..next_day) or 'пока неизвестен'),
  {'Закрыть'},function() end)
end
local function main()
 local entries={
  {'Выборы',elect}, {'Идеология',ideology}, {'Возвышение правителя',ascend_ruler},
  {'Торговля и караваны',market_menu}, {'Обзор',status}, {'Казна',treasury},
  {'Эффекты идеологий',ideology_statistics}, {'Законы',laws_menu},
  {'Мобилизация',mobilize}, {'Орочья разведка',sc_ork_recon_fallback},
  {'Статистика',statistics}, {'Летопись',history_menu},
  {'Национальные фокусы',focuses}, {'Государственные программы',programs},
  {'Дипломатия',ultimatum}, {'Военная готовность',defense}
 }
 local total=math.ceil(#entries/2)
 local function show_page(page)
  local start=(page-1)*2+1;local labels={};local actions={}
  for i=start,math.min(start+1,#entries) do labels[#labels+1]=entries[i][1];actions[#labels]=i end
  if page>1 then labels[#labels+1]='← Назад';actions[#labels]='prev' end
  if page<total then labels[#labels+1]='Далее →';actions[#labels]='next' end
  labels[#labels+1]='✕ Закрыть';actions[#labels]='close'
  local msg='ПВ: '..tostring(get('pp',0))..' | Казна: '..tostring(get('reserve',0))..' | Население: '..tostring(count())..'\nВыберите раздел.'
  alem.dialog('Государство — '..page..'/'..total,msg,labels,function(i)
   local action=actions[i]
   if action=='prev' then show_page(page-1);return end
   if action=='next' then show_page(page+1);return end
   if type(action)=='number' then
    local item=entries[action];local ok,err=pcall(item[2])
    if not ok then pcall(alem.log,'Statecraft menu action ('..item[1]..'): '..tostring(err));pcall(alem.letter,'Ошибка раздела',tostring(err)) end
   end
  end)
 end
 show_page(1)
end
alem.on('on_research_done',function(id)
 if type(id)=='string' and string.sub(id,1,3)=='sc_' then
  if get('tech_'..id,0)~=1 then
   set('tech_'..id,1)
   local rewards={sc_administration={'Silver',12},sc_council={'Food',18},sc_economy={'Wood',25},sc_diplomacy={'Silver',16},sc_intelligence={'Silver',12},sc_ultimatum={'Steel',12},sc_defense={'Steel',22},sc_army={'Steel',18},sc_industry={'Steel',25},sc_agriculture={'Food',35},sc_treasury={'Silver',24},sc_laws={'Food',16},sc_education={'Cloth',18},sc_records={'Wood',20},sc_festivals={'Food',30},sc_market={'Silver',22}}
   local v=rewards[id]
   if v then give(v[1],v[2]);note('Исследование завершено','Получены дополнительные государственные припасы: '..v[2]..' ед.')
   else alem.mood_all(2,1,'Новые знания');note('Исследование завершено','Новые знания повысили настроение жителей на сутки.') end
  end
 end
end)
alem.on('on_hour',function(h)
 local r=ruler()
 if r~='' then alem.memory(r,10,0.06,'Я — правитель') end
 if enemy_count()>0 and get('alert_day',-1)~=day() then
  set('alert_day',day());note('Тревога!','Враги обнаружены возле колонии!')
 end
end)
alem.on('on_day',function(d)
 if d<=get('last_day',-1) then return end
 set('last_day',d)
 if get('ascended_ruler','')~='' and not alive(get('ascended_ruler','')) then
  set('ascended_ruler','');set('ascended_title','')
 end
 if get('order_due',0)>0 and d>=get('order_due',0) then
  local item=get('order_item','Wood');local qty=get('order_qty',0)
  if qty>0 then alem.give(item,qty);note('Торговый караван прибыл',get('order_faction','Купцы')..' доставили '..item..' ×'..qty) end
  set('order_due',0);set('order_qty',0)
 end
 -- Finish deliveries from version 16.14 and older saves; new purchases arrive instantly.
 local remaining={};local arrivals={}
 for due,item,qty in string.gmatch(get('market_queue',''),'(%d+)|([%w_]+)|(%d+);') do
  if tonumber(due)<=d then
   local ok=pcall(alem.give,item,tonumber(qty))
   if ok then arrivals[#arrivals+1]=item..' ×'..qty else remaining[#remaining+1]=due..'|'..item..'|'..qty..';' end
  else remaining[#remaining+1]=due..'|'..item..'|'..qty..';' end
 end
 set('market_queue',table.concat(remaining))
 if #arrivals>0 then note('Рынок: доставка','Прибыли заказы: '..table.concat(arrivals,', ')) end
 if enemy_count()>0 and d>get('alarm_day',-10) then
  set('alarm_day',d);note('Тревога!','Обнаружены враги. Проверьте оборону поселения.')
 end
 law_tick(d)
 policy_tick(d)
 if get('mobilized',0)==1 then
  for _,person in ipairs(names()) do
   if type(person)=='string' then pcall(alem.draft,person,true) end
  end
 end
 local population=math.max(0,count())
 local previous=get('last_population',-1)
 local income=daily_income(population)
 set('last_population',population)
 set('last_income',income)
 if income>0 then pp(income) end
 if known('sc_logistics') and d%5==0 then ledger('Wood',8);ledger('Food',8) end
 if known('sc_culture') then alem.mood_all(1,0.95,'Общественные пространства') end
 if known('sc_memorial_tech') and d%5==0 then alem.mood_all(2,1,'Память о прошлом') end
 if known('sc_public_furniture') then alem.mood_all(1,0.95,'Удобства поселения') end
 if known('sc_street_light') and d%3==0 then alem.mood_all(1,1,'Освещённые улицы') end

 if get('ascended_ruler','')~='' and get('ascended_ruler','')==ruler() then
  pp(10);alem.mood_all(10,0.95,'Правление возвышенного владыки')
  give('Steel',15);give('Food',20);give('Wood',15);give('Silver',8)
 end
 local ok,err=pcall(conviction_tick)
 if not ok then alem.log("Statecraft traits: "..tostring(err)) end
 local change=''
 if previous>=0 and previous~=population then
  change='\nИзменение населения: '..previous..' -> '..population..'. Новый диапазон: '..population..'–'..(population+math.min(4,population))..' ПВ/день.'
 end
 note('Политическая власть','День '..d..'. Население: '..population..'. Начислено: +'..income..' ПВ. Всего: '..get('pp',0)..'.'..change)
 local i=get('ideology',0);local v=ideologies[i]
 if v then
  alem.mood_all(v[2],1,v[3])
  if d%v[4]==0 then
   local pick=v[5][math.random(1,#v[5])]
   local item,lo,hi=pick[1],pick[2],pick[3]
   if pick[4] then
    local ok,ids=false,nil;local present={}
    if type(alem.ids)=='function' then ok,ids=pcall(alem.ids,'resources') end
    if ok and type(ids)=='table' then for _,entry in pairs(ids) do local id=type(entry)=='string' and entry or (type(entry)=='table' and entry.id or nil);if type(id)=='string' then present[string.lower(id)]=id end end end
    if present[string.lower(item)] then item=present[string.lower(item)] else item,lo,hi=pick[4],pick[5],pick[6] end
   end
   local qty=math.random(lo,hi);give(item,qty)
   note('Поставки: '..v[1],v[6]..'\nПолучено: '..item..' ×'..qty)
  end
 end
 answer(d)
 local deliveries={{1,4,'Wood',16,'Steel',12},{2,3,'Steel',16,nil,0},{3,5,'Food',40,nil,0},{7,5,'Steel',12,'Food',20}}
 for _,v in ipairs(deliveries) do
  if d<get('program_end_'..v[1],0) and d%v[2]==0 then
   give(v[3],v[4]);if v[5] then give(v[5],v[6]) end
   note('Государственная программа',reforms[v[1]][1]..': поставка получена.')
  end
 end
 if d<get('program_end_4',0) and d%3==0 then alem.mood_all(2,1,'Государственное образование') end
 if d<get('program_end_8',0) then pp(3) end
 if d>=get('event_next',8) then
  set('event_next',d+math.random(8,13))
  local ev=math.random(1,5)
  if ev==1 then give('Food',35);note('Урожайный год','Дополнительно +35 еды.');set('event_last','Урожайный год')
  elseif ev==2 then alem.mood_all(-2,2,'Забастовка');note('Забастовка','-2 настроения на 2 дня.');set('event_last','Забастовка')
  elseif ev==3 then local loss=math.min(get('pp',0),12);set('pp',get('pp',0)-loss);note('Коррупционный скандал','Потеряно '..loss..' ПВ.');set('event_last','Коррупционный скандал')
  elseif ev==4 then alem.mood_all(3,2,'Государственный праздник');note('Государственный праздник','+3 настроения на 2 дня.');set('event_last','Государственный праздник')
  else set('ult_next',math.max(get('ult_next',0),d+2));note('Пограничный инцидент','Посольства задержаны на 2 дня.');set('event_last','Пограничный инцидент') end
 end
end)
alem.on('on_colonist_died',function(n)
 if n==get('ruler','') then demote_former(n);set('ruler','');chronicle('Правитель погиб: '..tostring(n));note('Смерть правителя','Должность свободна. Следующие выборы доступны после установленного срока.') end
end)

-- Оповещение о повреждении постройки; частота ограничена одним письмом в день.
alem.on('on_building_damaged',function(...)
 if day()>get('alarm_day',-10) then set('alarm_day',day());note('Нападение!','Повреждена постройка. Проверьте оборону поселения.') end
end)

-- Version 16.6: the government lives in the hammer fan, with a proper icon.
local function sc_open_government()
 local ok,err=pcall(main)
 if not ok then
  pcall(alem.log,'Statecraft menu open error: '..tostring(err))
  pcall(alem.letter,'Ошибка меню «Государство»',tostring(err))
 end
end
local sc_government_registered=false
local function sc_register_government()
 if sc_government_registered then return end
 -- Remove a leftover HUD button created by an older release.
 if type(alem.button_remove)=='function' then pcall(alem.button_remove,'Государство') end
 if type(alem.menu_button)=='function' then
  local ok,result=pcall(alem.menu_button,'Государство','icon_sc_administration',sc_open_government)
  if ok and result~=false then sc_government_registered=true;return end
  pcall(alem.log,'Statecraft hammer registration: '..tostring(result))
 end
 -- Compatibility fallback for releases without hammer-menu API.
 if type(alem.button)=='function' then
  local ok,result=pcall(alem.button,'Государство',sc_open_government)
  if ok and result~=false then sc_government_registered=true
  else pcall(alem.log,'Statecraft button registration: '..tostring(result)) end
 end
end
sc_register_government()
-- If the UI wasn't ready at script initialization, retry after world load.
alem.on('on_load',sc_register_government)
alem.on('on_map_generated',sc_register_government)

-- v13.2: controlled ruins weapon/ammo spawning; zero ammunition without corresponding weapon.
local sc_ruin_profiles = {
  ["sc_ruin_settlement_01"]={kind="warehouse",points={{25,18},{6,12},{11,6},{8,2}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}},
  ["sc_ruin_settlement_02"]={kind="dorm",points={{10,20},{6,19},{5,14}},weapons={"knife","club","bow","pistol"},odds={0.60,0.35,0.05}},
  ["sc_ruin_settlement_03"]={kind="workshop",points={{10,27},{18,25},{19,3}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}},
  ["sc_ruin_settlement_04"]={kind="mixed",points={{18,10},{14,4}},weapons={"knife","club","bow","crossbow","pistol","musket","rifle","sword"},odds={0.40,0.47,0.13}},
  ["sc_ruin_settlement_05"]={kind="warehouse",points={{18,33},{5,27},{21,7},{18,5}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}},
  ["sc_ruin_settlement_06"]={kind="dorm",points={{19,14},{21,14}},weapons={"knife","club","bow","pistol"},odds={0.60,0.35,0.05}},
  ["sc_ruin_settlement_07"]={kind="workshop",points={{17,33},{20,33},{14,26},{9,5}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}},
  ["sc_ruin_settlement_08"]={kind="mixed",points={{11,17},{5,15},{26,13},{13,7},{15,3}},weapons={"knife","club","bow","crossbow","pistol","musket","rifle","sword"},odds={0.40,0.47,0.13}},
  ["sc_ruin_settlement_09"]={kind="warehouse",points={{25,30},{15,17},{13,10},{22,8},{27,3}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}},
  ["sc_ruin_settlement_10"]={kind="dorm",points={{17,29},{16,22},{15,15},{8,11},{7,7}},weapons={"knife","club","bow","pistol"},odds={0.60,0.35,0.05}},
  ["sc_ruin_settlement_11"]={kind="workshop",points={{4,20},{8,19},{26,13},{12,12},{21,8}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}},
  ["sc_ruin_settlement_12"]={kind="mixed",points={{17,24},{16,7},{22,6},{12,4},{33,1}},weapons={"knife","club","bow","crossbow","pistol","musket","rifle","sword"},odds={0.40,0.47,0.13}},
  ["sc_ruin_settlement_13"]={kind="warehouse",points={{17,20},{13,19},{10,12},{10,6}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}},
  ["sc_ruin_settlement_14"]={kind="dorm",points={{20,21},{20,11},{21,3}},weapons={"knife","club","bow","pistol"},odds={0.60,0.35,0.05}},
  ["sc_ruin_settlement_15"]={kind="workshop",points={{6,27},{28,22},{3,1}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}},
  ["sc_ruin_settlement_16"]={kind="mixed",points={{10,37},{2,23},{17,18},{23,6}},weapons={"knife","club","bow","crossbow","pistol","musket","rifle","sword"},odds={0.40,0.47,0.13}},
  ["sc_ruin_settlement_17"]={kind="warehouse",points={{19,24},{17,11},{16,10}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}},
  ["sc_ruin_settlement_18"]={kind="dorm",points={{7,18},{18,14},{10,11},{5,10},{21,3}},weapons={"knife","club","bow","pistol"},odds={0.60,0.35,0.05}},
  ["sc_ruin_outpost_01"]={kind="workshop",points={{9,7},{5,6}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}},
  ["sc_ruin_outpost_03"]={kind="warehouse",points={{24,6},{23,1}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}},
  ["sc_ruin_outpost_04"]={kind="dorm",points={{5,10}},weapons={"knife","club","bow","pistol"},odds={0.60,0.35,0.05}},
  ["sc_ruin_outpost_05"]={kind="workshop",points={{6,18}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}},
  ["sc_ruin_outpost_06"]={kind="mixed",points={{17,11}},weapons={"knife","club","bow","crossbow","pistol","musket","rifle","sword"},odds={0.40,0.47,0.13}},
  ["sc_ruin_outpost_07"]={kind="warehouse",points={{4,3},{7,2}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}},
  ["sc_ruin_outpost_08"]={kind="dorm",points={{3,3},{4,2}},weapons={"knife","club","bow","pistol"},odds={0.60,0.35,0.05}},
  ["sc_ruin_metropolis_01"]={kind="workshop",points={{29,27},{30,27},{31,27},{32,27},{33,27},{34,27},{35,27},{29,26},{30,26},{31,26},{32,26},{33,26},{34,26},{35,26},{29,25},{30,25},{31,25},{32,25},{33,25},{34,25},{35,25},{29,24},{30,24},{31,24},{32,24},{33,24},{34,24},{35,24},{21,23},{22,23},{23,23},{24,23},{25,23},{29,23},{30,23},{31,23},{32,23},{33,23},{34,23},{35,23},{21,22},{22,22},{23,22},{25,22},{30,22},{31,22},{32,22},{33,22},{34,22},{35,22},{21,21},{22,21},{23,21},{24,21},{25,21},{26,21},{29,21},{30,21},{31,21},{32,21},{34,21},{23,20},{24,20},{25,20},{26,20},{27,20},{29,20},{30,20},{31,20},{32,20},{33,20},{34,20},{35,20},{23,19},{24,19},{25,19},{26,19},{27,19},{24,15},{25,15},{26,15},{24,14},{25,14},{26,14},{27,14},{24,13},{25,13},{26,13},{27,13},{28,13},{30,13},{31,13},{32,13},{33,13},{34,13},{24,12},{25,12},{26,12},{27,12},{30,12},{31,12},{32,12},{33,12},{34,12},{24,11},{25,11},{26,11},{27,11},{28,11},{30,11},{31,11},{32,11},{33,11},{34,11},{30,10},{31,10},{32,10},{33,10},{34,10}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}},
  ["sc_ruin_metropolis_02"]={kind="mixed",points={{17,34},{1,30},{2,30},{3,30},{4,30},{5,30},{6,30},{1,29},{2,29},{3,29},{4,29},{6,29},{1,28},{2,28},{3,28},{4,28},{5,28},{6,28},{22,28},{23,28},{24,28},{1,27},{2,27},{3,27},{5,27},{6,27},{22,27},{23,27},{24,27},{1,26},{2,26},{3,26},{4,26},{5,26},{6,26},{22,26},{23,26},{24,26},{3,25},{4,25},{5,25},{22,25},{23,25},{24,25},{3,24},{4,24},{22,24},{23,24},{24,24},{22,23},{22,22},{31,21},{34,21},{35,21},{36,21},{37,21},{31,20},{32,20},{33,20},{34,20},{35,20},{36,20},{37,20},{31,19},{32,19},{33,19},{34,19},{35,19},{36,19},{37,19},{31,18},{32,18},{33,18},{34,18},{35,18},{36,18},{37,18},{31,17},{32,17},{33,17},{34,17},{35,17},{36,17},{37,17},{14,16},{11,14},{12,14},{13,14},{14,14},{15,14},{11,13},{12,13},{13,13},{14,13},{15,13},{11,12},{12,12},{14,12},{15,12},{12,11},{13,11},{14,11},{15,11},{23,11},{13,10},{14,10},{15,10},{6,7},{8,2}},weapons={"knife","club","bow","crossbow","pistol","musket","rifle","sword"},odds={0.40,0.47,0.13}},
  ["sc_ruin_metropolis_03"]={kind="warehouse",points={{19,24},{20,18},{35,17},{16,16},{15,12},{33,12},{14,11},{16,11},{28,9},{29,8},{30,7}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}},
  ["sc_ruin_metropolis_04"]={kind="dorm",points={{41,23},{35,22},{40,21},{42,21},{37,14},{32,13},{23,12},{32,12},{6,11},{4,9},{1,5},{11,4},{15,4},{17,3},{12,2},{13,2}},weapons={"knife","club","bow","pistol"},odds={0.60,0.35,0.05}},
  ["sc_ruin_metropolis_05"]={kind="workshop",points={{6,27},{7,27},{8,27},{6,26},{7,26},{8,26},{6,25},{7,25},{8,25},{22,25},{23,25},{24,25},{25,25},{26,25},{27,25},{28,25},{29,25},{30,25},{31,25},{32,25},{33,25},{6,24},{7,24},{8,24},{23,24},{24,24},{25,24},{26,24},{27,24},{28,24},{29,24},{30,24},{31,24},{32,24},{33,24},{6,23},{7,23},{8,23},{10,23},{11,23},{12,23},{22,23},{23,23},{24,23},{25,23},{26,23},{27,23},{28,23},{29,23},{30,23},{31,23},{32,23},{33,23},{7,22},{10,22},{11,22},{12,22},{22,22},{23,22},{24,22},{25,22},{26,22},{27,22},{28,22},{29,22},{30,22},{31,22},{32,22},{33,22},{10,21},{11,21},{12,21},{22,21},{23,21},{24,21},{25,21},{26,21},{27,21},{28,21},{29,21},{30,21},{31,21},{32,21},{33,21},{10,20},{11,20},{12,20},{22,20},{23,20},{24,20},{25,20},{26,20},{27,20},{28,20},{29,20},{30,20},{31,20},{32,20},{33,20},{10,19},{11,19},{22,19},{23,19},{24,19},{25,19},{26,19},{27,19},{28,19},{29,19},{30,19},{31,19},{32,19},{33,19},{10,18},{11,18},{12,18},{22,18},{23,18},{24,18},{25,18},{26,18},{27,18},{28,18},{29,18},{30,18},{31,18},{32,18},{33,18},{10,17},{11,17},{12,17},{22,17},{23,17},{24,17},{25,17},{26,17},{27,17},{28,17},{29,17},{30,17},{31,17},{32,17},{33,17},{31,15},{32,15},{33,15},{34,15},{35,15},{31,14},{32,14},{33,14},{34,14},{35,14},{36,14},{24,13},{25,13},{26,13},{27,13},{28,13},{29,13},{31,13},{32,13},{33,13},{34,13},{35,13},{36,13},{38,13},{39,13},{40,13},{41,13},{43,13},{44,13},{45,13},{46,13},{47,13},{48,13},{15,12},{16,12},{17,12},{18,12},{19,12},{20,12},{21,12},{22,12},{24,12},{25,12},{26,12},{27,12},{28,12},{29,12},{31,12},{33,12},{34,12},{35,12},{36,12},{38,12},{39,12},{40,12},{41,12},{42,12},{43,12},{44,12},{45,12},{46,12},{47,12},{48,12},{15,11},{16,11},{17,11},{18,11},{19,11},{20,11},{21,11},{22,11},{24,11},{26,11},{27,11},{28,11},{29,11},{31,11},{32,11},{33,11},{34,11},{35,11},{36,11},{38,11},{39,11},{40,11},{41,11},{42,11},{43,11},{44,11},{45,11},{46,11},{47,11},{48,11},{15,10},{17,10},{18,10},{19,10},{20,10},{21,10},{22,10},{24,10},{25,10},{26,10},{27,10},{28,10},{29,10},{15,9},{16,9},{17,9},{18,9},{19,9},{20,9},{21,9},{22,9},{24,9},{25,9},{26,9},{28,9},{15,8},{16,8},{17,8},{18,8},{19,8},{20,8},{21,8},{22,8},{24,8},{25,8},{26,8},{27,8},{28,8},{29,8},{15,7},{16,7},{17,7},{18,7},{19,7},{20,7},{21,7},{22,7},{15,6},{16,6},{17,6},{18,6},{19,6},{20,6},{21,6},{22,6}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}},
  ["sc_ruin_metropolis_06"]={kind="mixed",points={{1,45},{2,45},{3,45},{1,44},{2,44},{3,44},{4,44},{2,43},{3,43},{4,43},{5,43},{1,42},{2,42},{3,42},{4,42},{5,42},{1,41},{2,41},{3,41},{5,41},{1,40},{2,40},{3,40},{4,40},{5,40},{7,40},{8,40},{9,40},{10,40},{11,40},{12,40},{13,40},{14,40},{15,40},{16,40},{1,39},{2,39},{3,39},{4,39},{7,39},{8,39},{9,39},{10,39},{11,39},{12,39},{13,39},{14,39},{15,39},{16,39},{1,38},{2,38},{3,38},{7,38},{8,38},{9,38},{10,38},{12,38},{13,38},{14,38},{15,38},{16,38},{7,37},{8,37},{9,37},{10,37},{11,37},{12,37},{13,37},{14,37},{15,37},{16,37},{25,29},{26,29},{27,29},{28,29},{29,29},{30,29},{31,29},{32,29},{33,29},{25,28},{26,28},{27,28},{28,28},{29,28},{30,28},{31,28},{32,28},{33,28},{6,27},{17,27},{18,27},{19,27},{20,27},{21,27},{25,27},{26,27},{27,27},{28,27},{29,27},{30,27},{31,27},{32,27},{33,27},{17,26},{18,26},{19,26},{20,26},{21,26},{25,26},{26,26},{27,26},{28,26},{29,26},{30,26},{31,26},{32,26},{33,26},{17,25},{18,25},{19,25},{20,25},{21,25},{25,25},{26,25},{27,25},{28,25},{29,25},{30,25},{31,25},{32,25},{33,25},{17,24},{18,24},{19,24},{21,24},{25,24},{26,24},{27,24},{28,24},{29,24},{30,24},{31,24},{32,24},{33,24},{17,23},{18,23},{19,23},{20,23},{21,23},{25,23},{26,23},{27,23},{28,23},{30,23},{31,23},{32,23},{33,23},{17,22},{18,22},{19,22},{20,22},{21,22},{25,22},{26,22},{27,22},{28,22},{29,22},{30,22},{31,22},{32,22},{33,22},{6,18},{7,18},{8,18},{10,18},{11,18},{12,18},{13,18},{14,18},{15,18},{16,18},{17,18},{6,17},{7,17},{8,17},{9,17},{10,17},{11,17},{12,17},{13,17},{14,17},{15,17},{16,17},{17,17},{6,16},{7,16},{8,16},{9,16},{10,16},{11,16},{12,16},{13,16},{14,16},{15,16},{16,16},{17,16},{20,16},{6,15},{7,15},{8,15},{9,15},{10,15},{11,15},{12,15},{13,15},{14,15},{15,15},{16,15},{17,15},{6,14},{7,14},{8,14},{9,14},{10,14},{11,14},{12,14},{13,14},{14,14},{15,14},{16,14},{17,14},{23,14},{6,13},{7,13},{8,13},{9,13},{10,13},{11,13},{12,13},{13,13},{14,13},{15,13},{16,13},{17,13},{22,13},{6,12},{7,12},{8,12},{9,12},{10,12},{11,12},{12,12},{13,12},{14,12},{15,12},{16,12},{17,12},{21,12},{22,12},{23,12},{6,11},{7,11},{8,11},{9,11},{10,11},{11,11},{12,11},{13,11},{14,11},{15,11},{16,11},{17,11},{21,11},{22,11},{6,10},{7,10},{8,10},{9,10},{10,10},{11,10},{13,10},{14,10},{15,10},{16,10},{17,10},{21,10},{22,10},{23,10},{21,9},{22,9},{23,9},{21,8},{22,8},{23,8},{22,7},{23,7},{16,6},{17,6},{18,6},{19,6},{21,6},{22,6},{23,6},{15,5},{16,5},{17,5},{18,5},{19,5},{21,5},{22,5},{23,5},{15,4},{16,4},{17,4},{18,4},{19,4},{21,4},{22,4},{23,4},{15,3},{16,3},{17,3},{18,3},{19,3},{15,2},{16,2},{17,2},{18,2},{19,2},{15,1},{17,1},{18,1},{19,1}},weapons={"knife","club","bow","crossbow","pistol","musket","rifle","sword"},odds={0.40,0.47,0.13}},
}
local function sc_existing_id(group, candidates)
  local ok, ids = pcall(alem.ids, group)
  if not ok or type(ids) ~= 'table' then return nil end
  local found={}
  for _,v in pairs(ids) do
    local key=type(v)=='table' and v.id or v
    if type(key)=='string' then found[string.lower(key)]=key end
  end
  for _,candidate in ipairs(candidates) do
    if found[string.lower(candidate)] then return found[string.lower(candidate)] end
  end
  return nil
end
-- 14.3: Catastrophic cities use the same rare weapon / matched-ammo system as normal ruins.
sc_ruin_profiles["sc_odyssey_city_01"]={kind="workshop",points={{59,46},{8,39},{8,14},{50,53},{50,14},{68,39},{8,46},{17,14},{68,7},{26,39}},weapons={"crossbow","musket","rifle","sword","pistol"},odds={0.32,0.50,0.18}}
sc_ruin_profiles["sc_odyssey_city_02"]={kind="warehouse",points={{50,46},{26,7},{59,7},{17,53},{8,7},{59,14},{59,21},{59,39},{26,39},{50,53}},weapons={"pistol","crossbow","musket","rifle","sword","bow"},odds={0.38,0.48,0.14}}
sc_ruin_profiles["sc_odyssey_city_03"]={kind="mixed",points={{50,53},{8,46},{26,46},{50,7},{59,14},{26,53},{26,21},{8,53},{17,7},{68,14}},weapons={"knife","club","bow","crossbow","pistol","musket","rifle","sword"},odds={0.40,0.47,0.13}}
local sc_ammo_for={
  rifle={'RifleAmmo','RifleRound','RifleRounds','Ammo','Bullets','Bullet'},
  pistol={'PistolAmmo','PistolRound','PistolRounds','Ammo','Bullets','Bullet'},
  musket={'MusketAmmo','MusketBall','MusketBalls','Ammo','Bullets','Bullet'},
  bow={'Arrows','Arrow'}, crossbow={'Bolts','Bolt','CrossbowBolt','CrossbowBolts'}
}
local sc_ammo_counts={rifle={8,16},pistol={6,14},musket={4,10},bow={6,14},crossbow={5,12}}
local sc_component_candidates={
  {'Spring','Springs'}, {'Gear','Gears'}, {'Component','Components'},
  {'Gunpowder','Powder'}, {'MechanicalParts','Parts'}
}
alem.on('on_structure_placed',function(id,x,y)
  local profile=sc_ruin_profiles[id]
  if not profile or #profile.points==0 then return end
  local roll=math.random()
  local count=roll<profile.odds[1] and 0 or (roll<profile.odds[1]+profile.odds[2] and 1 or 2)
  local used={}
  local used_weapons={}
  for i=1,count do
    local candidates={}
    for _,w in ipairs(profile.weapons) do
      if not used_weapons[w] then
        local actual=sc_existing_id('weapons',{w})
        if actual then candidates[#candidates+1]={id=w,actual=actual} end
      end
    end
    if #candidates==0 then break end
    local selected=candidates[math.random(#candidates)]
    local free={}
    for j=1,#profile.points do if not used[j] then free[#free+1]=j end end
    if #free==0 then break end
    local j=free[math.random(#free)];used[j]=true;used_weapons[selected.id]=true
    local point=profile.points[j];local px=x+point[1];local py=y+point[2]
    local ok=pcall(alem.spawn_weapon,selected.actual,px,py)
    if ok and sc_ammo_for[selected.id] then
      local ammo=sc_existing_id('resources',sc_ammo_for[selected.id])
      if ammo then
        local range=sc_ammo_counts[selected.id]
        local amount=math.random(range[1],range[2])
        pcall(alem.spawn_item,ammo,amount,px,py)
      end
    end
  end
  -- Spare components: only warehouses/workshops, very low probability, one small stack.
  local odds=profile.kind=='workshop' and 0.12 or (profile.kind=='warehouse' and 0.06 or 0)
  if odds>0 and math.random()<odds then
    local order={1,2,3,4,5}
    for i=#order,2,-1 do local j=math.random(i);order[i],order[j]=order[j],order[i] end
    for _,index in ipairs(order) do
      local component=sc_existing_id('resources',sc_component_candidates[index])
      if component then
        local point=profile.points[math.random(#profile.points)]
        pcall(alem.spawn_item,component,math.random(1,3),x+point[1],y+point[2]);break
      end
    end
  end
end)
