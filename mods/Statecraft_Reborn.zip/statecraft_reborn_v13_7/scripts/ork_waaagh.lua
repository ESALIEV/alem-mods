-- Statecraft 16.4: persistent Ork Waaagh escalation. Separate script so 16.3 core is untouched.
local ork_name = 'Орочья Вааагх!'
local ork_key = 'sc_ork_' -- persistent keys saved through alem.get/set
local function ork_get(k, default) return alem.get(ork_key .. k, default) end
local function ork_set(k, value) alem.set(ork_key .. k, value) end
local function ork_id()
  local f = alem.faction(ork_name)
  return f and f.id or nil
end
local function ork_threat(wins)
  -- +28% each battle, plus linear reinforcement. Every third battle adds a larger horde.
  local tier = math.floor(wins / 3)
  return math.floor((95 + wins * 55 + tier * 100) * (1 + wins * 0.28))
end
local function ork_start_raid()
  local id = ork_id()
  if not id then
    alem.log('Орки: фракция пока не найдена; налёт отложен.')
    return false
  end
  local wins = ork_get('battles', 0)
  local points = ork_threat(wins)
  -- Set pending first; on_raid_planned must not multiply our points twice.
  ork_set('pending', 1)
  local ok, result = pcall(alem.raid_from, id, points)
  if not ok or result == false then
    ork_set('pending', 0)
    alem.log('Орки: raid_from не удалось: ' .. tostring(result))
    return false
  end
  ork_set('active', 1)
  ork_set('next', alem.day() + math.random(7, 11))
  alem.letter('ВАААГХ! — орки наступают',
    'Орочья орда атакует колонию! Битва №' .. (wins + 1) ..
    '. Сила налёта: ' .. points .. '. После каждого столкновения их армия растёт.')
  return true
end
alem.on('on_day', function(d)
  if ork_get('next', 0) == 0 then ork_set('next', d + math.random(9, 13)) end
  if ork_get('active', 0) == 0 and d >= ork_get('next', 0) then
    if not ork_start_raid() then ork_set('next', d + 2) end
  end
end)
alem.on('on_raid_planned', function(id, points)
  local oid = ork_id()
  if oid and tostring(id) == tostring(oid) then
    ork_set('active', 1)
    if ork_get('pending', 0) == 1 then
      ork_set('pending', 0)
      return nil
    end
    local wins = ork_get('battles', 0)
    return math.max(points or 0, ork_threat(wins))
  end
end)
alem.on('on_raid_end', function()
  if ork_get('active', 0) ~= 1 then return end
  ork_set('active', 0)
  ork_set('pending', 0)
  local battles = ork_get('battles', 0) + 1
  ork_set('battles', battles)
  ork_set('next', alem.day() + math.random(7, 11))
  local points = ork_threat(battles)
  alem.letter('Орки становятся сильнее',
    'Завершена битва с орками №' .. battles ..
    '. Следующая Вааагх! усилится: больше бойцов, больше тяжёлых воинов. Угроза: ' .. points .. '.')
  local id = ork_id()
  if id then pcall(alem.faction_note, id, 'Вааагх! усилилась после битвы №' .. battles .. '; угроза ' .. points) end
end)
-- Dedicated reconnaissance entry in the hammer fan.
local function ork_open_recon()
 local ok,err=pcall(function()
  local battles=tonumber(ork_get('battles',0)) or 0
  local active=ork_get('active',0)==1
  local next_day=tonumber(ork_get('next',0)) or 0
  alem.dialog('Орочья разведка',
    'Пережито битв: '..battles..'\nСила следующей Вааагх!: '..ork_threat(battles)..
    '\nСостояние: '..(active and 'идёт налёт' or 'собираются силы')..
    '\nСледующий налёт: '..(next_day>0 and ('не ранее дня '..next_day) or 'ещё не определён'),
    {'Закрыть'},function() end)
 end)
 if not ok then
  pcall(alem.log,'Ork reconnaissance: '..tostring(err))
  pcall(alem.letter,'Ошибка орочьей разведки',tostring(err))
 end
end
local ork_recon_registered=false
local function ork_register_recon()
 if ork_recon_registered then return end
 if type(alem.button_remove)=='function' then pcall(alem.button_remove,'ВАААГХ!: разведка') end
 if type(alem.menu_button)=='function' then
  local ok,result=pcall(alem.menu_button,'Орочья разведка','icon_sc_ork_recon',ork_open_recon)
  if ok and result~=false then ork_recon_registered=true;return end
  pcall(alem.log,'Ork hammer registration: '..tostring(result))
 end
 -- Older game versions: retain a simple button if hammer API is absent.
 if type(alem.button)=='function' then
  local ok,result=pcall(alem.button,'Орочья разведка',ork_open_recon)
  if ok and result~=false then ork_recon_registered=true
  else pcall(alem.log,'Ork button registration: '..tostring(result)) end
 end
end
ork_register_recon()
alem.on('on_load',ork_register_recon)
alem.on('on_map_generated',ork_register_recon)
