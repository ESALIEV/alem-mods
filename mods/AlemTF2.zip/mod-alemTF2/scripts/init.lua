-- init.lua
-- Система Уберзаряда: накопление от лечения, обнуление после активации

-- Хук: вызывается при касте любой способности
function on_spell_cast(pawn, spellId)
    -- Если медик лечит — добавляем 15 к Уберзаряду
    if spellId == "heal" then
        local current = alem.energy(pawn, "ubercharge") or 0
        local new_val = math.min(100, current + 15)
        alem.set_energy(pawn, "ubercharge", new_val)
    end

    -- Если медик активировал Уберзаряд — обнуляем шкалу
    if spellId == "ubercharge" then
        alem.set_energy(pawn, "ubercharge", 0)
    end
end
