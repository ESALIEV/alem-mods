-- scripts/gray_army.lua
-- Армия Грея требует дань. Не заплатил — приходят 12 бойцов.
-- Срабатывает только если богатство игрока >= 10000.

local FACTION      = "gray_army"
local TRIBUTE_ITEM = "australium"
local TRIBUTE_COST = 20
local RAID_COUNT   = 12
local MIN_WEALTH   = 10000

local demand_active = false

-- Богатство игрока (серебро). Подставь своё поле, если у тебя богатство считается иначе.
local function player_wealth()
    return alem.wealth and alem.wealth() or 0
end

-- Сколько австралиума в колонии
local function count_item(item_id)
    local total = 0
    for _, pawn in ipairs(alem.colonists() or {}) do
        local inv = alem.inventory(pawn)
        if inv then
            for _, slot in ipairs(inv) do
                if slot and slot.id == item_id then total = total + 1 end
            end
        end
    end
    return total
end

-- Списать австралиум
local function consume_item(item_id, amount)
    local need = amount
    for _, pawn in ipairs(alem.colonists() or {}) do
        local inv = alem.inventory(pawn)
        if inv then
            for i = #inv, 1, -1 do
                if need <= 0 then break end
                if inv[i] and inv[i].id == item_id then
                    table.remove(inv, i)
                    need = need - 1
                end
            end
            alem.set_inventory(pawn, inv)
        end
    end
    return amount - need
end

-- Старт требования: только если игрок достаточно богат
function gray_army_demand()
    if demand_active then return end

    if player_wealth() < MIN_WEALTH then
        return  -- игрок небогат — армия не приходит
    end

    demand_active = true
    alem.toast("Армия Грея требует 20 австралиума в течение 3 дней!")
end

-- Проверка по истечении срока
function gray_army_resolve()
    if not demand_active then return end
    demand_active = false

    if count_item(TRIBUTE_ITEM) >= TRIBUTE_COST then
        consume_item(TRIBUTE_ITEM, TRIBUTE_COST)
        alem.toast("Дань уплачена. Армия Грея довольна.")
    else
        alem.toast("Дань не уплачена! Армия Грея идёт на базу: " .. RAID_COUNT .. " бойцов!")
        for i = 1, RAID_COUNT do
            alem.spawn_raid(FACTION, "base")
        end
    end
end
