-- ============================================
-- AlemTF2: Профессии — ускорение крафта
-- только определённых предметов
-- ============================================

local Professions = {}

-- Список предметов для каждой профессии
local professionItems = {
  gunsmith = {
    "Ammo", "AmmoSmokeless", "MusketBall", "Arrow", "Bolts",
    "knife", "spear", "club", "axe", "sword", "mace", "morningstar",
    "halberd", "pike", "sabre", "bow", "javelin", "longbow",
    "composite_bow", "crossbow", "musket", "flintlock", "blunderbuss",
    "handcannon", "pistol", "shotgun", "rifle", "sniper", "smg",
    "tf2_bat", "tf2_shovel", "tf2_bottle", "tf2_shotgun", "tf2_pistol",
    "tf2_scattergun", "tf2_rocket_launcher", "tf2_flamethrower",
    "tf2_fire_axe", "tf2_grenade_launcher", "tf2_stickybomb_launcher",
    "tf2_minigun", "tf2_wrench", "tf2_syringe_gun", "tf2_bonesaw",
    "tf2_sniper_rifle", "tf2_smg", "tf2_kukri", "tf2_revolver",
    "tf2_knife", "tf2_ammo_box"
  },
  armorer = {
    "Cloth", "Leather", "Steel", "IronComponent",
    "Rivets", "Gears", "Springs", "SteelMechanism",
    "ProsthLegWood", "ProsthLegSteel", "BionicLeg",
    "BionicArm", "BionicEye"
  },
  demolitionist = {
    "Gunpowder", "Sulfur", "Saltpeter", "Grenade", "Molotov",
    "CannonBall", "Grapeshot", "Lead", "LeadOre"
  },
  combat_medic = {
    "Herbs", "Medicine", "Antibiotics", "mge_serum"
  }
}

-- Множители скорости крафта
local craftMultipliers = {
  gunsmith = 1.3,
  armorer = 1.2,
  demolitionist = 1.4,
  combat_medic = 1.15
}

-- Бонус к медицине
local medBonus = {
  combat_medic = 4
}

-- Построить обратный индекс: item -> profession
local itemToProfession = {}
for profId, items in pairs(professionItems) do
  for _, itemId in ipairs(items) do
    itemToProfession[itemId] = profId
  end
end

-- Получить профессию колониста
function Professions.GetProfession(colonist)
  if not colonist then return nil end
  if colonist.profession then return colonist.profession end
  if colonist.GetProfession then return colonist:GetProfession() end
  if colonist.data and colonist.data.profession then
    return colonist.data.profession
  end
  return nil
end

-- Проверить, подпадает ли предмет под профессию
function Professions.IsItemForProfession(itemId, profId)
  local items = professionItems[profId]
  if not items then return false end
  for _, id in ipairs(items) do
    if id == itemId then
      return true
    end
  end
  return false
end

-- Получить множитель скорости крафта
function Professions.GetCraftMultiplier(colonist, itemId)
  local profId = Professions.GetProfession(colonist)
  if not profId then return 1.0 end

  if Professions.IsItemForProfession(itemId, profId) then
    return craftMultipliers[profId] or 1.0
  end

  return 1.0
end

-- Получить бонус к медицине
function Professions.GetMedBonus(colonist)
  local profId = Professions.GetProfession(colonist)
  if not profId then return 0 end
  return medBonus[profId] or 0
end

-- ============================================
-- Хуки на крафт
-- ============================================

-- Вариант 1: on_craft_start
if alem and alem.on_craft_start then
  alem.on_craft_start(function(colonist, recipe)
    local itemId = recipe.itemId or recipe.id or recipe
    local mult = Professions.GetCraftMultiplier(colonist, itemId)
    if mult > 1.0 then
      if recipe.duration then
        recipe.duration = recipe.duration / mult
      end
      if recipe.time then
        recipe.time = recipe.time / mult
      end
      if recipe.craftTime then
        recipe.craftTime = recipe.craftTime / mult
      end
    end
  end)
end

-- Вариант 2: on_craft_complete
if alem and alem.on_craft_complete then
  alem.on_craft_complete(function(colonist, itemId)
    local mult = Professions.GetCraftMultiplier(colonist, itemId)
    if mult > 1.0 then
      print("[AlemTF2] " .. tostring(itemId) .. " crafted x" .. tostring(mult))
    end
  end)
end

-- Вариант 3: get_craft_speed
if alem and alem.get_craft_speed then
  local origGetCraftSpeed = alem.get_craft_speed
  alem.get_craft_speed = function(colonist, itemId)
    local base = origGetCraftSpeed(colonist, itemId)
    local mult = Professions.GetCraftMultiplier(colonist, itemId)
    return base * mult
  end
end

-- Вариант 4: on_production
if alem and alem.on_production then
  alem.on_production(function(colonist, recipe, workbench)
    local itemId = recipe.itemId or recipe.id or recipe
    local mult = Professions.GetCraftMultiplier(colonist, itemId)
    if mult > 1.0 and recipe.duration then
      recipe.duration = recipe.duration / mult
    end
  end)
end

-- Вариант 5: get_med_skill
if alem and alem.get_med_skill then
  local origGetMedSkill = alem.get_med_skill
  alem.get_med_skill = function(colonist)
    local base = origGetMedSkill(colonist)
    local bonus = Professions.GetMedBonus(colonist)
    return base + bonus
  end
end

-- Вариант 6: on_heal
if alem and alem.on_heal then
  alem.on_heal(function(colonist_med, patient)
    local bonus = Professions.GetMedBonus(colonist_med)
    if bonus > 0 then
      if patient.healSpeed then
        patient.healSpeed = patient.healSpeed * (1.0 + bonus * 0.1)
      end
    end
  end)
end

-- ============================================
-- Утилиты для отладки
-- ============================================

function Professions.Debug(colonist, itemId)
  local profId = Professions.GetProfession(colonist)
  local mult = Professions.GetCraftMultiplier(colonist, itemId)
  print("[AlemTF2] === DEBUG ===")
  print("[AlemTF2] Colonist profession: " .. tostring(profId))
  print("[AlemTF2] Item: " .. tostring(itemId))
  print("[AlemTF2] Multiplier: " .. tostring(mult))
  print("[AlemTF2] Med bonus: " .. tostring(Professions.GetMedBonus(colonist)))
  print("[AlemTF2] =================")
end

-- Вывод при загрузке
print("[AlemTF2] Professions loaded: gunsmith, armorer, demolitionist, combat_medic")
print("[AlemTF2] Craft multipliers: gunsmith x1.3, armorer x1.2, demolitionist x1.4, combat_medic x1.15")
print("[AlemTF2] Items registered: weapons, ammo, armor, explosives, medical")

return Professions
