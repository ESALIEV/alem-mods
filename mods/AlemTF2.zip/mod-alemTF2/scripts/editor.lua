-- scripts/editor.lua
-- Редактор персонажа с обходом бага отрисовки текста в input

local w = nil
local current_pawn = nil

-- Буферы ввода
local buf = {
    pawn = "", trait = "",
    skill_id = "", skill_lvl = "", skill_pass = "",
    bio_child = "", bio_adult = ""
}

-- Универсальное чтение значения поля
local function read_field(id, var)
    local v = buf[var]
    if v == nil or v == "" then
        v = alem.window_get("pawn_editor", id) or ""
    end
    return v
end

-- Обновление текста-подсказки под полем ввода
local function update_preview(var, text)
    if not w then return end
    local preview_id = "prev_" .. var
    local val = (text == "" or text == nil) and "(пусто)" or text
    w.set(preview_id, {text = "Ты ввёл: " .. val})
end

local function make_submit(var, id)
    return function(text)
        buf[var] = text or ""
        update_preview(var, text)
    end
end

local function skill_rows(data)
    local rows = {}
    if data and data.skills then
        local keys = {}
        for k, _ in pairs(data.skills) do keys[#keys + 1] = k end
        table.sort(keys)
        for _, k in ipairs(keys) do
            local s = data.skills[k]
            local lvl, pass = 0, 0
            if type(s) == "table" then
                lvl = s.level or 0
                pass = s.passion or 0
            else
                lvl = s or 0
            end
            rows[#rows + 1] = string.format("%s: ур.%d (стр.%d)", k, lvl, pass)
        end
    end
    if #rows == 0 then rows = {"(нет данных)"} end
    return rows
end

local function refresh()
    if not w then return end

    local names = alem.colonists() or {}
    w.set("colonist_list", {text = (#names > 0) and table.concat(names, ", ") or "(нет)"})

    if not current_pawn then
        w.set("info", {text = "Колонист не выбран. Введи имя и нажми «Выбрать»."})
        w.set("skill_list", {rows = {"(нет)"}})
        w.set("trait_list", {rows = {"(нет)"}})
        return
    end

    local data = alem.colonist(current_pawn)
    if not data then
        w.set("info", {text = "Колонист '" .. current_pawn .. "' не найден"})
        return
    end

    local traits = alem.traits(current_pawn) or {}
    local info = string.format(
        "Имя: %s   Возраст: %s   Пол: %s\nЗдоровье: %s%%   Настроение: %s%%\nЧерт: %d",
        data.name or current_pawn,
        tostring(data.age or "?"),
        (data.male == true) and "Мужчина" or "Женщина",
        tostring(data.health or "?"),
        tostring(data.mood or "?"),
        #traits
    )
    w.set("info", {text = info})
    w.set("skill_list", {rows = skill_rows(data)})

    local trows = {}
    for _, t in ipairs(traits) do trows[#trows + 1] = t end
    if #trows == 0 then trows = {"(нет черт)"} end
    w.set("trait_list", {rows = trows})

    -- Синхронизируем поля био и подсказки
    if data.bio_child then 
        w.set("in_bio_child", {text = data.bio_child}) 
        buf.bio_child = data.bio_child
        update_preview("bio_child", data.bio_child)
    end
    if data.bio_adult then 
        w.set("in_bio_adult", {text = data.bio_adult}) 
        buf.bio_adult = data.bio_adult
        update_preview("bio_adult", data.bio_adult)
    end
end

local function do_pick()
    local name = read_field("in_pawn", "pawn")
    if not name or name == "" then alem.toast("Введи имя колониста"); return end
    current_pawn = name
    -- Принудительно перерисовываем поле и подсказку
    w.set("in_pawn", {text = name})
    update_preview("pawn", name)
    refresh()
    alem.toast("Выбран: " .. name)
end

local function update_trait_list()
    if not current_pawn then return end
    local traits = alem.traits(current_pawn) or {}
    local trows = {}
    for _, tr in ipairs(traits) do trows[#trows + 1] = tr end
    if #trows == 0 then trows = {"(нет черт)"} end
    w.set("trait_list", {rows = trows})
end

local function do_add_trait()
    if not current_pawn then alem.toast("Сначала выбери колониста"); return end
    local t = read_field("in_trait", "trait")
    if not t or t == "" then alem.toast("Введи название черты"); return end
    alem.add_trait(current_pawn, t)
    alem.toast("Добавлено: " .. t)
    update_trait_list()
end

local function do_rem_trait()
    if not current_pawn then alem.toast("Сначала выбери колониста"); return end
    local t = read_field("in_trait", "trait")
    if not t or t == "" then alem.toast("Введи название черты"); return end
    alem.remove_trait(current_pawn, t)
    alem.toast("Убрано: " .. t)
    update_trait_list()
end

local function do_bio()
    if not current_pawn then alem.toast("Сначала выбери колониста"); return end
    local c = read_field("in_bio_child", "bio_child")
    local a = read_field("in_bio_adult", "bio_adult")
    alem.set_bio(current_pawn, (c ~= "") and c or nil, (a ~= "") and a or nil)
    alem.toast("Биография обновлена")
    refresh()
end

local function do_close()
    if w then w.close() end
end

local function do_skill()
    if not current_pawn then alem.toast("Сначала выбери колониста"); return end
    local id = read_field("in_skill_id", "skill_id")
    if not id or id == "" then alem.toast("Введи id навыка (напр. melee)"); return end
    local lvl = tonumber(read_field("in_skill_lvl", "skill_lvl")) or 0
    local pass = tonumber(read_field("in_skill_pass", "skill_pass")) or 0
    if lvl < 0 then lvl = 0 end
    if lvl > 20 then lvl = 20 end
    if pass < 0 then pass = 0 end
    if pass > 2 then pass = 2 end
    alem.set_skill(current_pawn, id, lvl, pass)
    alem.toast(id .. ": ур." .. lvl .. ", страсть " .. pass)
    refresh()
end

local function do_reload()
    buf.pawn = ""; buf.trait = ""; buf.skill_id = ""; buf.skill_lvl = ""; buf.skill_pass = ""
    buf.bio_child = ""; buf.bio_adult = ""
    update_preview("pawn", "")
    update_preview("trait", "")
    update_preview("skill_id", "")
    update_preview("skill_lvl", "")
    update_preview("skill_pass", "")
    update_preview("bio_child", "")
    update_preview("bio_adult", "")
    refresh()
end

function open_editor()
    if w and w.is_open() then w.close(); return end

    w = alem.window{
        id = "pawn_editor",
        title = "Редактор персонажа",
        w = 940, h = 780, -- Увеличили высоту, чтобы влезли подсказки
        anchor = "center",
        pause = true,
        elements = {
            {type="text", id="header", text="Редактор персонажа", x=20, y=15, w=900, h=30, size=22},

            {type="text", id="colonist_hint", text="Живые колонисты (введи имя в поле ниже):", x=20, y=55, w=900, h=22, size=15},
            {type="text", id="colonist_list", text="", x=20, y=80, w=900, h=44, size=14},

            -- Поле ввода + подсказка
            {type="input", id="in_pawn", placeholder="Имя колониста", x=20, y=130, w=300, h=40, on_submit = make_submit("pawn", "in_pawn")},
            {type="text", id="prev_pawn", text="Ты ввёл: (пусто)", x=20, y=172, w=300, h=18, size=12},
            
            {type="button", id="btn_pick", text="Выбрать", x=330, y=130, w=160, h=40, on_click = do_pick},
            {type="button", id="btn_close", text="Закрыть", x=760, y=130, w=160, h=40, on_click = do_close},

            {type="text", id="info", text="Колонист не выбран", x=20, y=195, w=900, h=70, size=16},

            {type="text", id="skills_title", text="Навыки:", x=20, y=270, w=400, h=24, size=18},
            {type="list", id="skill_list", rows={"(нет)"}, x=20, y=298, w=430, h=120},

            {type="text", id="traits_title", text="Черты:", x=490, y=270, w=430, h=24, size=18},
            {type="list", id="trait_list", rows={"(нет)"}, x=490, y=298, w=430, h=120},

            -- Навыки + подсказки
            {type="text", id="skill_edit", text="Навык — id (напр. melee), уровень 0–20, страсть 0–2:", x=20, y=430, w=900, h=22, size=15},
            {type="input", id="in_skill_id", placeholder="melee", x=20, y=455, w=200, h=38, on_submit = make_submit("skill_id", "in_skill_id")},
            {type="text", id="prev_skill_id", text="", x=20, y=495, w=200, h=16, size=12},
            
            {type="input", id="in_skill_lvl", placeholder="0-20", x=230, y=455, w=140, h=38, on_submit = make_submit("skill_lvl", "in_skill_lvl")},
            {type="text", id="prev_skill_lvl", text="", x=230, y=495, w=140, h=16, size=12},
            
            {type="input", id="in_skill_pass", placeholder="0-2", x=380, y=455, w=140, h=38, on_submit = make_submit("skill_pass", "in_skill_pass")},
            {type="text", id="prev_skill_pass", text="", x=380, y=495, w=140, h=16, size=12},

            {type="button", id="btn_skill", text="Применить", x=530, y=455, w=180, h=38, on_click = do_skill},

            -- Черты + подсказка
            {type="text", id="trait_edit", text="Черта — название (вводи вручную):", x=20, y=520, w=900, h=22, size=15},
            {type="input", id="in_trait", placeholder="Название черты", x=20, y=545, w=300, h=38, on_submit = make_submit("trait", "in_trait")},
            {type="text", id="prev_trait", text="", x=20, y=585, w=300, h=16, size=12},
            
            {type="button", id="btn_add_trait", text="Добавить", x=330, y=545, w=150, h=38, on_click = do_add_trait},
            {type="button", id="btn_rem_trait", text="Удалить", x=490, y=545, w=150, h=38, on_click = do_rem_trait},

            -- Био + подсказки
            {type="text", id="bio_edit", text="Биография:", x=20, y=615, w=900, h=22, size=15},
            
            {type="input", id="in_bio_child", placeholder="Детство", x=20, y=640, w=440, h=38, on_submit = make_submit("bio_child", "in_bio_child")},
            {type="text", id="prev_bio_child", text="", x=20, y=680, w=440, h=16, size=12},
            
            {type="input", id="in_bio_adult", placeholder="Взрослая жизнь", x=470, y=640, w=440, h=38, on_submit = make_submit("bio_adult", "in_bio_adult")},
            {type="text", id="prev_bio_adult", text="", x=470, y=680, w=440, h=16, size=12},

            {type="button", id="btn_bio", text="Сохранить био", x=20, y=710, w=200, h=38, on_click = do_bio},
            {type="button", id="btn_reload", text="Обновить", x=230, y=710, w=160, h=38, on_click = do_reload},
        }
    }

    local sel = alem.selected()
    if sel then
        current_pawn = sel
        w.set("in_pawn", {text = sel})
        buf.pawn = sel
        update_preview("pawn", sel)
    end

    refresh()
end

if alem.button then
    alem.button("Редактор", function() open_editor() end)
end