function tf2_eyestus_spawn()
    local center = colony.getCenter()
    local x = center.x + math.random(-15, 15)
    local y = center.y + math.random(-15, 15)

    local boss = colonist.create("tf2_eyestus")
    boss:setPos(x, y)
    boss:setFaction("enemy")
    boss.isBoss = true

    ui.showMessage("ОПАСНОСТЬ: Глазастус появился!", "red")
end
