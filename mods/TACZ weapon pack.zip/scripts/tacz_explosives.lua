-- TACZ explosives: RPG-7 + RGD-5
-- Table onHit explode = people only. Lua covers animals + reliable boom.

local CFG = {
  kkg_rpg7 = { r = 2.0, dmg = 55, build = 0.55, fire = true, label = 'Взрыв РПГ-7' },
  kkg_rgd5 = { r = 2.5, dmg = 45, build = 0.35, fire = false, label = 'Взрыв РГД-5' },
}

local function pick_id(...)
  local n = select('#', ...)
  if n >= 10 then
    local w = select(10, ...)
    if CFG[w] then return w end
  end
  for i = 1, n do
    local a = select(i, ...)
    if type(a) == 'string' and CFG[a] then return a end
  end
  -- attacker holding weapon
  local who = select(2, ...)
  if who and alem.weapon_of and alem.item_info then
    local ok, h = pcall(alem.weapon_of, who)
    if ok and h then
      local ok2, info = pcall(alem.item_info, h)
      if ok2 and info and CFG[info.id] then return info.id end
    end
  end
  return nil
end

local function xy(...)
  local n = select('#', ...)
  local nums = {}
  for i = 1, n do
    local a = select(i, ...)
    if type(a) == 'number' then nums[#nums+1] = a end
  end
  if #nums >= 2 then return nums[#nums-1], nums[#nums] end
  local target = select(1, ...)
  if target and alem.pos then
    local ok, x, y = pcall(alem.pos, target)
    if ok and type(x) == 'number' then return x, y end
  end
  return nil, nil
end

local last = {}
local function boom(id, x, y, tag)
  if not x or not y then
    alem.log('TACZ boom no xy ' .. tostring(id) .. ' ' .. tostring(tag))
    return
  end
  local c = CFG[id]
  if not c then return end
  local key = string.format('%s_%.1f_%.1f', id, x, y)
  local t = 0
  if alem.time then local ok, v = pcall(alem.time); if ok and type(v)=='number' then t=v end end
  if last[key] and (t - last[key]) < 0.2 then return end
  last[key] = t

  if alem.explode then
    pcall(alem.explode, x, y, c.r, c.dmg, c.build)
  elseif alem.damage_at then
    pcall(alem.damage_at, x, y, c.r, c.dmg, 'Heat', c.label)
  end
  if alem.fx then pcall(alem.fx, 'explosion', x, y) end
  if c.fire and alem.ignite then
    pcall(alem.ignite, math.floor(x + 0.5), math.floor(y + 0.5))
  end
  alem.log(string.format('TACZ %s boom @ %.1f,%.1f (%s)', id, x, y, tostring(tag)))
end

local function on_any(...)
  local id = pick_id(...)
  if not id then return end
  local x, y = xy(...)
  boom(id, x, y, 'hook')
end

alem.on('on_before_hit', on_any)
alem.on('on_hit', on_any)

-- table onHit script fallback for grenade / rpg
function tacz_rgd5_boom(attacker, target, weapon, x, y)
  if type(x) == 'number' and type(y) == 'number' then
    boom('kkg_rgd5', x, y, 'table')
  elseif target and alem.pos then
    local ok, px, py = pcall(alem.pos, target)
    if ok then boom('kkg_rgd5', px, py, 'table-pos') end
  end
end

function tacz_rpg7_boom(attacker, target, weapon, x, y)
  if type(x) == 'number' and type(y) == 'number' then
    boom('kkg_rpg7', x, y, 'table')
  elseif target and alem.pos then
    local ok, px, py = pcall(alem.pos, target)
    if ok then boom('kkg_rpg7', px, py, 'table-pos') end
  end
end

alem.on('on_load', function()
  alem.log('TACZ explosives: RPG-7 + RGD-5')
end)
