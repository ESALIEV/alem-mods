-- TACZ: ствол помнит убийства и получает имя
-- Память на вещи — движок (item_add / item_rename). Пороги — этот скрипт.
-- Alem 0.23.06

local TITLES = {
  [10]  = { suffix = '',           letter = 'Ствол получил имя',
            fmt = function(base, who) return base .. ' ' .. who end },
  [30]  = { suffix = ' Грозного',  letter = 'Ствол закалился в бою',
            fmt = function(base, who) return base .. ' ' .. who .. ' Грозного' end },
  [100] = { suffix = ' Проклятого', letter = 'Легендарный ствол',
            fmt = function(base, who) return base .. ' ' .. who .. ' Проклятого' end },
}

local BASE_NAMES = {
  kkg_ak47 = 'АК-47', kkg_ak47_scope = 'АК-47', kkg_m16 = 'M16',
  kkg_makarov = 'ПМ', kkg_makarov_rds = 'ПМ',
  kkg_glock19 = 'Glock 19', kkg_glock19_rds = 'Glock 19',
  kkg_gsh18 = 'ГШ-18', kkg_welrod = 'Welrod', kkg_mateba = 'Mateba',
  kkg_calico = 'Calico', kkg_calico_grip = 'Calico',
  kkg_mat49 = 'MAT-49', kkg_fmg9 = 'FMG-9', kkg_pp90m1 = 'ПП-90М1',
  kkg_bizon = 'Бизон', kkg_tkb022 = 'ТКБ-022П',
  kkg_ak12 = 'АК-12', kkg_abakan = 'Абакан', kkg_sks = 'СКС',
  kkg_mosin = 'Мосин', kkg_mosin_sawn = 'Обрез',
  kkg_chiappa_tt = 'Chiappa', kkg_thompson = 'Томпсон',
  kkg_deagle = 'Desert Eagle', kkg_rpg7 = 'РПГ-7', kkg_rgd5 = 'РГД-5',
}

local function is_tacz_id(id)
  return type(id) == 'string' and id:sub(1, 4) == 'kkg_'
end

local function base_name(info)
  if not info then return 'Ствол' end
  local id = info.id
  if BASE_NAMES[id] then return BASE_NAMES[id] end
  if info.name and info.name ~= '' then return info.name end
  return tostring(id or 'Ствол')
end

alem.on('on_kill', function(victim, kind, cause, profile, x, y, killer)
  if not killer or killer == '' then return end

  local w = alem.weapon_of(killer)
  if not w then return end

  local info = nil
  if alem.item_info then
    local ok, i = pcall(alem.item_info, w)
    if ok then info = i end
  end
  local wid = info and info.id or nil
  if not is_tacz_id(wid) then return end

  -- только осмысленные убийства: враг (и человек, и зверь — оба копят историю)
  -- kind: "enemy" / "colonist" / иногда другое
  local k = tostring(kind or '')
  if k == 'colonist' then
    -- дружественный огонь не кормит легенду
    return
  end

  local n = alem.item_add(w, 'kills', 1)
  if not n then return end

  -- запомнить первого хозяина на момент именования
  if not alem.item_get(w, 'named_by', nil) and (n == 10 or n == 30 or n == 100) then
    alem.item_set(w, 'named_by', killer)
  end

  local rule = TITLES[n]
  if not rule then return end

  local who = alem.item_get(w, 'named_by', killer) or killer
  local base = base_name(info)
  local new_name = rule.fmt(base, who)

  if alem.item_rename then
    alem.item_rename(w, new_name)
  end

  alem.item_set(w, 'title_level', n)
  alem.letter(
    rule.letter,
    string.format('%s: %d убийств из %s.\nТеперь это «%s».', who, n, base, new_name)
  )
  alem.log(string.format('TACZ legend: %s kills=%d -> %s', wid, n, new_name))
end)

alem.on('on_load', function()
  alem.log('TACZ weapon legends: 10 / 30 / 100 kills')
end)
