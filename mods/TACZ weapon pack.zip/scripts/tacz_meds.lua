-- TACZ: использование препаратов из рюкзака
-- on_use(имя, id вещи) — съел/уколол из рюкзака

alem.on('on_use', function(name, item_id)
  if item_id ~= 'TaczAdrenaline' then return end

  -- вещество из substances.json (боль, сон, mood −2, workMul…)
  pcall(alem.substance, name, 'tacz_adrenaline')

  -- доп. боевой бафф на ~3 часа (aim/move чуть выше)
  pcall(alem.buff, name, 'tacz_adren_buff', {
    moveSpeed = 0.12,
    aim = 0.08,
    pain = -0.2,
    mood = -2,
  }, 3)

  pcall(alem.memory, name, 4, 1, 'Укол адреналина')
  pcall(alem.log, 'TACZ: adrenaline used by ' .. tostring(name))
end)
