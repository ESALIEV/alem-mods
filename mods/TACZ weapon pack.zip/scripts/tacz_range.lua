-- TACZ: стрельбище — работа «Тренировка»
-- works.json → check + fn

local AMMO = {
  'Ammo9x19', 'Ammo9x18', 'Ammo762x39', 'Ammo545x39', 'Ammo556',
  'Ammo762x54', 'Ammo12ga', 'Ammo45ACP', 'Ammo50AE',
  'Ammo9x19Exp', 'Ammo9x18Exp', 'Ammo762x39Exp', 'Ammo545x39Exp',
  'Ammo556Exp', 'Ammo762x54Exp', 'Ammo12gaExp', 'Ammo45ACPExp', 'Ammo50AEExp',
  'Ammo', 'AmmoSmokeless'
}

local ROUNDS = 8   -- патронов за смену
local XP = 45      -- опыт ranged за успешную тренировку

local function stock(id)
  local ok, n = pcall(alem.resource, id)
  if ok and type(n) == 'number' and n > 0 then return n end
  return 0
end

local function find_ammo()
  for _, id in ipairs(AMMO) do
    if stock(id) >= ROUNDS then return id end
  end
  for _, id in ipairs(AMMO) do
    if stock(id) >= 1 then return id end
  end
  return nil
end

function tacz_can_train(uid, who, work)
  return find_ammo() ~= nil
end

function tacz_on_train(work, who, x, y, uid)
  local id = find_ammo()
  if not id then
    pcall(alem.toast, 'Нет патронов для тренировки')
    return
  end
  local have = stock(id)
  local take = math.min(ROUNDS, have)
  pcall(alem.take, id, take)

  -- опыт дальнего боя
  local ok, lvl = pcall(alem.xp, who, 'ranged', XP)
  if not ok then
    pcall(alem.xp, who, 'shooting', XP)
  end

  pcall(alem.memory, who, 2, 0.4, 'Тренировка на стрельбище')
  pcall(alem.log, 'TACZ range: ' .. tostring(who) .. ' -' .. tostring(take) .. ' ' .. id)
  if x and y then
    pcall(alem.fx_text, '+' .. tostring(XP) .. ' Стрельба', x, y, '#9ad1ff')
  end
end

alem.on('on_work_done', function(work, who, x, y, uid)
  if work == 'tacz_training' then
    -- дубль на случай если fn не вызвали
  end
end)

alem.on('on_load', function()
  pcall(alem.log, 'TACZ: shooting range ready')
end)
