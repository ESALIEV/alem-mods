-- TACZ durability · 0.23.07
-- Wear on HIT (no on_shot in API). Memory on weapon handle.

local MAX = {
  kkg_makarov=700, kkg_makarov_rds=720, kkg_glock19=750, kkg_glock19_rds=780,
  kkg_welrod=650, kkg_gsh18=800, kkg_mateba=850, kkg_deagle=700,
  kkg_calico=950, kkg_calico_grip=1000, kkg_mat49=900, kkg_fmg9=920,
  kkg_pp90m1=980, kkg_bizon=1000, kkg_thompson=950,
  kkg_ak47=1200, kkg_ak47_scope=1250, kkg_m16=1150, kkg_tkb022=1100,
  kkg_ak12=1350, kkg_abakan=1400, kkg_sks=1300, kkg_mosin=1400,
  kkg_mosin_sawn=900, kkg_chiappa_tt=800, kkg_rpg7=400,
}

local REPAIR_STEEL = { default=6, light=4, heavy=8, launcher=10 }
local REPAIR_PARTS = { default=1, light=1, heavy=2, launcher=2 }

local function class_of(id)
  if id == 'kkg_rpg7' then return 'launcher' end
  if id == 'kkg_ak12' or id == 'kkg_abakan' or id == 'kkg_ak47' or id == 'kkg_ak47_scope'
     or id == 'kkg_m16' or id == 'kkg_sks' or id == 'kkg_mosin' or id == 'kkg_tkb022' then
    return 'heavy'
  end
  if type(id) == 'string' and (
      id:find('makarov', 1, true) or id:find('glock', 1, true) or id:find('welrod', 1, true)
      or id:find('gsh', 1, true) or id:find('mateba', 1, true) or id:find('deagle', 1, true)
     ) then
    return 'light'
  end
  return 'default'
end

local function is_tacz(id)
  return type(id) == 'string' and MAX[id] ~= nil
end

-- pull weapon id from fixed signature or any string arg
local function pick_weapon_id(...)
  local n = select('#', ...)
  -- preferred: 10th arg (weapon) on 0.23.05+
  if n >= 10 then
    local w = select(10, ...)
    if is_tacz(w) then return w end
  end
  for i = n, 1, -1 do
    local a = select(i, ...)
    if is_tacz(a) then return a end
    if type(a) == 'string' and a:sub(1, 4) == 'kkg_' and MAX[a] then return a end
  end
  return nil
end

local function handle_of(who)
  if not who or who == '' or not alem.weapon_of then return nil end
  local ok, h = pcall(alem.weapon_of, who)
  if ok then return h end
  return nil
end

local function id_of_handle(h)
  if not h or not alem.item_info then return nil end
  local ok, info = pcall(alem.item_info, h)
  if ok and type(info) == 'table' and type(info.id) == 'string' then
    return info.id
  end
  return nil
end

local function get_set_dur(h, id)
  local max = MAX[id]
  if not max or not h then return nil, max end
  local d = nil
  if alem.item_get then
    local ok, v = pcall(alem.item_get, h, 'durability', nil)
    if ok then d = v end
  end
  if d == nil then
    d = max
    if alem.item_set then pcall(alem.item_set, h, 'durability', max) end
  end
  return tonumber(d) or max, max
end

local jam_cd = {}

local function notify(msg)
  if alem.toast then pcall(alem.toast, msg)
  elseif alem.log then alem.log(msg) end
end

-- cancel damage when broken
alem.on('on_before_hit', function(...)
  local who = select(2, ...)
  local id = pick_weapon_id(...)
  local h = handle_of(who)
  if not id and h then id = id_of_handle(h) end
  if not is_tacz(id) then return nil end
  if not h then return nil end
  local d, max = get_set_dur(h, id)
  if d and d <= 0 then
    local key = tostring(who)
    local t = 0
    if alem.time then local ok, v = pcall(alem.time); if ok and type(v)=='number' then t=v end end
    if not jam_cd[key] or (t - jam_cd[key]) > 2.5 then
      jam_cd[key] = t
      notify(tostring(who) .. ': ствол заклинило!')
    end
    return 0
  end
  return nil
end)

alem.on('on_hit', function(...)
  local who = select(2, ...)
  local id = pick_weapon_id(...)
  local h = handle_of(who)
  if not id and h then id = id_of_handle(h) end
  if not is_tacz(id) then return end
  if not h then
    -- no handle: still log once so we know hook fires
    alem.log('TACZ wear: hit with ' .. tostring(id) .. ' but no weapon_of(' .. tostring(who) .. ')')
    return
  end
  local d, max = get_set_dur(h, id)
  if not d or d <= 0 then return end
  d = d - 1
  pcall(alem.item_set, h, 'durability', d)
  if d == 0 then
    pcall(alem.item_set, h, 'jammed', true)
    if alem.letter then
      pcall(alem.letter, 'Заклинило',
        tostring(who) .. ': ствол исчерпал ресурс. Долгое нажатие → «Починить ствол» (сталь + точные детали).')
    end
    notify(tostring(who) .. ': КЛИН')
  elseif max and d == math.floor(max * 0.2) then
    notify(tostring(who) .. ': ствол изношен (~20%)')
  end
end)

local function can_repair(name)
  local h = handle_of(name)
  if not h then return false end
  local id = id_of_handle(h)
  if not is_tacz(id) then return false end
  local d, max = get_set_dur(h, id)
  return d ~= nil and max ~= nil and d < max
end

alem.pawn_action('Починить ствол', function(name)
  local h = handle_of(name)
  if not h then notify('Нет оружия в руках'); return end
  local id = id_of_handle(h)
  if not is_tacz(id) then notify('Не ствол TACZ'); return end
  local d, max = get_set_dur(h, id)
  if d >= max then notify('Ствол в порядке'); return end
  local cls = class_of(id)
  local need_s = REPAIR_STEEL[cls] or 6
  local need_p = REPAIR_PARTS[cls] or 1
  local have_s = (alem.resource and alem.resource('Steel')) or 0
  local have_p = (alem.resource and alem.resource('PreciseParts')) or 0
  if have_s < need_s or have_p < need_p then
    notify(string.format('Нужно: сталь %d, детали %d', need_s, need_p))
    return
  end
  if alem.take then
    pcall(alem.take, 'Steel', need_s)
    pcall(alem.take, 'PreciseParts', need_p)
  end
  pcall(alem.item_set, h, 'durability', max)
  pcall(alem.item_set, h, 'jammed', false)
  notify(string.format('%s: отремонтирован %d/%d', tostring(id), max, max))
end, can_repair)

alem.pawn_action('Прочность ствола', function(name)
  local h = handle_of(name)
  if not h then notify('Нет оружия'); return end
  local id = id_of_handle(h)
  if not is_tacz(id) then notify('Не ствол TACZ'); return end
  local d, max = get_set_dur(h, id)
  notify(string.format('%s: %d / %d', tostring(id), d or 0, max or 0))
end, function(name)
  local h = handle_of(name)
  return h and is_tacz(id_of_handle(h))
end)

alem.on('on_load', function()
  alem.log('TACZ durability v2 loaded')
end)
