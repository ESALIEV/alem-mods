-- TACZ Arms · статистика стволов · Alem 0.23.05+
-- Считаем ТОЛЬКО когда id ствола TACZ явно виден в хуке.
-- Кэш «последний ствол» НЕ используется для киллов (иначе чужой мод
-- продолжает писать убийства на старый ПМ).

local DEBUG = true
local PREFIX_K = 'tacz_k_'
local PREFIX_H = 'tacz_h_'
local PREFIX_E = 'tacz_e_'
local LIST_KEY = 'tacz_wlist'

local NAMES = {
  kkg_ak47 = 'АК-47', kkg_ak47_scope = 'АК-47 + ПСО', kkg_m16 = 'M16',
  kkg_makarov = 'ПМ', kkg_makarov_rds = 'ПМ + Burris',
  kkg_mateba = 'Mateba', kkg_calico = 'Calico', kkg_calico_grip = 'Calico + рукоять',
  kkg_glock19 = 'Glock 19', kkg_glock19_rds = 'Glock + Holosun',
  kkg_welrod = 'Welrod', kkg_gsh18 = 'ГШ-18', kkg_tkb022 = 'ТКБ-022П',
  kkg_mat49 = 'MAT-49', kkg_fmg9 = 'FMG-9', kkg_chiappa_tt = 'Chiappa TT',
  kkg_pp90m1 = 'ПП-90М1', kkg_mosin = 'Мосин', kkg_mosin_sawn = 'Обрез Мосина',
  kkg_bizon = 'Бизон', kkg_abakan = 'Абакан', kkg_ak12 = 'АК-12',
  kkg_sks = 'СКС', kkg_thompson = 'Томпсон', kkg_deagle = 'Desert Eagle', kkg_rpg7 = 'РПГ-7', kkg_rgd5 = 'РГД-5',
}

local LABEL_TO_ID = {
  ['Очередь АК-47'] = 'kkg_ak47',
  ['Очередь АК-47 (ПСО)'] = 'kkg_ak47_scope',
  ['Очередь M16'] = 'kkg_m16',
  ['Пуля ПМ'] = 'kkg_makarov',
  ['Пуля Glock'] = 'kkg_glock19',
  ['Пуля ГШ-18'] = 'kkg_gsh18',
  ['Тихий выстрел'] = 'kkg_welrod',
  ['Пуля Mateba'] = 'kkg_mateba',
  ['Очередь Calico'] = 'kkg_calico',
  ['Очередь MAT-49'] = 'kkg_mat49',
  ['Очередь FMG-9'] = 'kkg_fmg9',
  ['Очередь ПП-90М1'] = 'kkg_pp90m1',
  ['Очередь Бизона'] = 'kkg_bizon',
  ['Очередь Абакана'] = 'kkg_abakan',
  ['Очередь АК-12'] = 'kkg_ak12',
  ['Очередь ТКБ'] = 'kkg_tkb022',
  ['Пуля Мосина'] = 'kkg_mosin',
  ['Пуля обреза'] = 'kkg_mosin_sawn',
  ['Дробь Triple Threat'] = 'kkg_chiappa_tt',
  ['Пуля СКС'] = 'kkg_sks',
  ['Очередь Томпсона'] = 'kkg_thompson',
  ['Пуля Desert Eagle'] = 'kkg_deagle',
}

local function is_tacz(id)
  return type(id) == 'string' and NAMES[id] ~= nil
end

local function resolve(raw)
  if raw == nil then return nil end
  local s = tostring(raw)
  if is_tacz(s) then return s end
  if LABEL_TO_ID[s] then return LABEL_TO_ID[s] end
  local id = s:match('weapon:([%w_]+)') or s:match('(kkg_[%w_]+)')
  if id and is_tacz(id) then return id end
  return nil
end

-- только явный id в аргументах хука (без кэша по имени колониста)
local function find_weapon(...)
  local n = select('#', ...)
  for i = 1, n do
    local a = select(i, ...)
    local id = resolve(a)
    if id then return id end
    if type(a) == 'table' then
      for _, k in ipairs({ 'weapon', 'weaponId', 'gun', 'held', 'wpn', 'id', 'cause' }) do
        id = resolve(a[k])
        if id then return id end
      end
    end
  end
  return nil
end

local function remember_list(id)
  local list = alem.get(LIST_KEY, '') or ''
  if list == '' then
    alem.set(LIST_KEY, id)
    return
  end
  if not string.find('|' .. list .. '|', '|' .. id .. '|', 1, true) then
    alem.set(LIST_KEY, list .. '|' .. id)
  end
end

local function bump(prefix, id, enemy_only)
  if not id then return end
  local key = prefix .. id
  local n = (alem.get(key, 0) or 0) + 1
  alem.set(key, n)
  remember_list(id)
  if enemy_only then
    local ek = PREFIX_E .. id
    alem.set(ek, (alem.get(ek, 0) or 0) + 1)
  end
  return n
end

local function known_ids()
  local list = alem.get(LIST_KEY, '') or ''
  local out = {}
  if list == '' then return out end
  for id in string.gmatch(list, '[^|]+') do
    if id ~= '' then table.insert(out, id) end
  end
  return out
end

local function show_stats()
  local ids = known_ids()
  if #ids == 0 then
    alem.letter('Статистика TACZ', 'Пока никто не убит из нашего арсенала.\nСтреляйте чаще.')
    return
  end
  local rows = {}
  for _, id in ipairs(ids) do
    table.insert(rows, {
      id = id,
      kills = alem.get(PREFIX_K .. id, 0) or 0,
      hits = alem.get(PREFIX_H .. id, 0) or 0,
      enemy = alem.get(PREFIX_E .. id, 0) or 0,
    })
  end
  table.sort(rows, function(a, b)
    if a.kills ~= b.kills then return a.kills > b.kills end
    return a.hits > b.hits
  end)

  local lines = { 'Топ стволов TACZ:' }
  for i = 1, math.min(10, #rows) do
    local r = rows[i]
    local acc = ''
    if r.hits > 0 then
      acc = string.format(', ~%d%%', math.floor(r.kills / r.hits * 100))
    end
    table.insert(lines, string.format(
      '%d. %s — %d уб. (враги %d, поп. %d%s)',
      i, NAMES[r.id] or r.id, r.kills, r.enemy, r.hits, acc))
  end
  local tk, th = 0, 0
  for _, r in ipairs(rows) do tk = tk + r.kills; th = th + r.hits end
  table.insert(lines, '')
  table.insert(lines, string.format('Итого: %d убийств, %d попаданий.', tk, th))
  alem.letter('Статистика TACZ', table.concat(lines, '\n'))
end

-- on_hit: только явный TACZ id
alem.on('on_hit', function(...)
  local wpn = find_weapon(...)
  if wpn then
    bump(PREFIX_H, wpn, false)
    if DEBUG then
      local t = (alem.get('tacz_dbg_h', 0) or 0) + 1
      alem.set('tacz_dbg_h', t)
      if t <= 6 then
        alem.log('TACZ hit ' .. wpn)
      end
    end
  end
end)

-- on_kill: ТОЛЬКО если ствол TACZ виден в аргументах. Без кэша по колонисту.
alem.on('on_kill', function(...)
  if DEBUG then
    local t = (alem.get('tacz_dbg_k', 0) or 0) + 1
    alem.set('tacz_dbg_k', t)
    if t <= 12 then
      local parts = {}
      for i = 1, select('#', ...) do
        parts[i] = tostring(select(i, ...))
      end
      alem.log('TACZ on_kill raw: ' .. table.concat(parts, ' | '))
    end
  end

  local victim = select(1, ...)
  local kind = select(2, ...)
  local cause = select(3, ...)

  local wpn = find_weapon(...)
  if not wpn then
    wpn = resolve(cause)
  end

  if wpn then
    local enemy = (tostring(kind or '') == 'enemy')
    local n = bump(PREFIX_K, wpn, enemy)
    if DEBUG then
      alem.log('TACZ kill +1 ' .. wpn .. ' total=' .. tostring(n))
    end
  end
end)

alem.on('on_colonist_died', function(...)
  local wpn = find_weapon(...)
  if not wpn then
    wpn = resolve(select(4, ...)) -- cause often 4th
  end
  if wpn then
    bump(PREFIX_K, wpn, false)
  end
end)

alem.on('on_day', function(day)
  day = tonumber(day) or 0
  if day > 0 and day % 5 == 0 then
    show_stats()
  end
end)

alem.on('on_load', function()
  alem.log('TACZ stats v3.4.2 — no last-weapon cache for kills')
  if alem.menu_button then
    pcall(function()
      alem.menu_button('TACZ статистика', nil, show_stats)
    end)
  end
end)
