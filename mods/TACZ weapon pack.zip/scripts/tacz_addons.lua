-- TACZ Arms: addon bridge (0.23.05+)
-- Другие моды могут проверять alem.has_mod("ak_pack") и читать alem.shared

local ADDONS = {
  fo_wasteland = {
    name = "Fallout Wasteland",
    note = "Верстак пустоши, pipe pistol, .38",
  },
}

local function detect()
  local found = {}
  for id, meta in pairs(ADDONS) do
    local ok, has = pcall(alem.has_mod, id)
    if ok and has then
      found[#found + 1] = id
      pcall(alem.log, "TACZ: addon detected — " .. id .. " (" .. (meta.name or id) .. ")")
    end
  end

  -- общая доска: аддоны и TACZ видят друг друга
  pcall(function()
    alem.shared("tacz_ready", true)
    alem.shared("tacz_addons", found)
    alem.shared("tacz_version", "3.15")
  end)

  if #found > 0 then
    pcall(alem.log, "TACZ: active addons: " .. table.concat(found, ", "))
  else
    pcall(alem.log, "TACZ: no optional addons (fo_wasteland etc.)")
  end
  return found
end

alem.on("on_load", function()
  detect()
end)

-- API для аддонов: alem.shared("tacz_ready") == true если TACZ загружен
-- alem.has_mod("ak_pack") — то же через движок
-- alem.has_mod("fo_wasteland") — с этой стороны
