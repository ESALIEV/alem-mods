# Аддоны (TACZ 3.15+)

TACZ читает опциональные моды через `alem.has_mod`.

## Fallout Wasteland (`fo_wasteland`)
В `mod.json` аддона:
```json
"loadAfter": ["ak_pack"]
```

В скрипте аддона можно писать:
```lua
if alem.has_mod("ak_pack") then
  -- TACZ стоит: можно опираться на калибры/станки
end
-- или
local ready = alem.shared("tacz_ready")
```

TACZ при загрузке пишет в лог список найденных аддонов и выставляет:
- `alem.shared("tacz_ready", true)`
- `alem.shared("tacz_addons", { "fo_wasteland", ... })`
- `alem.shared("tacz_version", "3.15")`
